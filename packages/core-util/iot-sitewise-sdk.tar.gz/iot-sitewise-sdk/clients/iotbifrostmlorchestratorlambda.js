require('aws-sdk/lib/node_loader');
var AWS = require('aws-sdk/lib/core');
var Service = AWS.Service;
var apiLoader = AWS.apiLoader;

apiLoader.services['iotbifrostmlorchestratorlambda'] = {};
AWS.IotBifrostMLOrchestratorLambda = Service.defineService('iotbifrostmlorchestratorlambda', ['2017-07-25']);
Object.defineProperty(apiLoader.services['iotbifrostmlorchestratorlambda'], '2017-07-25', {
  get: function get() {
    var model = require('../apis/iotbifrostmlorchestratorlambda-2017-07-25.min.json');
    model.paginators = require('../apis/iotbifrostmlorchestratorlambda-2017-07-25.paginators.json').pagination;
    return model;
  },
  enumerable: true,
  configurable: true
});

module.exports = AWS.IotBifrostMLOrchestratorLambda;
