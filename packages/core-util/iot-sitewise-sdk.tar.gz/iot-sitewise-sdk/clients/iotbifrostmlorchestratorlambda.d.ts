import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class IotBifrostMLOrchestratorLambda extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: IotBifrostMLOrchestratorLambda.Types.ClientConfiguration)
  config: Config & IotBifrostMLOrchestratorLambda.Types.ClientConfiguration;
  /**
   * 
   */
  createAndStartAnomalyDetector(params: IotBifrostMLOrchestratorLambda.Types.CreateAndStartAnomalyDetectorRequest, callback?: (err: AWSError, data: IotBifrostMLOrchestratorLambda.Types.CreateAndStartAnomalyDetectorResponse) => void): Request<IotBifrostMLOrchestratorLambda.Types.CreateAndStartAnomalyDetectorResponse, AWSError>;
  /**
   * 
   */
  createAndStartAnomalyDetector(callback?: (err: AWSError, data: IotBifrostMLOrchestratorLambda.Types.CreateAndStartAnomalyDetectorResponse) => void): Request<IotBifrostMLOrchestratorLambda.Types.CreateAndStartAnomalyDetectorResponse, AWSError>;
  /**
   * 
   */
  describeAnomalyDetector(params: IotBifrostMLOrchestratorLambda.Types.DescribeAnomalyDetectorRequest, callback?: (err: AWSError, data: IotBifrostMLOrchestratorLambda.Types.DescribeAnomalyDetectorResponse) => void): Request<IotBifrostMLOrchestratorLambda.Types.DescribeAnomalyDetectorResponse, AWSError>;
  /**
   * 
   */
  describeAnomalyDetector(callback?: (err: AWSError, data: IotBifrostMLOrchestratorLambda.Types.DescribeAnomalyDetectorResponse) => void): Request<IotBifrostMLOrchestratorLambda.Types.DescribeAnomalyDetectorResponse, AWSError>;
}
declare namespace IotBifrostMLOrchestratorLambda {
  export type AnomalyDetectorARN = string;
  export type AnomalyDetectorName = string;
  export interface AssetProperty {
    assetId?: NonEmptyString;
    propertyId: NonEmptyString;
    propertyName: NonEmptyString;
  }
  export interface CreateAndStartAnomalyDetectorRequest {
    detectorId: DetectorId;
    anomalyDetectorName: AnomalyDetectorName;
    sitewiseSourceConfig: SitewiseConfig;
    mlServiceConfig: MLServiceConfig;
  }
  export interface CreateAndStartAnomalyDetectorResponse {
    detectorId?: DetectorId;
    detectorStatus?: DetectorStatus;
    anomalyDetectorName?: AnomalyDetectorName;
    anomalyDetectorARN?: AnomalyDetectorARN;
    failureReason?: FailureReason;
  }
  export type DataIngestionDelay = number;
  export interface DataIngestionLocation {
    s3DataSource: S3DataSource;
  }
  export interface DescribeAnomalyDetectorRequest {
    detectorId: DetectorId;
  }
  export interface DescribeAnomalyDetectorResponse {
    anomalyDetectorName?: AnomalyDetectorName;
    detectorId?: DetectorId;
    detectorStatus?: DetectorStatus;
    description?: Description;
    dataUploadFrequency?: Frequency;
    failureReason?: FailureReason;
    s3RoleArn?: RoleArn;
    mlServiceRoleArn?: RoleArn;
    creationTime?: EpochMilliseconds;
    lastModificationTime?: EpochMilliseconds;
    anomalyDetectorARN?: AnomalyDetectorARN;
    propertyId?: NonEmptyString;
    propertyName?: NonEmptyString;
    s3DataSource?: S3DataSource;
  }
  export type Description = string;
  export type DetectorId = string;
  export type DetectorStatus = "ACTIVE"|"ACTIVATING"|"INACTIVE"|"FAILED"|"DELETED"|"LEARNING"|string;
  export type EpochMilliseconds = number;
  export type FailureReason = string;
  export type Frequency = "P1D"|"PT1H"|"PT10M"|"PT5M"|string;
  export interface L4MServiceConfig {
    timeZone?: TimeZone;
    dataIngestionDelay?: DataIngestionDelay;
    dataUploadFrequency: Frequency;
    dataIngestionLocation: DataIngestionLocation;
    roleConfiguration: RoleConfiguration;
    description?: Description;
  }
  export interface MLServiceConfig {
    l4MServiceConfig?: L4MServiceConfig;
  }
  export type NonEmptyString = string;
  export type RoleArn = string;
  export interface RoleConfiguration {
    roleArn: RoleArn;
    s3RoleArn: RoleArn;
  }
  export type S3Bucket = string;
  export interface S3DataSource {
    bucket: S3Bucket;
    keyPrefix: S3Prefix;
  }
  export type S3Prefix = string;
  export interface SitewiseConfig {
    modelId: NonEmptyString;
    modelName: NonEmptyString;
    assetProperty: AssetProperty;
  }
  export type TimeZone = string;
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2017-07-25"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the IotBifrostMLOrchestratorLambda client.
   */
  export import Types = IotBifrostMLOrchestratorLambda;
}
export = IotBifrostMLOrchestratorLambda;
