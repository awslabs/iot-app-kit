import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class AbeautifulandamazingIotBlackPearlConsoleLambda extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: AbeautifulandamazingIotBlackPearlConsoleLambda.Types.ClientConfiguration)
  config: Config & AbeautifulandamazingIotBlackPearlConsoleLambda.Types.ClientConfiguration;
  /**
   * CreatePresignedPortalUrl
   */
  createPresignedPortalUrl(params: AbeautifulandamazingIotBlackPearlConsoleLambda.Types.CreatePresignedPortalUrlInput, callback?: (err: AWSError, data: AbeautifulandamazingIotBlackPearlConsoleLambda.Types.CreatePresignedPortalUrlOutput) => void): Request<AbeautifulandamazingIotBlackPearlConsoleLambda.Types.CreatePresignedPortalUrlOutput, AWSError>;
  /**
   * CreatePresignedPortalUrl
   */
  createPresignedPortalUrl(callback?: (err: AWSError, data: AbeautifulandamazingIotBlackPearlConsoleLambda.Types.CreatePresignedPortalUrlOutput) => void): Request<AbeautifulandamazingIotBlackPearlConsoleLambda.Types.CreatePresignedPortalUrlOutput, AWSError>;
}
declare namespace AbeautifulandamazingIotBlackPearlConsoleLambda {
  export interface CreatePresignedPortalUrlInput {
    portalId: CreatePresignedPortalUrlInputPortalIdString;
    state: CreatePresignedPortalUrlInputStateString;
    sessionDurationSeconds?: CreatePresignedPortalUrlInputSessionDurationSecondsString;
  }
  export type CreatePresignedPortalUrlInputPortalIdString = string;
  export type CreatePresignedPortalUrlInputSessionDurationSecondsString = string;
  export type CreatePresignedPortalUrlInputStateString = string;
  export interface CreatePresignedPortalUrlOutput {
    presignedPortalUrl: CreatePresignedPortalUrlOutputPresignedPortalUrlString;
  }
  export type CreatePresignedPortalUrlOutputPresignedPortalUrlString = string;
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2018-05-10"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the AbeautifulandamazingIotBlackPearlConsoleLambda client.
   */
  export import Types = AbeautifulandamazingIotBlackPearlConsoleLambda;
}
export = AbeautifulandamazingIotBlackPearlConsoleLambda;
