import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class SUP extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: SUP.Types.ClientConfiguration)
  config: Config & SUP.Types.ClientConfiguration;
  /**
   * 
   */
  addMemberToGroup(params: SUP.Types.AddMemberToGroupRequest, callback?: (err: AWSError, data: SUP.Types.AddMemberToGroupResponse) => void): Request<SUP.Types.AddMemberToGroupResponse, AWSError>;
  /**
   * 
   */
  addMemberToGroup(callback?: (err: AWSError, data: SUP.Types.AddMemberToGroupResponse) => void): Request<SUP.Types.AddMemberToGroupResponse, AWSError>;
  /**
   * 
   */
  createAlias(params: SUP.Types.CreateAliasRequest, callback?: (err: AWSError, data: SUP.Types.CreateAliasResponse) => void): Request<SUP.Types.CreateAliasResponse, AWSError>;
  /**
   * 
   */
  createAlias(callback?: (err: AWSError, data: SUP.Types.CreateAliasResponse) => void): Request<SUP.Types.CreateAliasResponse, AWSError>;
  /**
   * 
   */
  createGroup(params: SUP.Types.CreateGroupRequest, callback?: (err: AWSError, data: SUP.Types.CreateGroupResponse) => void): Request<SUP.Types.CreateGroupResponse, AWSError>;
  /**
   * 
   */
  createGroup(callback?: (err: AWSError, data: SUP.Types.CreateGroupResponse) => void): Request<SUP.Types.CreateGroupResponse, AWSError>;
  /**
   * 
   */
  createUser(params: SUP.Types.CreateUserRequest, callback?: (err: AWSError, data: SUP.Types.CreateUserResponse) => void): Request<SUP.Types.CreateUserResponse, AWSError>;
  /**
   * 
   */
  createUser(callback?: (err: AWSError, data: SUP.Types.CreateUserResponse) => void): Request<SUP.Types.CreateUserResponse, AWSError>;
  /**
   * 
   */
  deleteGroup(params: SUP.Types.DeleteGroupRequest, callback?: (err: AWSError, data: SUP.Types.DeleteGroupResponse) => void): Request<SUP.Types.DeleteGroupResponse, AWSError>;
  /**
   * 
   */
  deleteGroup(callback?: (err: AWSError, data: SUP.Types.DeleteGroupResponse) => void): Request<SUP.Types.DeleteGroupResponse, AWSError>;
  /**
   * 
   */
  deleteUser(params: SUP.Types.DeleteUserRequest, callback?: (err: AWSError, data: SUP.Types.DeleteUserResponse) => void): Request<SUP.Types.DeleteUserResponse, AWSError>;
  /**
   * 
   */
  deleteUser(callback?: (err: AWSError, data: SUP.Types.DeleteUserResponse) => void): Request<SUP.Types.DeleteUserResponse, AWSError>;
  /**
   * 
   */
  describeGroups(params: SUP.Types.DescribeGroupsRequest, callback?: (err: AWSError, data: SUP.Types.DescribeGroupsResponse) => void): Request<SUP.Types.DescribeGroupsResponse, AWSError>;
  /**
   * 
   */
  describeGroups(callback?: (err: AWSError, data: SUP.Types.DescribeGroupsResponse) => void): Request<SUP.Types.DescribeGroupsResponse, AWSError>;
  /**
   * 
   */
  describeUsers(params: SUP.Types.DescribeUsersRequest, callback?: (err: AWSError, data: SUP.Types.DescribeUsersResponse) => void): Request<SUP.Types.DescribeUsersResponse, AWSError>;
  /**
   * 
   */
  describeUsers(callback?: (err: AWSError, data: SUP.Types.DescribeUsersResponse) => void): Request<SUP.Types.DescribeUsersResponse, AWSError>;
  /**
   * 
   */
  disableUser(params: SUP.Types.DisableUserRequest, callback?: (err: AWSError, data: SUP.Types.DisableUserResponse) => void): Request<SUP.Types.DisableUserResponse, AWSError>;
  /**
   * 
   */
  disableUser(callback?: (err: AWSError, data: SUP.Types.DisableUserResponse) => void): Request<SUP.Types.DisableUserResponse, AWSError>;
  /**
   * 
   */
  enableUser(params: SUP.Types.EnableUserRequest, callback?: (err: AWSError, data: SUP.Types.EnableUserResponse) => void): Request<SUP.Types.EnableUserResponse, AWSError>;
  /**
   * 
   */
  enableUser(callback?: (err: AWSError, data: SUP.Types.EnableUserResponse) => void): Request<SUP.Types.EnableUserResponse, AWSError>;
  /**
   * 
   */
  getUserPoolInfo(params: SUP.Types.GetUserPoolInfoRequest, callback?: (err: AWSError, data: SUP.Types.GetUserPoolInfoResponse) => void): Request<SUP.Types.GetUserPoolInfoResponse, AWSError>;
  /**
   * 
   */
  getUserPoolInfo(callback?: (err: AWSError, data: SUP.Types.GetUserPoolInfoResponse) => void): Request<SUP.Types.GetUserPoolInfoResponse, AWSError>;
  /**
   * 
   */
  listGroupsForUser(params: SUP.Types.ListGroupsForUserRequest, callback?: (err: AWSError, data: SUP.Types.ListGroupsForUserResponse) => void): Request<SUP.Types.ListGroupsForUserResponse, AWSError>;
  /**
   * 
   */
  listGroupsForUser(callback?: (err: AWSError, data: SUP.Types.ListGroupsForUserResponse) => void): Request<SUP.Types.ListGroupsForUserResponse, AWSError>;
  /**
   * 
   */
  listMembersInGroup(params: SUP.Types.ListMembersInGroupRequest, callback?: (err: AWSError, data: SUP.Types.ListMembersInGroupResponse) => void): Request<SUP.Types.ListMembersInGroupResponse, AWSError>;
  /**
   * 
   */
  listMembersInGroup(callback?: (err: AWSError, data: SUP.Types.ListMembersInGroupResponse) => void): Request<SUP.Types.ListMembersInGroupResponse, AWSError>;
  /**
   * 
   */
  removeMemberFromGroup(params: SUP.Types.RemoveMemberFromGroupRequest, callback?: (err: AWSError, data: SUP.Types.RemoveMemberFromGroupResponse) => void): Request<SUP.Types.RemoveMemberFromGroupResponse, AWSError>;
  /**
   * 
   */
  removeMemberFromGroup(callback?: (err: AWSError, data: SUP.Types.RemoveMemberFromGroupResponse) => void): Request<SUP.Types.RemoveMemberFromGroupResponse, AWSError>;
  /**
   * 
   */
  searchGroups(params: SUP.Types.SearchGroupsRequest, callback?: (err: AWSError, data: SUP.Types.SearchGroupsResponse) => void): Request<SUP.Types.SearchGroupsResponse, AWSError>;
  /**
   * 
   */
  searchGroups(callback?: (err: AWSError, data: SUP.Types.SearchGroupsResponse) => void): Request<SUP.Types.SearchGroupsResponse, AWSError>;
  /**
   * 
   */
  searchUsers(params: SUP.Types.SearchUsersRequest, callback?: (err: AWSError, data: SUP.Types.SearchUsersResponse) => void): Request<SUP.Types.SearchUsersResponse, AWSError>;
  /**
   * 
   */
  searchUsers(callback?: (err: AWSError, data: SUP.Types.SearchUsersResponse) => void): Request<SUP.Types.SearchUsersResponse, AWSError>;
  /**
   * 
   */
  updateGroup(params: SUP.Types.UpdateGroupRequest, callback?: (err: AWSError, data: SUP.Types.UpdateGroupResponse) => void): Request<SUP.Types.UpdateGroupResponse, AWSError>;
  /**
   * 
   */
  updateGroup(callback?: (err: AWSError, data: SUP.Types.UpdateGroupResponse) => void): Request<SUP.Types.UpdateGroupResponse, AWSError>;
  /**
   * 
   */
  updatePassword(params: SUP.Types.UpdatePasswordRequest, callback?: (err: AWSError, data: SUP.Types.UpdatePasswordResponse) => void): Request<SUP.Types.UpdatePasswordResponse, AWSError>;
  /**
   * 
   */
  updatePassword(callback?: (err: AWSError, data: SUP.Types.UpdatePasswordResponse) => void): Request<SUP.Types.UpdatePasswordResponse, AWSError>;
  /**
   * 
   */
  updateUser(params: SUP.Types.UpdateUserRequest, callback?: (err: AWSError, data: SUP.Types.UpdateUserResponse) => void): Request<SUP.Types.UpdateUserResponse, AWSError>;
  /**
   * 
   */
  updateUser(callback?: (err: AWSError, data: SUP.Types.UpdateUserResponse) => void): Request<SUP.Types.UpdateUserResponse, AWSError>;
  /**
   * 
   */
  verifyEmail(params: SUP.Types.VerifyEmailRequest, callback?: (err: AWSError, data: SUP.Types.VerifyEmailResponse) => void): Request<SUP.Types.VerifyEmailResponse, AWSError>;
  /**
   * 
   */
  verifyEmail(callback?: (err: AWSError, data: SUP.Types.VerifyEmailResponse) => void): Request<SUP.Types.VerifyEmailResponse, AWSError>;
}
declare namespace SUP {
  export interface AddMemberToGroupRequest {
    Member: Member;
    GroupId: GroupId;
  }
  export interface AddMemberToGroupResponse {
  }
  export interface AddressType {
    StreetAddress?: StringType;
    Region?: StringType;
    PostalCode?: StringType;
    Country?: StringType;
  }
  export type Addresses = AddressType[];
  export type Alias = string;
  export type AttributeName = string;
  export type BooleanType = boolean;
  export interface CreateAliasRequest {
    Alias: Alias;
  }
  export interface CreateAliasResponse {
  }
  export interface CreateGroupRequest {
    Description?: Description;
    GroupName: StringType;
  }
  export interface CreateGroupResponse {
    Group?: Group;
  }
  export interface CreateUserRequest {
    UserName: EmailId;
    Name: Name;
    DisplayName?: StringType;
    PreferredLanguage?: StringType;
    Emails: Emails;
    PhoneNumbers?: PhoneNumbers;
    Addresses?: Addresses;
    PasswordMode: PasswordMode;
    EmployeeNumber?: StringType;
    AdObjectGuid?: StringType;
    Notes?: StringType;
  }
  export interface CreateUserResponse {
    User?: User;
  }
  export interface DeleteGroupRequest {
    GroupId: GroupId;
  }
  export interface DeleteGroupResponse {
  }
  export interface DeleteUserRequest {
    UserId: UserId;
  }
  export interface DeleteUserResponse {
  }
  export interface DescribeGroupsRequest {
    GroupIds?: GroupIds;
    MaxResults?: MaxResults;
    NextToken?: MarkerType;
  }
  export interface DescribeGroupsResponse {
    Groups: Groups;
    NextToken?: MarkerType;
  }
  export interface DescribeUsersRequest {
    UserIds?: UserIds;
    MaxResults?: MaxResults;
    NextToken?: MarkerType;
  }
  export interface DescribeUsersResponse {
    Users: Users;
    NextToken?: MarkerType;
  }
  export type Description = string;
  export type DirectoryId = string;
  export type DirectoryType = string;
  export interface DisableUserRequest {
    UserId: UserId;
  }
  export interface DisableUserResponse {
  }
  export type EmailId = string;
  export interface EmailInfo {
    Email?: EmailId;
    Status?: EmailStatus;
  }
  export type EmailStatus = "Verified"|"Not_Verified"|string;
  export type Emails = EmailId[];
  export type EmailsInfo = EmailInfo[];
  export interface EnableUserRequest {
    UserId: UserId;
  }
  export interface EnableUserResponse {
  }
  export interface GetUserPoolInfoRequest {
    DirectoryId?: DirectoryId;
  }
  export interface GetUserPoolInfoResponse {
    Alias?: Alias;
    DirectoryId?: DirectoryId;
    MigrationStatus?: MigrationStatus;
    DirectoryType?: DirectoryType;
  }
  export interface Group {
    GroupId: GroupId;
    Description?: StringType;
    GroupName?: StringType;
  }
  export type GroupId = string;
  export type GroupIds = GroupId[];
  export type Groups = Group[];
  export type IdType = string;
  export interface ListGroupsForUserRequest {
    UserId: UserId;
    MaxResults?: MaxResults;
    GroupAttributes?: SearchAttributes;
    NextToken?: MarkerType;
  }
  export interface ListGroupsForUserResponse {
    Groups: Groups;
    NextToken?: MarkerType;
  }
  export interface ListMembersInGroupRequest {
    GroupId: GroupId;
    MaxResults?: MaxResults;
    NextToken?: MarkerType;
  }
  export interface ListMembersInGroupResponse {
    Members: Members;
    NextToken?: MarkerType;
  }
  export type MarkerType = string;
  export type MaxResults = number;
  export interface Member {
    Id?: IdType;
    Type?: MemberType;
  }
  export type MemberType = "USER"|"GROUP"|string;
  export type Members = Member[];
  export type MigrationStatus = "NotMigrated"|"Migrating"|"Migrated"|"Failed"|string;
  export interface Name {
    GivenName: StringType;
    FamilyName: StringType;
    MiddleName?: StringType;
  }
  export interface OptionalAttribute {
    Value?: StringType;
    UpdateType?: UpdateType;
  }
  export type Password = string;
  export type PasswordMode = "OTP"|"EMAIL"|string;
  export type PhoneNumberType = string;
  export type PhoneNumbers = PhoneNumberType[];
  export interface RemoveMemberFromGroupRequest {
    Member: Member;
    GroupId: GroupId;
  }
  export interface RemoveMemberFromGroupResponse {
  }
  export interface RequiredAttribute {
    Value?: StringType;
  }
  export type SearchAttributes = AttributeName[];
  export interface SearchGroupsRequest {
    SearchString: SearchValue;
    MaxResults?: MaxResults;
    SearchAttributes?: SearchAttributes;
    NextToken?: MarkerType;
  }
  export interface SearchGroupsResponse {
    Groups: Groups;
    NextToken?: MarkerType;
  }
  export interface SearchUsersRequest {
    SearchString: SearchValue;
    SearchAttributes?: SearchAttributes;
    MaxResults?: MaxResults;
    NextToken?: MarkerType;
  }
  export interface SearchUsersResponse {
    Users: Users;
    NextToken?: MarkerType;
  }
  export type SearchValue = string;
  export type StringType = string;
  export interface UpdateAddressType {
    StreetAddress?: OptionalAttribute;
    Region?: OptionalAttribute;
    PostalCode?: OptionalAttribute;
    Country?: OptionalAttribute;
  }
  export type UpdateAddresses = UpdateAddressType[];
  export interface UpdateDescription {
    Value?: Description;
    UpdateType?: UpdateType;
  }
  export interface UpdateGroupRequest {
    GroupId: GroupId;
    Description?: UpdateDescription;
  }
  export interface UpdateGroupResponse {
  }
  export interface UpdateName {
    GivenName: RequiredAttribute;
    FamilyName: RequiredAttribute;
    MiddleName?: OptionalAttribute;
  }
  export interface UpdatePasswordRequest {
    UserId: UserId;
    PasswordMode: PasswordMode;
  }
  export interface UpdatePasswordResponse {
    Password?: Password;
  }
  export interface UpdatePhoneNumberType {
    Value?: PhoneNumberType;
    UpdateType?: UpdateType;
  }
  export type UpdatePhoneNumbers = UpdatePhoneNumberType[];
  export type UpdateType = "ADD_REPLACE"|"DELETE"|string;
  export interface UpdateUserRequest {
    UserId: UserId;
    Name?: UpdateName;
    DisplayName?: OptionalAttribute;
    PreferredLanguage?: OptionalAttribute;
    PhoneNumbers?: UpdatePhoneNumbers;
    Addresses?: UpdateAddresses;
    EmployeeNumber?: OptionalAttribute;
    AdObjectGuid?: OptionalAttribute;
    Notes?: OptionalAttribute;
  }
  export interface UpdateUserResponse {
  }
  export interface User {
    UserId: UserId;
    UserName: EmailId;
    Name: Name;
    DisplayName?: StringType;
    PreferredLanguage?: StringType;
    Active?: BooleanType;
    Emails?: Emails;
    PhoneNumbers?: PhoneNumbers;
    Addresses?: Addresses;
    Password?: Password;
    EmployeeNumber?: StringType;
    AdObjectGuid?: StringType;
    Notes?: StringType;
    EmailsInfo?: EmailsInfo;
  }
  export type UserId = string;
  export type UserIds = UserId[];
  export type Users = User[];
  export interface VerifyEmailRequest {
    UserId?: UserId;
    EmailId?: EmailId;
  }
  export interface VerifyEmailResponse {
  }
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2017-11-28"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the SUP client.
   */
  export import Types = SUP;
}
export = SUP;
