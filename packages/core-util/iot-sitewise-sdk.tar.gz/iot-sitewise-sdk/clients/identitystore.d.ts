import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class IdentityStore extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: IdentityStore.Types.ClientConfiguration)
  config: Config & IdentityStore.Types.ClientConfiguration;
  /**
   * Add a member to the target group.
   */
  addMemberToGroup(params: IdentityStore.Types.AddMemberToGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.AddMemberToGroupResponse) => void): Request<IdentityStore.Types.AddMemberToGroupResponse, AWSError>;
  /**
   * Add a member to the target group.
   */
  addMemberToGroup(callback?: (err: AWSError, data: IdentityStore.Types.AddMemberToGroupResponse) => void): Request<IdentityStore.Types.AddMemberToGroupResponse, AWSError>;
  /**
   * 
   */
  createBearerToken(params: IdentityStore.Types.CreateBearerTokenRequest, callback?: (err: AWSError, data: IdentityStore.Types.CreateBearerTokenResponse) => void): Request<IdentityStore.Types.CreateBearerTokenResponse, AWSError>;
  /**
   * 
   */
  createBearerToken(callback?: (err: AWSError, data: IdentityStore.Types.CreateBearerTokenResponse) => void): Request<IdentityStore.Types.CreateBearerTokenResponse, AWSError>;
  /**
   * Create an empty group.
   */
  createGroup(params: IdentityStore.Types.CreateGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.CreateGroupResponse) => void): Request<IdentityStore.Types.CreateGroupResponse, AWSError>;
  /**
   * Create an empty group.
   */
  createGroup(callback?: (err: AWSError, data: IdentityStore.Types.CreateGroupResponse) => void): Request<IdentityStore.Types.CreateGroupResponse, AWSError>;
  /**
   * API to create a provision tenant for directory. LimitExceededException: Currently we are limiting the number of provision sources to be only one. So, LimitExceededException will be thrown if client tries to create a new provision source for a directory which already has a source. ResourceNotFoundException: Thrown when the provided directoryId does not exists.
   */
  createProvisioningTenant(params: IdentityStore.Types.CreateProvisioningTenantRequest, callback?: (err: AWSError, data: IdentityStore.Types.CreateProvisioningTenantResponse) => void): Request<IdentityStore.Types.CreateProvisioningTenantResponse, AWSError>;
  /**
   * API to create a provision tenant for directory. LimitExceededException: Currently we are limiting the number of provision sources to be only one. So, LimitExceededException will be thrown if client tries to create a new provision source for a directory which already has a source. ResourceNotFoundException: Thrown when the provided directoryId does not exists.
   */
  createProvisioningTenant(callback?: (err: AWSError, data: IdentityStore.Types.CreateProvisioningTenantResponse) => void): Request<IdentityStore.Types.CreateProvisioningTenantResponse, AWSError>;
  /**
   * 
   */
  createUser(params: IdentityStore.Types.CreateUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.CreateUserResponse) => void): Request<IdentityStore.Types.CreateUserResponse, AWSError>;
  /**
   * 
   */
  createUser(callback?: (err: AWSError, data: IdentityStore.Types.CreateUserResponse) => void): Request<IdentityStore.Types.CreateUserResponse, AWSError>;
  /**
   * 
   */
  deleteBearerToken(params: IdentityStore.Types.DeleteBearerTokenRequest, callback?: (err: AWSError, data: IdentityStore.Types.DeleteBearerTokenResponse) => void): Request<IdentityStore.Types.DeleteBearerTokenResponse, AWSError>;
  /**
   * 
   */
  deleteBearerToken(callback?: (err: AWSError, data: IdentityStore.Types.DeleteBearerTokenResponse) => void): Request<IdentityStore.Types.DeleteBearerTokenResponse, AWSError>;
  /**
   * Delete the target group.
   */
  deleteGroup(params: IdentityStore.Types.DeleteGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.DeleteGroupResponse) => void): Request<IdentityStore.Types.DeleteGroupResponse, AWSError>;
  /**
   * Delete the target group.
   */
  deleteGroup(callback?: (err: AWSError, data: IdentityStore.Types.DeleteGroupResponse) => void): Request<IdentityStore.Types.DeleteGroupResponse, AWSError>;
  /**
   * 
   */
  deleteProvisioningTenant(params: IdentityStore.Types.DeleteProvisioningTenantRequest, callback?: (err: AWSError, data: IdentityStore.Types.DeleteProvisioningTenantResponse) => void): Request<IdentityStore.Types.DeleteProvisioningTenantResponse, AWSError>;
  /**
   * 
   */
  deleteProvisioningTenant(callback?: (err: AWSError, data: IdentityStore.Types.DeleteProvisioningTenantResponse) => void): Request<IdentityStore.Types.DeleteProvisioningTenantResponse, AWSError>;
  /**
   * 
   */
  deleteUser(params: IdentityStore.Types.DeleteUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.DeleteUserResponse) => void): Request<IdentityStore.Types.DeleteUserResponse, AWSError>;
  /**
   * 
   */
  deleteUser(callback?: (err: AWSError, data: IdentityStore.Types.DeleteUserResponse) => void): Request<IdentityStore.Types.DeleteUserResponse, AWSError>;
  /**
   * Query the group data, not including user and group members.
   */
  describeGroup(params: IdentityStore.Types.DescribeGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.DescribeGroupResponse) => void): Request<IdentityStore.Types.DescribeGroupResponse, AWSError>;
  /**
   * Query the group data, not including user and group members.
   */
  describeGroup(callback?: (err: AWSError, data: IdentityStore.Types.DescribeGroupResponse) => void): Request<IdentityStore.Types.DescribeGroupResponse, AWSError>;
  /**
   * 
   */
  describeGroups(params: IdentityStore.Types.DescribeGroupsRequest, callback?: (err: AWSError, data: IdentityStore.Types.DescribeGroupsResponse) => void): Request<IdentityStore.Types.DescribeGroupsResponse, AWSError>;
  /**
   * 
   */
  describeGroups(callback?: (err: AWSError, data: IdentityStore.Types.DescribeGroupsResponse) => void): Request<IdentityStore.Types.DescribeGroupsResponse, AWSError>;
  /**
   * 
   */
  describeProvisioningTenant(params: IdentityStore.Types.DescribeProvisioningTenantRequest, callback?: (err: AWSError, data: IdentityStore.Types.DescribeProvisioningTenantResponse) => void): Request<IdentityStore.Types.DescribeProvisioningTenantResponse, AWSError>;
  /**
   * 
   */
  describeProvisioningTenant(callback?: (err: AWSError, data: IdentityStore.Types.DescribeProvisioningTenantResponse) => void): Request<IdentityStore.Types.DescribeProvisioningTenantResponse, AWSError>;
  /**
   * 
   */
  describeUser(params: IdentityStore.Types.DescribeUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.DescribeUserResponse) => void): Request<IdentityStore.Types.DescribeUserResponse, AWSError>;
  /**
   * 
   */
  describeUser(callback?: (err: AWSError, data: IdentityStore.Types.DescribeUserResponse) => void): Request<IdentityStore.Types.DescribeUserResponse, AWSError>;
  /**
   * 
   */
  describeUsers(params: IdentityStore.Types.DescribeUsersRequest, callback?: (err: AWSError, data: IdentityStore.Types.DescribeUsersResponse) => void): Request<IdentityStore.Types.DescribeUsersResponse, AWSError>;
  /**
   * 
   */
  describeUsers(callback?: (err: AWSError, data: IdentityStore.Types.DescribeUsersResponse) => void): Request<IdentityStore.Types.DescribeUsersResponse, AWSError>;
  /**
   * 
   */
  disableUser(params: IdentityStore.Types.DisableUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.DisableUserResponse) => void): Request<IdentityStore.Types.DisableUserResponse, AWSError>;
  /**
   * 
   */
  disableUser(callback?: (err: AWSError, data: IdentityStore.Types.DisableUserResponse) => void): Request<IdentityStore.Types.DisableUserResponse, AWSError>;
  /**
   * 
   */
  enableUser(params: IdentityStore.Types.EnableUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.EnableUserResponse) => void): Request<IdentityStore.Types.EnableUserResponse, AWSError>;
  /**
   * 
   */
  enableUser(callback?: (err: AWSError, data: IdentityStore.Types.EnableUserResponse) => void): Request<IdentityStore.Types.EnableUserResponse, AWSError>;
  /**
   * 
   */
  isMemberInGroup(params: IdentityStore.Types.IsMemberInGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.IsMemberInGroupResponse) => void): Request<IdentityStore.Types.IsMemberInGroupResponse, AWSError>;
  /**
   * 
   */
  isMemberInGroup(callback?: (err: AWSError, data: IdentityStore.Types.IsMemberInGroupResponse) => void): Request<IdentityStore.Types.IsMemberInGroupResponse, AWSError>;
  /**
   * 
   */
  listBearerTokens(params: IdentityStore.Types.ListBearerTokensRequest, callback?: (err: AWSError, data: IdentityStore.Types.ListBearerTokensResponse) => void): Request<IdentityStore.Types.ListBearerTokensResponse, AWSError>;
  /**
   * 
   */
  listBearerTokens(callback?: (err: AWSError, data: IdentityStore.Types.ListBearerTokensResponse) => void): Request<IdentityStore.Types.ListBearerTokensResponse, AWSError>;
  /**
   * List groups of the target member, including the top level only. For example, User1 -> Group1, Group1 -> Group2. The result of User1 only return Group1, not including Group2.
   */
  listGroupsForMember(params: IdentityStore.Types.ListGroupsForMemberRequest, callback?: (err: AWSError, data: IdentityStore.Types.ListGroupsForMemberResponse) => void): Request<IdentityStore.Types.ListGroupsForMemberResponse, AWSError>;
  /**
   * List groups of the target member, including the top level only. For example, User1 -> Group1, Group1 -> Group2. The result of User1 only return Group1, not including Group2.
   */
  listGroupsForMember(callback?: (err: AWSError, data: IdentityStore.Types.ListGroupsForMemberResponse) => void): Request<IdentityStore.Types.ListGroupsForMemberResponse, AWSError>;
  /**
   * 
   */
  listGroupsForUser(params: IdentityStore.Types.ListGroupsForUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.ListGroupsForUserResponse) => void): Request<IdentityStore.Types.ListGroupsForUserResponse, AWSError>;
  /**
   * 
   */
  listGroupsForUser(callback?: (err: AWSError, data: IdentityStore.Types.ListGroupsForUserResponse) => void): Request<IdentityStore.Types.ListGroupsForUserResponse, AWSError>;
  /**
   * List all the members in the target group, including top level only. For example, User1 -> Group1, Group2 -> Group1, User2 -> Group2. The result of Group1 return User1 and Group2, not including User2.
   */
  listMembersInGroup(params: IdentityStore.Types.ListMembersInGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.ListMembersInGroupResponse) => void): Request<IdentityStore.Types.ListMembersInGroupResponse, AWSError>;
  /**
   * List all the members in the target group, including top level only. For example, User1 -> Group1, Group2 -> Group1, User2 -> Group2. The result of Group1 return User1 and Group2, not including User2.
   */
  listMembersInGroup(callback?: (err: AWSError, data: IdentityStore.Types.ListMembersInGroupResponse) => void): Request<IdentityStore.Types.ListMembersInGroupResponse, AWSError>;
  /**
   * 
   */
  listProvisioningTenants(params: IdentityStore.Types.ListProvisioningTenantsRequest, callback?: (err: AWSError, data: IdentityStore.Types.ListProvisioningTenantsResponse) => void): Request<IdentityStore.Types.ListProvisioningTenantsResponse, AWSError>;
  /**
   * 
   */
  listProvisioningTenants(callback?: (err: AWSError, data: IdentityStore.Types.ListProvisioningTenantsResponse) => void): Request<IdentityStore.Types.ListProvisioningTenantsResponse, AWSError>;
  /**
   * Remove a member from the group.
   */
  removeMemberFromGroup(params: IdentityStore.Types.RemoveMemberFromGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.RemoveMemberFromGroupResponse) => void): Request<IdentityStore.Types.RemoveMemberFromGroupResponse, AWSError>;
  /**
   * Remove a member from the group.
   */
  removeMemberFromGroup(callback?: (err: AWSError, data: IdentityStore.Types.RemoveMemberFromGroupResponse) => void): Request<IdentityStore.Types.RemoveMemberFromGroupResponse, AWSError>;
  /**
   * 
   */
  searchGroups(params: IdentityStore.Types.SearchGroupsRequest, callback?: (err: AWSError, data: IdentityStore.Types.SearchGroupsResponse) => void): Request<IdentityStore.Types.SearchGroupsResponse, AWSError>;
  /**
   * 
   */
  searchGroups(callback?: (err: AWSError, data: IdentityStore.Types.SearchGroupsResponse) => void): Request<IdentityStore.Types.SearchGroupsResponse, AWSError>;
  /**
   * 
   */
  searchUsers(params: IdentityStore.Types.SearchUsersRequest, callback?: (err: AWSError, data: IdentityStore.Types.SearchUsersResponse) => void): Request<IdentityStore.Types.SearchUsersResponse, AWSError>;
  /**
   * 
   */
  searchUsers(callback?: (err: AWSError, data: IdentityStore.Types.SearchUsersResponse) => void): Request<IdentityStore.Types.SearchUsersResponse, AWSError>;
  /**
   * 
   */
  updateGroup(params: IdentityStore.Types.UpdateGroupRequest, callback?: (err: AWSError, data: IdentityStore.Types.UpdateGroupResponse) => void): Request<IdentityStore.Types.UpdateGroupResponse, AWSError>;
  /**
   * 
   */
  updateGroup(callback?: (err: AWSError, data: IdentityStore.Types.UpdateGroupResponse) => void): Request<IdentityStore.Types.UpdateGroupResponse, AWSError>;
  /**
   * 
   */
  updateGroupDisplayName(params: IdentityStore.Types.UpdateGroupDisplayNameRequest, callback?: (err: AWSError, data: IdentityStore.Types.UpdateGroupDisplayNameResponse) => void): Request<IdentityStore.Types.UpdateGroupDisplayNameResponse, AWSError>;
  /**
   * 
   */
  updateGroupDisplayName(callback?: (err: AWSError, data: IdentityStore.Types.UpdateGroupDisplayNameResponse) => void): Request<IdentityStore.Types.UpdateGroupDisplayNameResponse, AWSError>;
  /**
   * 
   */
  updateUser(params: IdentityStore.Types.UpdateUserRequest, callback?: (err: AWSError, data: IdentityStore.Types.UpdateUserResponse) => void): Request<IdentityStore.Types.UpdateUserResponse, AWSError>;
  /**
   * 
   */
  updateUser(callback?: (err: AWSError, data: IdentityStore.Types.UpdateUserResponse) => void): Request<IdentityStore.Types.UpdateUserResponse, AWSError>;
  /**
   * 
   */
  updateUserName(params: IdentityStore.Types.UpdateUserNameRequest, callback?: (err: AWSError, data: IdentityStore.Types.UpdateUserNameResponse) => void): Request<IdentityStore.Types.UpdateUserNameResponse, AWSError>;
  /**
   * 
   */
  updateUserName(callback?: (err: AWSError, data: IdentityStore.Types.UpdateUserNameResponse) => void): Request<IdentityStore.Types.UpdateUserNameResponse, AWSError>;
}
declare namespace IdentityStore {
  export interface AddMemberToGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    Member: MemberToAdd;
  }
  export interface AddMemberToGroupResponse {
  }
  export type AttributeMap = {[key: string]: AttributeValue};
  export type AttributeName = string;
  export type AttributePath = string;
  export interface AttributeValue {
    StringValue?: SensitiveStringType;
    BooleanValue?: SensitiveBooleanType;
    NumberValue?: SensitiveLongType;
    BinaryValue?: SensitiveBlobType;
    DecimalValue?: SensitiveBigDecimalType;
    DateTimeValue?: SensitiveDateType;
    ComplexValue?: AttributeMap;
    StringListValue?: MultiValuedStringAttributeValue;
    NumberListValue?: MultiValuedNumberAttributeValue;
    BinaryListValue?: MultiValuedBinaryAttributeValue;
    DecimalListValue?: MultiValuedDecimalAttributeValue;
    DateTimeListValue?: MultiValuedDateTimeAttributeValue;
    ComplexListValue?: MultiValuedComplexAttributeValue;
  }
  export interface BearerToken {
    TokenId?: BearerTokenId;
    Token?: Token;
    CreationTime?: DateType;
    ExpirationTime?: DateType;
  }
  export type BearerTokenId = string;
  export type BearerTokenList = BearerToken[];
  export type BooleanType = boolean;
  export type ComparisonOperator = "EQ"|"BEGINS_WITH"|string;
  export type ConditionOperator = "AND"|"OR"|string;
  export interface CreateBearerTokenRequest {
    IdentityStoreId: IdentityStoreId;
    TenantId: TenantId;
  }
  export interface CreateBearerTokenResponse {
    BearerToken: BearerToken;
  }
  export interface CreateGroupRequest {
    IdentityStoreId: IdentityStoreId;
    DisplayName: GroupDisplayName;
    GroupAttributes?: AttributeMap;
  }
  export interface CreateGroupResponse {
    Group: Group;
  }
  export interface CreateProvisioningTenantRequest {
    IdentityStoreId: IdentityStoreId;
  }
  export interface CreateProvisioningTenantResponse {
    ProvisioningTenant?: ProvisioningTenant;
  }
  export interface CreateUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserName: UserName;
    PasswordMode?: PasswordMode;
    Active: BooleanType;
    UserAttributes?: AttributeMap;
  }
  export interface CreateUserResponse {
    User: User;
    Password?: Password;
  }
  export type DateType = Date;
  export interface DeleteBearerTokenRequest {
    IdentityStoreId: IdentityStoreId;
    TenantId: TenantId;
    TokenId: BearerTokenId;
  }
  export interface DeleteBearerTokenResponse {
  }
  export interface DeleteGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
  }
  export interface DeleteGroupResponse {
  }
  export interface DeleteProvisioningTenantRequest {
    TenantId: TenantId;
    IdentityStoreId: IdentityStoreId;
  }
  export interface DeleteProvisioningTenantResponse {
  }
  export interface DeleteUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
  }
  export interface DeleteUserResponse {
  }
  export interface DescribeGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
  }
  export interface DescribeGroupResponse {
    Group: Group;
  }
  export interface DescribeGroupsRequest {
    IdentityStoreId: IdentityStoreId;
    GroupIds: ResourceIds;
  }
  export interface DescribeGroupsResponse {
    Groups: Groups;
    UnprocessedGroupIds?: ResourceIds;
  }
  export interface DescribeProvisioningTenantRequest {
    TenantId: TenantId;
    IdentityStoreId: IdentityStoreId;
  }
  export interface DescribeProvisioningTenantResponse {
    ProvisioningTenant?: ProvisioningTenant;
  }
  export interface DescribeUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
  }
  export interface DescribeUserResponse {
    User: User;
  }
  export interface DescribeUsersRequest {
    IdentityStoreId: IdentityStoreId;
    UserIds: ResourceIds;
  }
  export interface DescribeUsersResponse {
    Users: Users;
    UnprocessedUserIds?: ResourceIds;
  }
  export interface DisableUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
  }
  export interface DisableUserResponse {
  }
  export interface EnableUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
  }
  export interface EnableUserResponse {
  }
  export interface Filter {
    ComparisonOperator: ComparisonOperator;
    AttributePath: AttributePath;
    AttributeValue: AttributeValue;
  }
  export type Filters = Filter[];
  export interface Group {
    GroupId: ResourceId;
    DisplayName: GroupDisplayName;
    GroupAttributes?: AttributeMap;
    Meta?: Meta;
  }
  export type GroupDisplayName = string;
  export type Groups = Group[];
  export type IdentityStoreId = string;
  export interface IsMemberInGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    MemberId: ResourceId;
  }
  export interface IsMemberInGroupResponse {
    Result: BooleanType;
  }
  export interface ListBearerTokensRequest {
    IdentityStoreId: IdentityStoreId;
    TenantId: TenantId;
  }
  export interface ListBearerTokensResponse {
    BearerTokens: BearerTokenList;
  }
  export interface ListGroupsForMemberRequest {
    IdentityStoreId: IdentityStoreId;
    MemberId: ResourceId;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListGroupsForMemberResponse {
    MemberId: ResourceId;
    Groups: Groups;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListGroupsForUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListGroupsForUserResponse {
    UserId: ResourceId;
    Groups: Groups;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListMembersInGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListMembersInGroupResponse {
    GroupId: ResourceId;
    Members: Members;
    NextToken?: NextToken;
    MaxResults?: MaxResults;
  }
  export interface ListProvisioningTenantsRequest {
    IdentityStoreId: IdentityStoreId;
  }
  export interface ListProvisioningTenantsResponse {
    ProvisioningTenants?: ProvisioningTenants;
  }
  export type LongType = number;
  export type MaxResults = number;
  export interface Member {
    MemberId: ResourceId;
    MemberType: ResourceType;
    Meta?: Meta;
  }
  export interface MemberToAdd {
    MemberId: ResourceId;
  }
  export type Members = Member[];
  export interface Meta {
    CreatedAt?: DateType;
    UpdatedAt?: DateType;
    CreatedBy?: StringType;
    UpdatedBy?: StringType;
  }
  export type MultiValuedBinaryAttributeValue = SensitiveBlobType[];
  export type MultiValuedComplexAttributeValue = AttributeMap[];
  export type MultiValuedDateTimeAttributeValue = SensitiveDateType[];
  export type MultiValuedDecimalAttributeValue = SensitiveBigDecimalType[];
  export type MultiValuedNumberAttributeValue = SensitiveLongType[];
  export type MultiValuedStringAttributeValue = SensitiveStringType[];
  export type NextToken = string;
  export interface Operation {
    OperationType: OperationType;
    UpdateAttributes: AttributeMap;
  }
  export type OperationType = "ADD"|"REMOVE"|"REPLACE"|string;
  export type Operations = Operation[];
  export type Password = string;
  export type PasswordMode = "OTP"|"EMAIL"|string;
  export interface ProvisioningTenant {
    TenantId?: TenantId;
    ScimEndpoint?: StringType;
    CreationTime?: DateType;
  }
  export type ProvisioningTenants = ProvisioningTenant[];
  export interface RemoveMemberFromGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    MemberId: ResourceId;
  }
  export interface RemoveMemberFromGroupResponse {
  }
  export type ResourceId = string;
  export type ResourceIds = ResourceId[];
  export type ResourceType = "MEMBER"|"GROUP"|"USER"|"PROVISIONING_TENANT"|"BEARER_TOKEN"|"IDENTITY_STORE"|string;
  export interface SearchGroupsRequest {
    IdentityStoreId: IdentityStoreId;
    MaxResults?: MaxResults;
    NextToken?: NextToken;
    ConditionOperator?: ConditionOperator;
    Filters?: Filters;
  }
  export interface SearchGroupsResponse {
    Groups: Groups;
    NextToken?: NextToken;
    TotalGroupCount?: LongType;
  }
  export interface SearchUsersRequest {
    IdentityStoreId: IdentityStoreId;
    MaxResults?: MaxResults;
    NextToken?: NextToken;
    ConditionOperator?: ConditionOperator;
    Filters?: Filters;
  }
  export interface SearchUsersResponse {
    Users: Users;
    NextToken?: NextToken;
    TotalUserCount?: LongType;
  }
  export type SensitiveBigDecimalType = number;
  export type SensitiveBlobType = Buffer|Uint8Array|Blob|string;
  export type SensitiveBooleanType = boolean;
  export type SensitiveDateType = Date;
  export type SensitiveLongType = number;
  export type SensitiveStringType = string;
  export type StringType = string;
  export type TenantId = string;
  export type Token = string;
  export interface UpdateGroupDisplayNameRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    DisplayName: GroupDisplayName;
  }
  export interface UpdateGroupDisplayNameResponse {
  }
  export interface UpdateGroupRequest {
    IdentityStoreId: IdentityStoreId;
    GroupId: ResourceId;
    Operations: Operations;
  }
  export interface UpdateGroupResponse {
    Group: Group;
  }
  export interface UpdateUserNameRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
    UserName: UserName;
  }
  export interface UpdateUserNameResponse {
  }
  export interface UpdateUserRequest {
    IdentityStoreId: IdentityStoreId;
    UserId: ResourceId;
    Operations: Operations;
  }
  export interface UpdateUserResponse {
    User: User;
  }
  export interface User {
    UserName: UserName;
    UserId: ResourceId;
    UserAttributes?: AttributeMap;
    Active?: BooleanType;
    Meta?: Meta;
  }
  export type UserName = string;
  export type Users = User[];
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2019-11-01"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the IdentityStore client.
   */
  export import Types = IdentityStore;
}
export = IdentityStore;
