import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class SUPRest extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: SUPRest.Types.ClientConfiguration)
  config: Config & SUPRest.Types.ClientConfiguration;
  /**
   * 
   */
  validateToken(params: SUPRest.Types.Token, callback?: (err: AWSError, data: SUPRest.Types.ValidateTokenResponse) => void): Request<SUPRest.Types.ValidateTokenResponse, AWSError>;
  /**
   * 
   */
  validateToken(callback?: (err: AWSError, data: SUPRest.Types.ValidateTokenResponse) => void): Request<SUPRest.Types.ValidateTokenResponse, AWSError>;
  /**
   * 
   */
  validateTokenOptionsMethod(callback?: (err: AWSError, data: SUPRest.Types.ValidateTokenOptionsMethodResponse) => void): Request<SUPRest.Types.ValidateTokenOptionsMethodResponse, AWSError>;
}
declare namespace SUPRest {
  export type AllowHeaders = string;
  export type AllowOriginHeader = string;
  export interface Token {
    id: string;
  }
  export interface ValidateTokenOptionsMethodResponse {
    allow_origin_header: AllowOriginHeader;
    allow_headers: AllowHeaders;
  }
  export interface ValidateTokenResponse {
    allow_origin_header: AllowOriginHeader;
  }
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2018-11-01"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the SUPRest client.
   */
  export import Types = SUPRest;
}
export = SUPRest;
