import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
interface Blob {}
declare class SSOInternal extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: SSOInternal.Types.ClientConfiguration)
  config: Config & SSOInternal.Types.ClientConfiguration;
  /**
   * Assocaite a Directory to CloudSSO.
   */
  associateDirectory(params: SSOInternal.Types.AssociateDirectoryRequest, callback?: (err: AWSError, data: SSOInternal.Types.AssociateDirectoryResponse) => void): Request<SSOInternal.Types.AssociateDirectoryResponse, AWSError>;
  /**
   * Assocaite a Directory to CloudSSO.
   */
  associateDirectory(callback?: (err: AWSError, data: SSOInternal.Types.AssociateDirectoryResponse) => void): Request<SSOInternal.Types.AssociateDirectoryResponse, AWSError>;
  /**
   * Create an assignment between a User/Group acessor and AppInstance.
   */
  associateProfile(params: SSOInternal.Types.AssociateProfileRequest, callback?: (err: AWSError, data: SSOInternal.Types.AssociateProfileResponse) => void): Request<SSOInternal.Types.AssociateProfileResponse, AWSError>;
  /**
   * Create an assignment between a User/Group acessor and AppInstance.
   */
  associateProfile(callback?: (err: AWSError, data: SSOInternal.Types.AssociateProfileResponse) => void): Request<SSOInternal.Types.AssociateProfileResponse, AWSError>;
  /**
   * Attaches an AMP to the permission set
   */
  attachManagedPolicy(params: SSOInternal.Types.AttachManagedPolicyRequest, callback?: (err: AWSError, data: SSOInternal.Types.AttachManagedPolicyResponse) => void): Request<SSOInternal.Types.AttachManagedPolicyResponse, AWSError>;
  /**
   * Attaches an AMP to the permission set
   */
  attachManagedPolicy(callback?: (err: AWSError, data: SSOInternal.Types.AttachManagedPolicyResponse) => void): Request<SSOInternal.Types.AttachManagedPolicyResponse, AWSError>;
  /**
   * Create an ApplicationInstance.
   */
  createApplicationInstance(params: SSOInternal.Types.CreateApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.CreateApplicationInstanceResponse) => void): Request<SSOInternal.Types.CreateApplicationInstanceResponse, AWSError>;
  /**
   * Create an ApplicationInstance.
   */
  createApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.CreateApplicationInstanceResponse) => void): Request<SSOInternal.Types.CreateApplicationInstanceResponse, AWSError>;
  /**
   * Create Application Instance Certificate.
   */
  createApplicationInstanceCertificate(params: SSOInternal.Types.CreateApplicationInstanceCertificateRequest, callback?: (err: AWSError, data: SSOInternal.Types.CreateApplicationInstanceCertificateResponse) => void): Request<SSOInternal.Types.CreateApplicationInstanceCertificateResponse, AWSError>;
  /**
   * Create Application Instance Certificate.
   */
  createApplicationInstanceCertificate(callback?: (err: AWSError, data: SSOInternal.Types.CreateApplicationInstanceCertificateResponse) => void): Request<SSOInternal.Types.CreateApplicationInstanceCertificateResponse, AWSError>;
  /**
   * Create an Managed ApplicationInstance.
   */
  createManagedApplicationInstance(params: SSOInternal.Types.CreateManagedApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.CreateManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.CreateManagedApplicationInstanceResponse, AWSError>;
  /**
   * Create an Managed ApplicationInstance.
   */
  createManagedApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.CreateManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.CreateManagedApplicationInstanceResponse, AWSError>;
  /**
   * Creates a Permission Set
   */
  createPermissionSet(params: SSOInternal.Types.CreatePermissionSetRequest, callback?: (err: AWSError, data: SSOInternal.Types.CreatePermissionSetResponse) => void): Request<SSOInternal.Types.CreatePermissionSetResponse, AWSError>;
  /**
   * Creates a Permission Set
   */
  createPermissionSet(callback?: (err: AWSError, data: SSOInternal.Types.CreatePermissionSetResponse) => void): Request<SSOInternal.Types.CreatePermissionSetResponse, AWSError>;
  /**
   * Create Application Profile for a given Application.
   */
  createProfile(params: SSOInternal.Types.CreateProfileRequest, callback?: (err: AWSError, data: SSOInternal.Types.CreateProfileResponse) => void): Request<SSOInternal.Types.CreateProfileResponse, AWSError>;
  /**
   * Create Application Profile for a given Application.
   */
  createProfile(callback?: (err: AWSError, data: SSOInternal.Types.CreateProfileResponse) => void): Request<SSOInternal.Types.CreateProfileResponse, AWSError>;
  /**
   * Delete an ApplicationInstance.
   */
  deleteApplicationInstance(params: SSOInternal.Types.DeleteApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceResponse, AWSError>;
  /**
   * Delete an ApplicationInstance.
   */
  deleteApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceResponse, AWSError>;
  /**
   * Delete an Application Instance Certificate.
   */
  deleteApplicationInstanceCertificate(params: SSOInternal.Types.DeleteApplicationInstanceCertificateRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceCertificateResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceCertificateResponse, AWSError>;
  /**
   * Delete an Application Instance Certificate.
   */
  deleteApplicationInstanceCertificate(callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceCertificateResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceCertificateResponse, AWSError>;
  /**
   * will delete the SAML idp from the account and then the application instance.
   */
  deleteApplicationInstanceForAWsAccount(params: SSOInternal.Types.DeleteApplicationInstanceForAWsAccountRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceForAWsAccountResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceForAWsAccountResponse, AWSError>;
  /**
   * will delete the SAML idp from the account and then the application instance.
   */
  deleteApplicationInstanceForAWsAccount(callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationInstanceForAWsAccountResponse) => void): Request<SSOInternal.Types.DeleteApplicationInstanceForAWsAccountResponse, AWSError>;
  /**
   * will detach profile from the permission set and then delete it.
   */
  deleteApplicationProfileForAwsAccount(params: SSOInternal.Types.DeleteApplicationProfileForAwsAccountRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationProfileForAwsAccountResponse) => void): Request<SSOInternal.Types.DeleteApplicationProfileForAwsAccountResponse, AWSError>;
  /**
   * will detach profile from the permission set and then delete it.
   */
  deleteApplicationProfileForAwsAccount(callback?: (err: AWSError, data: SSOInternal.Types.DeleteApplicationProfileForAwsAccountResponse) => void): Request<SSOInternal.Types.DeleteApplicationProfileForAwsAccountResponse, AWSError>;
  /**
   * Deletes multiple assignments associated with the accessor. Indicates if all the assignments are deleted.
   */
  deleteAssignmentsForAccessor(params: SSOInternal.Types.DeleteAssignmentsForAccessorRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteAssignmentsForAccessorResponse) => void): Request<SSOInternal.Types.DeleteAssignmentsForAccessorResponse, AWSError>;
  /**
   * Deletes multiple assignments associated with the accessor. Indicates if all the assignments are deleted.
   */
  deleteAssignmentsForAccessor(callback?: (err: AWSError, data: SSOInternal.Types.DeleteAssignmentsForAccessorResponse) => void): Request<SSOInternal.Types.DeleteAssignmentsForAccessorResponse, AWSError>;
  /**
   * Delete an Managed ApplicationInstance.
   */
  deleteManagedApplicationInstance(params: SSOInternal.Types.DeleteManagedApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.DeleteManagedApplicationInstanceResponse, AWSError>;
  /**
   * Delete an Managed ApplicationInstance.
   */
  deleteManagedApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.DeleteManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.DeleteManagedApplicationInstanceResponse, AWSError>;
  /**
   * Deletes a Permission Set
   */
  deletePermissionSet(params: SSOInternal.Types.DeletePermissionSetRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeletePermissionSetResponse) => void): Request<SSOInternal.Types.DeletePermissionSetResponse, AWSError>;
  /**
   * Deletes a Permission Set
   */
  deletePermissionSet(callback?: (err: AWSError, data: SSOInternal.Types.DeletePermissionSetResponse) => void): Request<SSOInternal.Types.DeletePermissionSetResponse, AWSError>;
  /**
   * Deletes the embedded policy document from the permission set.
   */
  deletePermissionsPolicy(params: SSOInternal.Types.DeletePermissionsPolicyRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeletePermissionsPolicyResponse) => void): Request<SSOInternal.Types.DeletePermissionsPolicyResponse, AWSError>;
  /**
   * Deletes the embedded policy document from the permission set.
   */
  deletePermissionsPolicy(callback?: (err: AWSError, data: SSOInternal.Types.DeletePermissionsPolicyResponse) => void): Request<SSOInternal.Types.DeletePermissionsPolicyResponse, AWSError>;
  /**
   * Delete an ApplicationProfile.
   */
  deleteProfile(params: SSOInternal.Types.DeleteProfileRequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteProfileResponse) => void): Request<SSOInternal.Types.DeleteProfileResponse, AWSError>;
  /**
   * Delete an ApplicationProfile.
   */
  deleteProfile(callback?: (err: AWSError, data: SSOInternal.Types.DeleteProfileResponse) => void): Request<SSOInternal.Types.DeleteProfileResponse, AWSError>;
  /**
   * Delete SSO in current region for the calling account
   */
  deleteSSO(params: SSOInternal.Types.DeleteSSORequest, callback?: (err: AWSError, data: SSOInternal.Types.DeleteSSOResponse) => void): Request<SSOInternal.Types.DeleteSSOResponse, AWSError>;
  /**
   * Delete SSO in current region for the calling account
   */
  deleteSSO(callback?: (err: AWSError, data: SSOInternal.Types.DeleteSSOResponse) => void): Request<SSOInternal.Types.DeleteSSOResponse, AWSError>;
  /**
   * Lists all the attached AMP's to a Permission set
   */
  describePermissionsPolicies(params: SSOInternal.Types.DescribePermissionsPoliciesRequest, callback?: (err: AWSError, data: SSOInternal.Types.DescribePermissionsPoliciesResponse) => void): Request<SSOInternal.Types.DescribePermissionsPoliciesResponse, AWSError>;
  /**
   * Lists all the attached AMP's to a Permission set
   */
  describePermissionsPolicies(callback?: (err: AWSError, data: SSOInternal.Types.DescribePermissionsPoliciesResponse) => void): Request<SSOInternal.Types.DescribePermissionsPoliciesResponse, AWSError>;
  /**
   * Get regions that has SSO service registered
   */
  describeRegisteredRegions(params: SSOInternal.Types.DescribeRegisteredRegionsRequest, callback?: (err: AWSError, data: SSOInternal.Types.DescribeRegisteredRegionsResponse) => void): Request<SSOInternal.Types.DescribeRegisteredRegionsResponse, AWSError>;
  /**
   * Get regions that has SSO service registered
   */
  describeRegisteredRegions(callback?: (err: AWSError, data: SSOInternal.Types.DescribeRegisteredRegionsResponse) => void): Request<SSOInternal.Types.DescribeRegisteredRegionsResponse, AWSError>;
  /**
   * Detaches an AMP from a Permission Set
   */
  detachManagedPolicy(params: SSOInternal.Types.DetachManagedPolicyRequest, callback?: (err: AWSError, data: SSOInternal.Types.DetachManagedPolicyResponse) => void): Request<SSOInternal.Types.DetachManagedPolicyResponse, AWSError>;
  /**
   * Detaches an AMP from a Permission Set
   */
  detachManagedPolicy(callback?: (err: AWSError, data: SSOInternal.Types.DetachManagedPolicyResponse) => void): Request<SSOInternal.Types.DetachManagedPolicyResponse, AWSError>;
  /**
   * Disassociate a Directory to CloudSSO.
   */
  disassociateDirectory(params: SSOInternal.Types.DisassociateDirectoryRequest, callback?: (err: AWSError, data: SSOInternal.Types.DisassociateDirectoryResponse) => void): Request<SSOInternal.Types.DisassociateDirectoryResponse, AWSError>;
  /**
   * Disassociate a Directory to CloudSSO.
   */
  disassociateDirectory(callback?: (err: AWSError, data: SSOInternal.Types.DisassociateDirectoryResponse) => void): Request<SSOInternal.Types.DisassociateDirectoryResponse, AWSError>;
  /**
   * Delete User and Group to AppInstance Assignments.
   */
  disassociateProfile(params: SSOInternal.Types.DisassociateProfileRequest, callback?: (err: AWSError, data: SSOInternal.Types.DisassociateProfileResponse) => void): Request<SSOInternal.Types.DisassociateProfileResponse, AWSError>;
  /**
   * Delete User and Group to AppInstance Assignments.
   */
  disassociateProfile(callback?: (err: AWSError, data: SSOInternal.Types.DisassociateProfileResponse) => void): Request<SSOInternal.Types.DisassociateProfileResponse, AWSError>;
  /**
   * Will return a boolean flag indicating whether a profile is in sync with the permission set
   */
  getAWSAccountProfileStatus(params: SSOInternal.Types.GetAWSAccountProfileStatusRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetAWSAccountProfileStatusResponse) => void): Request<SSOInternal.Types.GetAWSAccountProfileStatusResponse, AWSError>;
  /**
   * Will return a boolean flag indicating whether a profile is in sync with the permission set
   */
  getAWSAccountProfileStatus(callback?: (err: AWSError, data: SSOInternal.Types.GetAWSAccountProfileStatusResponse) => void): Request<SSOInternal.Types.GetAWSAccountProfileStatusResponse, AWSError>;
  /**
   * Returns all the accessors that has assignments for the provided directory association
   */
  getAccessorsForDirectoryAssociation(params: SSOInternal.Types.GetAccessorsForDirectoryAssociationRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetAccessorsForDirectoryAssociationResponse) => void): Request<SSOInternal.Types.GetAccessorsForDirectoryAssociationResponse, AWSError>;
  /**
   * Returns all the accessors that has assignments for the provided directory association
   */
  getAccessorsForDirectoryAssociation(callback?: (err: AWSError, data: SSOInternal.Types.GetAccessorsForDirectoryAssociationResponse) => void): Request<SSOInternal.Types.GetAccessorsForDirectoryAssociationResponse, AWSError>;
  /**
   * Get an ApplicationInstance.
   */
  getApplicationInstance(params: SSOInternal.Types.GetApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationInstanceResponse) => void): Request<SSOInternal.Types.GetApplicationInstanceResponse, AWSError>;
  /**
   * Get an ApplicationInstance.
   */
  getApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationInstanceResponse) => void): Request<SSOInternal.Types.GetApplicationInstanceResponse, AWSError>;
  /**
   * Will return the ApplicationInstance for AWS Account
   */
  getApplicationInstanceForAWSAccount(params: SSOInternal.Types.GetApplicationInstanceForAWSAccountRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationInstanceForAWSAccountResponse) => void): Request<SSOInternal.Types.GetApplicationInstanceForAWSAccountResponse, AWSError>;
  /**
   * Will return the ApplicationInstance for AWS Account
   */
  getApplicationInstanceForAWSAccount(callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationInstanceForAWSAccountResponse) => void): Request<SSOInternal.Types.GetApplicationInstanceForAWSAccountResponse, AWSError>;
  /**
   * Get a SaaS ApplicationTemplate.
   */
  getApplicationTemplate(params: SSOInternal.Types.GetApplicationTemplateRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationTemplateResponse) => void): Request<SSOInternal.Types.GetApplicationTemplateResponse, AWSError>;
  /**
   * Get a SaaS ApplicationTemplate.
   */
  getApplicationTemplate(callback?: (err: AWSError, data: SSOInternal.Types.GetApplicationTemplateResponse) => void): Request<SSOInternal.Types.GetApplicationTemplateResponse, AWSError>;
  /**
   * Get an Managed ApplicationInstance.
   */
  getManagedApplicationInstance(params: SSOInternal.Types.GetManagedApplicationInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.GetManagedApplicationInstanceResponse, AWSError>;
  /**
   * Get an Managed ApplicationInstance.
   */
  getManagedApplicationInstance(callback?: (err: AWSError, data: SSOInternal.Types.GetManagedApplicationInstanceResponse) => void): Request<SSOInternal.Types.GetManagedApplicationInstanceResponse, AWSError>;
  /**
   * Retrieves device management configuration for the specified directory.
   */
  getMfaDeviceManagementForDirectory(params: SSOInternal.Types.GetMfaDeviceManagementForDirectoryRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetMfaDeviceManagementForDirectoryResponse) => void): Request<SSOInternal.Types.GetMfaDeviceManagementForDirectoryResponse, AWSError>;
  /**
   * Retrieves device management configuration for the specified directory.
   */
  getMfaDeviceManagementForDirectory(callback?: (err: AWSError, data: SSOInternal.Types.GetMfaDeviceManagementForDirectoryResponse) => void): Request<SSOInternal.Types.GetMfaDeviceManagementForDirectoryResponse, AWSError>;
  /**
   * Check if SSO has been enabled for an account
   */
  getPeregrineStatus(params: SSOInternal.Types.GetPeregrineStatusRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetPeregrineStatusResponse) => void): Request<SSOInternal.Types.GetPeregrineStatusResponse, AWSError>;
  /**
   * Check if SSO has been enabled for an account
   */
  getPeregrineStatus(callback?: (err: AWSError, data: SSOInternal.Types.GetPeregrineStatusResponse) => void): Request<SSOInternal.Types.GetPeregrineStatusResponse, AWSError>;
  /**
   * Gets a Permission Set.
   */
  getPermissionSet(params: SSOInternal.Types.GetPermissionSetRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetPermissionSetResponse) => void): Request<SSOInternal.Types.GetPermissionSetResponse, AWSError>;
  /**
   * Gets a Permission Set.
   */
  getPermissionSet(callback?: (err: AWSError, data: SSOInternal.Types.GetPermissionSetResponse) => void): Request<SSOInternal.Types.GetPermissionSetResponse, AWSError>;
  /**
   * Get the policy Document embedded in a Permission Set
   */
  getPermissionsPolicy(params: SSOInternal.Types.GetPermissionsPolicyRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetPermissionsPolicyResponse) => void): Request<SSOInternal.Types.GetPermissionsPolicyResponse, AWSError>;
  /**
   * Get the policy Document embedded in a Permission Set
   */
  getPermissionsPolicy(callback?: (err: AWSError, data: SSOInternal.Types.GetPermissionsPolicyResponse) => void): Request<SSOInternal.Types.GetPermissionsPolicyResponse, AWSError>;
  /**
   * Get shared SSO Instance Configuration
   */
  getSharedSsoConfiguration(params: SSOInternal.Types.GetSharedSsoConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetSharedSsoConfigurationResponse) => void): Request<SSOInternal.Types.GetSharedSsoConfigurationResponse, AWSError>;
  /**
   * Get shared SSO Instance Configuration
   */
  getSharedSsoConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.GetSharedSsoConfigurationResponse) => void): Request<SSOInternal.Types.GetSharedSsoConfigurationResponse, AWSError>;
  /**
   * Get SSO Instance Configuration
   */
  getSsoConfiguration(params: SSOInternal.Types.GetSsoConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.GetSsoConfigurationResponse) => void): Request<SSOInternal.Types.GetSsoConfigurationResponse, AWSError>;
  /**
   * Get SSO Instance Configuration
   */
  getSsoConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.GetSsoConfigurationResponse) => void): Request<SSOInternal.Types.GetSsoConfigurationResponse, AWSError>;
  /**
   * Create a SaaS ApplicationInstance's ServiceProviderMetadata in S3. Return parameters required to access the S3 file.
   */
  importApplicationInstanceServiceProviderMetadata(params: SSOInternal.Types.ImportApplicationInstanceServiceProviderMetadataRequest, callback?: (err: AWSError, data: SSOInternal.Types.ImportApplicationInstanceServiceProviderMetadataResponse) => void): Request<SSOInternal.Types.ImportApplicationInstanceServiceProviderMetadataResponse, AWSError>;
  /**
   * Create a SaaS ApplicationInstance's ServiceProviderMetadata in S3. Return parameters required to access the S3 file.
   */
  importApplicationInstanceServiceProviderMetadata(callback?: (err: AWSError, data: SSOInternal.Types.ImportApplicationInstanceServiceProviderMetadataResponse) => void): Request<SSOInternal.Types.ImportApplicationInstanceServiceProviderMetadataResponse, AWSError>;
  /**
   * Will return all the application profiles for an AWS account instance
   */
  listAWSAccountProfiles(params: SSOInternal.Types.ListAWSAccountProfilesRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListAWSAccountProfilesResponse) => void): Request<SSOInternal.Types.ListAWSAccountProfilesResponse, AWSError>;
  /**
   * Will return all the application profiles for an AWS account instance
   */
  listAWSAccountProfiles(callback?: (err: AWSError, data: SSOInternal.Types.ListAWSAccountProfilesResponse) => void): Request<SSOInternal.Types.ListAWSAccountProfilesResponse, AWSError>;
  /**
   * Will return a list of accounts in which a profile corresponding to the permission set has been provisioned. If the OnlyOutOfSync flag is set to true then only the Accounts with profile out of sync with the permission set, will be returned.
   */
  listAccountsWithProvisionedPermissionSet(params: SSOInternal.Types.ListAccountsWithProvisionedPermissionSetRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListAccountsWithProvisionedPermissionSetResponse) => void): Request<SSOInternal.Types.ListAccountsWithProvisionedPermissionSetResponse, AWSError>;
  /**
   * Will return a list of accounts in which a profile corresponding to the permission set has been provisioned. If the OnlyOutOfSync flag is set to true then only the Accounts with profile out of sync with the permission set, will be returned.
   */
  listAccountsWithProvisionedPermissionSet(callback?: (err: AWSError, data: SSOInternal.Types.ListAccountsWithProvisionedPermissionSetResponse) => void): Request<SSOInternal.Types.ListAccountsWithProvisionedPermissionSetResponse, AWSError>;
  /**
   * List Application Instance Certificates.
   */
  listApplicationInstanceCertificates(params: SSOInternal.Types.ListApplicationInstanceCertificatesRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationInstanceCertificatesResponse) => void): Request<SSOInternal.Types.ListApplicationInstanceCertificatesResponse, AWSError>;
  /**
   * List Application Instance Certificates.
   */
  listApplicationInstanceCertificates(callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationInstanceCertificatesResponse) => void): Request<SSOInternal.Types.ListApplicationInstanceCertificatesResponse, AWSError>;
  /**
   * List ApplicationInstances.
   */
  listApplicationInstances(params: SSOInternal.Types.ListApplicationInstancesRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationInstancesResponse) => void): Request<SSOInternal.Types.ListApplicationInstancesResponse, AWSError>;
  /**
   * List ApplicationInstances.
   */
  listApplicationInstances(callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationInstancesResponse) => void): Request<SSOInternal.Types.ListApplicationInstancesResponse, AWSError>;
  /**
   * List SaaS ApplicationTemplates.
   */
  listApplicationTemplates(params: SSOInternal.Types.ListApplicationTemplatesRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationTemplatesResponse) => void): Request<SSOInternal.Types.ListApplicationTemplatesResponse, AWSError>;
  /**
   * List SaaS ApplicationTemplates.
   */
  listApplicationTemplates(callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationTemplatesResponse) => void): Request<SSOInternal.Types.ListApplicationTemplatesResponse, AWSError>;
  /**
   * List SaaS Applications.
   */
  listApplications(params: SSOInternal.Types.ListApplicationsRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationsResponse) => void): Request<SSOInternal.Types.ListApplicationsResponse, AWSError>;
  /**
   * List SaaS Applications.
   */
  listApplications(callback?: (err: AWSError, data: SSOInternal.Types.ListApplicationsResponse) => void): Request<SSOInternal.Types.ListApplicationsResponse, AWSError>;
  /**
   * List DirectoryAssociations.
   */
  listDirectoryAssociations(params: SSOInternal.Types.ListDirectoryAssociationsRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListDirectoryAssociationsResponse) => void): Request<SSOInternal.Types.ListDirectoryAssociationsResponse, AWSError>;
  /**
   * List DirectoryAssociations.
   */
  listDirectoryAssociations(callback?: (err: AWSError, data: SSOInternal.Types.ListDirectoryAssociationsResponse) => void): Request<SSOInternal.Types.ListDirectoryAssociationsResponse, AWSError>;
  /**
   * Lists all the PermissionSets for an organization
   */
  listPermissionSets(params: SSOInternal.Types.ListPermissionSetsRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListPermissionSetsResponse) => void): Request<SSOInternal.Types.ListPermissionSetsResponse, AWSError>;
  /**
   * Lists all the PermissionSets for an organization
   */
  listPermissionSets(callback?: (err: AWSError, data: SSOInternal.Types.ListPermissionSetsResponse) => void): Request<SSOInternal.Types.ListPermissionSetsResponse, AWSError>;
  /**
   * List assignments between User/Group accessors and Applications.
   */
  listProfileAssociations(params: SSOInternal.Types.ListProfileAssociationsRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListProfileAssociationsResponse) => void): Request<SSOInternal.Types.ListProfileAssociationsResponse, AWSError>;
  /**
   * List assignments between User/Group accessors and Applications.
   */
  listProfileAssociations(callback?: (err: AWSError, data: SSOInternal.Types.ListProfileAssociationsResponse) => void): Request<SSOInternal.Types.ListProfileAssociationsResponse, AWSError>;
  /**
   * List ApplicationProfiles.
   */
  listProfiles(params: SSOInternal.Types.ListProfilesRequest, callback?: (err: AWSError, data: SSOInternal.Types.ListProfilesResponse) => void): Request<SSOInternal.Types.ListProfilesResponse, AWSError>;
  /**
   * List ApplicationProfiles.
   */
  listProfiles(callback?: (err: AWSError, data: SSOInternal.Types.ListProfilesResponse) => void): Request<SSOInternal.Types.ListProfilesResponse, AWSError>;
  /**
   * Will either create an ApplicationInstance or return an Existing one for the AWS Account.
   */
  provisionApplicationInstanceForAWSAccount(params: SSOInternal.Types.ProvisionApplicationInstanceForAWSAccountRequest, callback?: (err: AWSError, data: SSOInternal.Types.ProvisionApplicationInstanceForAWSAccountResponse) => void): Request<SSOInternal.Types.ProvisionApplicationInstanceForAWSAccountResponse, AWSError>;
  /**
   * Will either create an ApplicationInstance or return an Existing one for the AWS Account.
   */
  provisionApplicationInstanceForAWSAccount(callback?: (err: AWSError, data: SSOInternal.Types.ProvisionApplicationInstanceForAWSAccountResponse) => void): Request<SSOInternal.Types.ProvisionApplicationInstanceForAWSAccountResponse, AWSError>;
  /**
   * Will create an ApplicationProfile for the application instance corresponding to a permission set
   */
  provisionApplicationProfileForAWSAccountInstance(params: SSOInternal.Types.ProvisionApplicationProfileForAWSAccountInstanceRequest, callback?: (err: AWSError, data: SSOInternal.Types.ProvisionApplicationProfileForAWSAccountInstanceResponse) => void): Request<SSOInternal.Types.ProvisionApplicationProfileForAWSAccountInstanceResponse, AWSError>;
  /**
   * Will create an ApplicationProfile for the application instance corresponding to a permission set
   */
  provisionApplicationProfileForAWSAccountInstance(callback?: (err: AWSError, data: SSOInternal.Types.ProvisionApplicationProfileForAWSAccountInstanceResponse) => void): Request<SSOInternal.Types.ProvisionApplicationProfileForAWSAccountInstanceResponse, AWSError>;
  /**
   * Will either create a new SAMLProvider in the AWS Account or return the existing one.
   */
  provisionSAMLProvider(params: SSOInternal.Types.ProvisionSAMLProviderRequest, callback?: (err: AWSError, data: SSOInternal.Types.ProvisionSAMLProviderResponse) => void): Request<SSOInternal.Types.ProvisionSAMLProviderResponse, AWSError>;
  /**
   * Will either create a new SAMLProvider in the AWS Account or return the existing one.
   */
  provisionSAMLProvider(callback?: (err: AWSError, data: SSOInternal.Types.ProvisionSAMLProviderResponse) => void): Request<SSOInternal.Types.ProvisionSAMLProviderResponse, AWSError>;
  /**
   * Save device management configuration for the specified directory.
   */
  putMfaDeviceManagementForDirectory(params: SSOInternal.Types.PutMfaDeviceManagementForDirectoryRequest, callback?: (err: AWSError, data: SSOInternal.Types.PutMfaDeviceManagementForDirectoryResponse) => void): Request<SSOInternal.Types.PutMfaDeviceManagementForDirectoryResponse, AWSError>;
  /**
   * Save device management configuration for the specified directory.
   */
  putMfaDeviceManagementForDirectory(callback?: (err: AWSError, data: SSOInternal.Types.PutMfaDeviceManagementForDirectoryResponse) => void): Request<SSOInternal.Types.PutMfaDeviceManagementForDirectoryResponse, AWSError>;
  /**
   * Embeds a policy document in the permissions set.
   */
  putPermissionsPolicy(params: SSOInternal.Types.PutPermissionsPolicyRequest, callback?: (err: AWSError, data: SSOInternal.Types.PutPermissionsPolicyResponse) => void): Request<SSOInternal.Types.PutPermissionsPolicyResponse, AWSError>;
  /**
   * Embeds a policy document in the permissions set.
   */
  putPermissionsPolicy(callback?: (err: AWSError, data: SSOInternal.Types.PutPermissionsPolicyResponse) => void): Request<SSOInternal.Types.PutPermissionsPolicyResponse, AWSError>;
  /**
   * set current region where SSO instance will be created
   */
  registerRegion(params: SSOInternal.Types.RegisterRegionRequest, callback?: (err: AWSError, data: SSOInternal.Types.RegisterRegionResponse) => void): Request<SSOInternal.Types.RegisterRegionResponse, AWSError>;
  /**
   * set current region where SSO instance will be created
   */
  registerRegion(callback?: (err: AWSError, data: SSOInternal.Types.RegisterRegionResponse) => void): Request<SSOInternal.Types.RegisterRegionResponse, AWSError>;
  /**
   * Enable SSO for the calling account
   */
  startPeregrine(params: SSOInternal.Types.StartPeregrineRequest, callback?: (err: AWSError, data: SSOInternal.Types.StartPeregrineResponse) => void): Request<SSOInternal.Types.StartPeregrineResponse, AWSError>;
  /**
   * Enable SSO for the calling account
   */
  startPeregrine(callback?: (err: AWSError, data: SSOInternal.Types.StartPeregrineResponse) => void): Request<SSOInternal.Types.StartPeregrineResponse, AWSError>;
  /**
   * Promote an Application Instance Certificate to active.
   */
  updateApplicationInstanceActiveCertificate(params: SSOInternal.Types.UpdateApplicationInstanceActiveCertificateRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceActiveCertificateResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceActiveCertificateResponse, AWSError>;
  /**
   * Promote an Application Instance Certificate to active.
   */
  updateApplicationInstanceActiveCertificate(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceActiveCertificateResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceActiveCertificateResponse, AWSError>;
  /**
   * Update an ApplicationInstance's DisplayData.
   */
  updateApplicationInstanceDisplayData(params: SSOInternal.Types.UpdateApplicationInstanceDisplayDataRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceDisplayDataResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceDisplayDataResponse, AWSError>;
  /**
   * Update an ApplicationInstance's DisplayData.
   */
  updateApplicationInstanceDisplayData(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceDisplayDataResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceDisplayDataResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ResponseConfig.
   */
  updateApplicationInstanceResponseConfiguration(params: SSOInternal.Types.UpdateApplicationInstanceResponseConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceResponseConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceResponseConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ResponseConfig.
   */
  updateApplicationInstanceResponseConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceResponseConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceResponseConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ResponseSchemaConfig.
   */
  updateApplicationInstanceResponseSchemaConfiguration(params: SSOInternal.Types.UpdateApplicationInstanceResponseSchemaConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceResponseSchemaConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceResponseSchemaConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ResponseSchemaConfig.
   */
  updateApplicationInstanceResponseSchemaConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceResponseSchemaConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceResponseSchemaConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's SecurityConfig.
   */
  updateApplicationInstanceSecurityConfiguration(params: SSOInternal.Types.UpdateApplicationInstanceSecurityConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceSecurityConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceSecurityConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's SecurityConfig.
   */
  updateApplicationInstanceSecurityConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceSecurityConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceSecurityConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ServiceProviderConfig.
   */
  updateApplicationInstanceServiceProviderConfiguration(params: SSOInternal.Types.UpdateApplicationInstanceServiceProviderConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceServiceProviderConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceServiceProviderConfigurationResponse, AWSError>;
  /**
   * Update a SaaS ApplicationInstance's ServiceProviderConfig.
   */
  updateApplicationInstanceServiceProviderConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceServiceProviderConfigurationResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceServiceProviderConfigurationResponse, AWSError>;
  /**
   * Update an ApplicationInstance's Status.
   */
  updateApplicationInstanceStatus(params: SSOInternal.Types.UpdateApplicationInstanceStatusRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceStatusResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceStatusResponse, AWSError>;
  /**
   * Update an ApplicationInstance's Status.
   */
  updateApplicationInstanceStatus(callback?: (err: AWSError, data: SSOInternal.Types.UpdateApplicationInstanceStatusResponse) => void): Request<SSOInternal.Types.UpdateApplicationInstanceStatusResponse, AWSError>;
  /**
   * Update a Directory to CloudSSO.
   */
  updateDirectoryAssociation(params: SSOInternal.Types.UpdateDirectoryAssociationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateDirectoryAssociationResponse) => void): Request<SSOInternal.Types.UpdateDirectoryAssociationResponse, AWSError>;
  /**
   * Update a Directory to CloudSSO.
   */
  updateDirectoryAssociation(callback?: (err: AWSError, data: SSOInternal.Types.UpdateDirectoryAssociationResponse) => void): Request<SSOInternal.Types.UpdateDirectoryAssociationResponse, AWSError>;
  /**
   * Update an ManagedApplicationInstance's Status.
   */
  updateManagedApplicationInstanceStatus(params: SSOInternal.Types.UpdateManagedApplicationInstanceStatusRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateManagedApplicationInstanceStatusResponse) => void): Request<SSOInternal.Types.UpdateManagedApplicationInstanceStatusResponse, AWSError>;
  /**
   * Update an ManagedApplicationInstance's Status.
   */
  updateManagedApplicationInstanceStatus(callback?: (err: AWSError, data: SSOInternal.Types.UpdateManagedApplicationInstanceStatusResponse) => void): Request<SSOInternal.Types.UpdateManagedApplicationInstanceStatusResponse, AWSError>;
  /**
   * Update a Permission Set
   */
  updatePermissionSet(params: SSOInternal.Types.UpdatePermissionSetRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdatePermissionSetResponse) => void): Request<SSOInternal.Types.UpdatePermissionSetResponse, AWSError>;
  /**
   * Update a Permission Set
   */
  updatePermissionSet(callback?: (err: AWSError, data: SSOInternal.Types.UpdatePermissionSetResponse) => void): Request<SSOInternal.Types.UpdatePermissionSetResponse, AWSError>;
  /**
   * Update SSO Instance Configuration
   */
  updateSsoConfiguration(params: SSOInternal.Types.UpdateSsoConfigurationRequest, callback?: (err: AWSError, data: SSOInternal.Types.UpdateSsoConfigurationResponse) => void): Request<SSOInternal.Types.UpdateSsoConfigurationResponse, AWSError>;
  /**
   * Update SSO Instance Configuration
   */
  updateSsoConfiguration(callback?: (err: AWSError, data: SSOInternal.Types.UpdateSsoConfigurationResponse) => void): Request<SSOInternal.Types.UpdateSsoConfigurationResponse, AWSError>;
}
declare namespace SSOInternal {
  export interface AWSAccountProfile {
    name?: permissionSetNameType;
    profileId?: profileIdType;
    display?: DisplayData;
    responseConfig?: ResponseConfig;
    permissionSetId?: permissionSetIdType;
  }
  export interface Accessor {
    id: accessorIdType;
    ssoGuid?: accessorIdType;
    softDeleted?: softDeletedType;
    type: accessorType;
    display?: AccessorDisplayData;
    directoryType: directoryType;
    directoryId: idType;
    normalizedId?: accessorIdType;
  }
  export interface AccessorDisplayData {
    userName?: nameType;
    groupName?: nameType;
    identifiedUserName?: nameType;
    firstName?: nameType;
    lastName?: nameType;
    windowsUpn?: windowsUpnType;
  }
  export type AllowedMfaTypes = MfaType[];
  export interface Application {
    applicationId: idType;
    display: DisplayData;
    applicationType?: applicationType;
  }
  export interface ApplicationFilter {
    filterMode: filterMode;
    filterKey: applicationFilterKey;
    filterValue: filterValue;
  }
  export interface ApplicationInstance {
    instanceId: applicationInstanceIdType;
    name?: applicationInstanceName;
    template: ApplicationTemplate;
    searchMetadata?: searchMetadataMap;
    status: status;
    display: DisplayData;
    serviceProviderConfig?: ServiceProviderConfig;
    responseConfig?: ResponseConfig;
    responseSchemaConfig?: ResponseSchemaConfig;
    securityConfig?: SecurityConfig;
    profiles?: applicationProfileList;
    activeCertificate: CertificateData;
    identityProviderConfig?: IdentityProviderConfig;
    visible?: visible;
    clientId?: clientIdType;
    managedAccount?: idType;
    assignmentConfig?: AssignmentConfig;
    endUserVisible?: endUserVisible;
  }
  export interface ApplicationProfile {
    name?: nameType;
    profileId: profileIdType;
    status: status;
    display?: DisplayData;
    responseConfig?: ResponseConfig;
  }
  export interface ApplicationTemplate {
    templateId: idType;
    templateVersion?: idType;
    application: Application;
    sSOProtocol: SSOProtocol;
    serviceProviderConfig?: ServiceProviderConfig;
    responseConfig?: ResponseConfig;
    responseSchemaConfig: ResponseSchemaConfig;
    securityConfig: SecurityConfig;
    confidentialClientConfig?: ClientTemplate;
  }
  export interface Assignment {
    accountId: idType;
    accessor: Accessor;
    instanceId: idType;
    profileId?: profileIdType;
  }
  export interface AssignmentConfig {
    assignmentRequired?: assignmentRequired;
  }
  export interface AssociateDirectoryRequest {
    directoryId?: idType;
    directoryType: directoryType;
    instanceArn?: swbArnType;
  }
  export interface AssociateDirectoryResponse {
    directoryAssociation: DirectoryAssociation;
  }
  export interface AssociateProfileRequest {
    accessorId: accessorIdType;
    ssoGuid?: accessorIdType;
    accessorType: accessorType;
    accessorDisplay?: AccessorDisplayData;
    directoryId: idType;
    directoryType: directoryType;
    instanceId: applicationInstanceIdType;
    profileId: profileIdType;
  }
  export interface AssociateProfileResponse {
    assignment: Assignment;
  }
  export interface AttachManagedPolicyRequest {
    permissionSetId: permissionSetIdType;
    arn: managedPolicyArn;
  }
  export interface AttachManagedPolicyResponse {
  }
  export interface AttachedManagedPolicy {
    Name?: nameType;
    Arn?: managedPolicyArn;
  }
  export type AttachedManagedPolicyList = AttachedManagedPolicy[];
  export interface CertificateData {
    certificateId: certificateId;
    algorithm: certificateAlgorithm;
    keySize: keySize;
    certificate: certificateType;
    issueDate: dateType;
    expiryDate: dateType;
    status: status;
  }
  export interface ClientTemplate {
    redirectUris?: RedirectUris;
    scopes?: scopeList;
    grantTypes?: grantTypeList;
  }
  export interface CreateApplicationInstanceCertificateRequest {
    instanceId: applicationInstanceIdType;
  }
  export interface CreateApplicationInstanceCertificateResponse {
    applicationInstanceCertificate: CertificateData;
  }
  export interface CreateApplicationInstanceRequest {
    templateId: templateIdType;
    templateVersion?: versionType;
    name: applicationInstanceName;
  }
  export interface CreateApplicationInstanceResponse {
    applicationInstance: ApplicationInstance;
  }
  export interface CreateManagedApplicationInstanceRequest {
    templateId: templateIdType;
    templateVersion?: versionType;
    tenantId: idType;
    templateContext?: templateContextMap;
    startUrl: urlLocationType;
    displayName: nameType;
    regionName?: regionNameType;
    assignmentConfig?: AssignmentConfig;
    endUserVisible?: endUserVisible;
  }
  export interface CreateManagedApplicationInstanceResponse {
    applicationInstance: ApplicationInstance;
    identityStoreId?: idType;
    instanceArn?: swbArnType;
  }
  export interface CreatePermissionSetRequest {
    permissionSetName: permissionSetNameType;
    description?: PermissionSetDescriptionType;
    ttl?: durationType;
    relayState?: relayStateType;
  }
  export interface CreatePermissionSetResponse {
    permissionSet: PermissionSet;
  }
  export interface CreateProfileRequest {
    name: nameType;
    instanceId: applicationInstanceIdType;
    responseConfig?: ResponseConfig;
  }
  export interface CreateProfileResponse {
    applicationProfile: ApplicationProfile;
  }
  export interface DeleteApplicationInstanceCertificateRequest {
    certificateId: certificateId;
    instanceId: applicationInstanceIdType;
  }
  export interface DeleteApplicationInstanceCertificateResponse {
  }
  export interface DeleteApplicationInstanceForAWsAccountRequest {
    instanceId: applicationInstanceIdType;
  }
  export interface DeleteApplicationInstanceForAWsAccountResponse {
  }
  export interface DeleteApplicationInstanceRequest {
    instanceId: applicationInstanceIdType;
  }
  export interface DeleteApplicationInstanceResponse {
  }
  export interface DeleteApplicationProfileForAwsAccountRequest {
    profileId: profileIdType;
    instanceId: applicationInstanceIdType;
  }
  export interface DeleteApplicationProfileForAwsAccountResponse {
  }
  export interface DeleteAssignmentsForAccessorRequest {
    accessor: Accessor;
  }
  export interface DeleteAssignmentsForAccessorResponse {
    allAssignmentsDeleted?: booleanType;
  }
  export interface DeleteManagedApplicationInstanceRequest {
    clientId: clientIdType;
  }
  export interface DeleteManagedApplicationInstanceResponse {
  }
  export interface DeletePermissionSetRequest {
    permissionSetId: permissionSetIdType;
  }
  export interface DeletePermissionSetResponse {
  }
  export interface DeletePermissionsPolicyRequest {
    permissionSetId: permissionSetIdType;
  }
  export interface DeletePermissionsPolicyResponse {
  }
  export interface DeleteProfileRequest {
    profileId: profileIdType;
    instanceId: applicationInstanceIdType;
  }
  export interface DeleteProfileResponse {
  }
  export interface DeleteSSORequest {
  }
  export interface DeleteSSOResponse {
  }
  export interface DescribePermissionsPoliciesRequest {
    permissionSetId: permissionSetIdType;
    marker?: markerType;
  }
  export interface DescribePermissionsPoliciesResponse {
    attachedManagedPolicies: AttachedManagedPolicyList;
    marker?: markerType;
  }
  export interface DescribeRegisteredRegionsRequest {
  }
  export interface DescribeRegisteredRegionsResponse {
    regions: registeredRegionList;
  }
  export interface DetachManagedPolicyRequest {
    permissionSetId: permissionSetIdType;
    arn: managedPolicyArn;
  }
  export interface DetachManagedPolicyResponse {
  }
  export type DirectoryAlias = string;
  export interface DirectoryAssociation {
    directoryId: idType;
    directoryType: directoryType;
    directoryAlias?: DirectoryAlias;
    status: status;
    attributeMapping?: propertyMap;
    authenticationType?: authenticationType;
    provisioningTypes?: provisioningTypes;
    instanceArn?: swbArnType;
  }
  export interface DisassociateDirectoryRequest {
    directoryId: idType;
    directoryType: directoryType;
    instanceArn?: swbArnType;
  }
  export interface DisassociateDirectoryResponse {
  }
  export interface DisassociateProfileRequest {
    accessorId: accessorIdType;
    ssoGuid?: accessorIdType;
    accessorType: accessorType;
    directoryId: idType;
    directoryType: directoryType;
    instanceId: applicationInstanceIdType;
    profileId: profileIdType;
  }
  export interface DisassociateProfileResponse {
  }
  export interface DisplayData {
    displayName?: nameType;
    icon?: iconType;
    description?: descriptionType;
  }
  export interface Filter {
    filterMode: filterMode;
    filterKey: filterKey;
    filterValue: filterValue;
  }
  export interface GetAWSAccountProfileStatusRequest {
    instanceId: applicationInstanceIdType;
    profileId: profileIdType;
  }
  export interface GetAWSAccountProfileStatusResponse {
    awsProfileStatus: awsProfileStatus;
  }
  export interface GetAccessorsForDirectoryAssociationRequest {
    directoryId: idType;
    directoryType: directoryType;
    marker?: markerType;
  }
  export interface GetAccessorsForDirectoryAssociationResponse {
    accessors?: accessorList;
    marker?: markerType;
  }
  export interface GetApplicationInstanceForAWSAccountRequest {
    awsAccountId: accountIdType;
  }
  export interface GetApplicationInstanceForAWSAccountResponse {
    applicationInstance: ApplicationInstance;
  }
  export interface GetApplicationInstanceRequest {
    instanceId: applicationInstanceIdType;
  }
  export interface GetApplicationInstanceResponse {
    applicationInstance: ApplicationInstance;
  }
  export interface GetApplicationTemplateRequest {
    templateId: templateIdType;
    templateVersion?: versionType;
  }
  export interface GetApplicationTemplateResponse {
    applicationTemplate: ApplicationTemplate;
  }
  export interface GetManagedApplicationInstanceRequest {
    clientId: clientIdType;
  }
  export interface GetManagedApplicationInstanceResponse {
    applicationInstance: ApplicationInstance;
    identityStoreId?: idType;
    instanceArn?: swbArnType;
    regions?: managedApplicationInstanceRegionList;
  }
  export interface GetMfaDeviceManagementForDirectoryRequest {
    directoryId: idType;
    directoryType: directoryType;
  }
  export interface GetMfaDeviceManagementForDirectoryResponse {
    userPermission: UserPermissionType;
  }
  export interface GetPeregrineStatusRequest {
  }
  export interface GetPeregrineStatusResponse {
    ssoStatus: status;
    ssoStatusReasons?: ssoStatusReasons;
  }
  export interface GetPermissionSetRequest {
    permissionSetId: permissionSetIdType;
  }
  export interface GetPermissionSetResponse {
    permissionSet: PermissionSet;
    ssoInstanceId?: SsoInstanceIdType;
  }
  export interface GetPermissionsPolicyRequest {
    permissionSetId: permissionSetIdType;
  }
  export interface GetPermissionsPolicyResponse {
    policyDocument: permissionSetPolicyDocumentType;
  }
  export interface GetSharedSsoConfigurationRequest {
  }
  export interface GetSharedSsoConfigurationResponse {
    sharedSsoConfiguration: SharedSsoConfiguration;
    ssoStatus?: status;
  }
  export interface GetSsoConfigurationRequest {
  }
  export interface GetSsoConfigurationResponse {
    ssoConfiguration: SsoConfiguration;
  }
  export interface IdentityProviderConfig {
    metadataUrl?: urlLocationType;
    remoteLoginUrl?: urlLocationType;
    remoteLogoutUrl?: urlLocationType;
    issuerUrl?: urlLocationType;
  }
  export interface ImportApplicationInstanceServiceProviderMetadataRequest {
    instanceId: applicationInstanceIdType;
    serviceProviderMetadataFile: file;
  }
  export interface ImportApplicationInstanceServiceProviderMetadataResponse {
    s3BucketName?: s3BucketName;
    s3Key?: s3Key;
    s3VersionId?: s3VersionId;
  }
  export interface ListAWSAccountProfilesRequest {
    instanceId: applicationInstanceIdType;
    marker?: markerType;
  }
  export interface ListAWSAccountProfilesResponse {
    profileList: awsAccountProfileList;
    marker?: markerType;
  }
  export interface ListAccountsWithProvisionedPermissionSetRequest {
    permissionSetId: permissionSetIdType;
    marker?: markerType;
    onlyOutOfSync?: booleanType;
  }
  export interface ListAccountsWithProvisionedPermissionSetResponse {
    accountIds: accountIdList;
    marker?: markerType;
  }
  export interface ListApplicationInstanceCertificatesRequest {
    instanceId: applicationInstanceIdType;
    marker?: markerType;
  }
  export interface ListApplicationInstanceCertificatesResponse {
    applicationInstanceCertificates: certificateList;
    marker?: markerType;
  }
  export interface ListApplicationInstancesRequest {
    marker?: markerType;
    filter?: Filter;
  }
  export interface ListApplicationInstancesResponse {
    applicationInstances: applicationInstanceList;
    marker?: markerType;
  }
  export interface ListApplicationTemplatesRequest {
    applicationId: applicationIdType;
  }
  export interface ListApplicationTemplatesResponse {
    applicationTemplates: applicationTemplateList;
  }
  export interface ListApplicationsRequest {
    filter?: ApplicationFilter;
    marker?: markerType;
  }
  export interface ListApplicationsResponse {
    applications: applicationList;
    marker?: markerType;
  }
  export interface ListDirectoryAssociationsRequest {
    marker?: markerType;
    instanceArn?: swbArnType;
  }
  export interface ListDirectoryAssociationsResponse {
    directoryAssociations: directoryAssociationList;
    marker?: markerType;
  }
  export interface ListPermissionSetsRequest {
    marker?: markerType;
  }
  export interface ListPermissionSetsResponse {
    permissionSets: PermissionSetList;
    marker?: markerType;
    ssoInstanceId?: SsoInstanceIdType;
  }
  export interface ListProfileAssociationsRequest {
    directoryId: idType;
    directoryType: directoryType;
    instanceId: applicationInstanceIdType;
    profileId: profileIdType;
    marker?: markerType;
  }
  export interface ListProfileAssociationsResponse {
    assignments: assignmentList;
    marker?: markerType;
  }
  export interface ListProfilesRequest {
    instanceId: applicationInstanceIdType;
    marker?: markerType;
  }
  export interface ListProfilesResponse {
    applicationProfiles: applicationProfileList;
    marker?: markerType;
  }
  export interface ManagedApplicationInstanceRegion {
    region?: regionNameType;
  }
  export type MfaMode = "DISABLED"|"CONTEXT_AWARE"|"ALWAYS_ON"|string;
  export type MfaType = "TOTP"|"WEBAUTHN"|string;
  export type MigrationStatus = "NOT_STARTED"|"IN_PROGRESS"|"FAILED"|"COMPLETED"|string;
  export type NoMfaSignInBehavior = "ALLOWED"|"BLOCKED"|"EMAIL_OTP"|"ALLOWED_WITH_ENROLLMENT"|string;
  export type NoPasswordSignInBehavior = "BLOCKED"|"EMAIL_OTP"|string;
  export interface PermissionSet {
    Name?: nameType;
    Id?: permissionSetIdType;
    Description?: PermissionSetDescriptionType;
    CreationDate?: dateType;
    ttl?: durationType;
    relayState?: relayStateType;
  }
  export type PermissionSetDescriptionType = string;
  export type PermissionSetList = PermissionSet[];
  export interface Property {
    transforms?: transformList;
    source: sourceList;
  }
  export interface ProvisionApplicationInstanceForAWSAccountRequest {
    accountName?: accountNameType;
    accountId: accountIdType;
    accountEmail: accountEmailType;
  }
  export interface ProvisionApplicationInstanceForAWSAccountResponse {
    applicationInstance: ApplicationInstance;
  }
  export interface ProvisionApplicationProfileForAWSAccountInstanceRequest {
    instanceId: applicationInstanceIdType;
    permissionSetId: permissionSetIdType;
  }
  export interface ProvisionApplicationProfileForAWSAccountInstanceResponse {
    applicationProfile: ApplicationProfile;
  }
  export interface ProvisionSAMLProviderRequest {
    applicationInstanceId: applicationInstanceIdType;
  }
  export interface ProvisionSAMLProviderResponse {
    samlIdpArn: swbArnType;
  }
  export interface PutMfaDeviceManagementForDirectoryRequest {
    directoryId: idType;
    directoryType: directoryType;
    userPermission: UserPermissionType;
  }
  export interface PutMfaDeviceManagementForDirectoryResponse {
  }
  export interface PutPermissionsPolicyRequest {
    permissionSetId: permissionSetIdType;
    policyDocument: permissionSetPolicyDocumentType;
  }
  export interface PutPermissionsPolicyResponse {
  }
  export interface RedirectUris {
    uris?: Property;
  }
  export interface RegisterRegionRequest {
  }
  export interface RegisterRegionResponse {
  }
  export interface RegisteredRegion {
    regionName: regionNameType;
    regionDisplayName?: nameType;
  }
  export interface ResponseConfig {
    subject?: Property;
    ttl?: durationType;
    relayState?: relayStateType;
    properties?: propertyMap;
  }
  export interface ResponseConsumer {
    location: urlLocationType;
    binding: bindingType;
    defaultValue: booleanType;
  }
  export interface ResponseSchemaConfig {
    subject?: SubjectSchemaProperty;
    properties?: schemaPropertyMap;
    supportedNameIdFormats?: nameIdFormatList;
  }
  export type SSOConfigurationType = "APP_AUTHENTICATION_CONFIGURATION"|"SHARING_MODE"|"SESSION"|"MIGRATION_STATUS"|string;
  export type SSOProtocol = "SAML"|"OIDC"|string;
  export interface SchemaProperty {
    include: includeProperty;
    multiValue?: multiValue;
    attrNameFormat?: attrNameFormat;
    friendlyName?: nameType;
    values?: schemaPropertyValueList;
  }
  export interface SecurityConfig {
    signature: signatureAlgorithm;
    keyType: keyType;
    keySize: keySize;
    ttl?: durationType;
  }
  export interface ServiceProviderCertificateData {
    certificate: certificateType;
    usage?: certificateUsage;
    algorithm?: certificateAlgorithm;
  }
  export interface ServiceProviderConfig {
    certificates?: serviceProviderCertificateList;
    requireRequestSignature: booleanType;
    startUrl?: urlLocationType;
    audience: uriType;
    consumers: responseConsumerList;
  }
  export interface SessionConfiguration {
    maxAuthenticationAge?: durationType;
  }
  export interface SharedSsoConfiguration {
    sharingMode?: SharingMode;
  }
  export type SharingMode = "BASIC"|"OFF"|string;
  export interface SsoConfiguration {
    mfaMode?: MfaMode;
    noMfaSignInBehavior?: NoMfaSignInBehavior;
    noPasswordSignInBehavior?: NoPasswordSignInBehavior;
    sharingMode?: SharingMode;
    allowedMfaTypes?: AllowedMfaTypes;
    migrationStatus?: MigrationStatus;
    sessionConfiguration?: SessionConfiguration;
  }
  export type SsoInstanceIdType = string;
  export interface StartPeregrineRequest {
    sharingMode?: SharingMode;
  }
  export interface StartPeregrineResponse {
    ssoStatus: status;
  }
  export interface SubjectSchemaProperty {
    include: includeProperty;
    multiValue?: multiValue;
    nameIdFormat?: nameIdFormat;
    friendlyName?: nameType;
    values?: schemaPropertyValueList;
  }
  export interface UpdateApplicationInstanceActiveCertificateRequest {
    certificateId: certificateId;
    instanceId: applicationInstanceIdType;
  }
  export interface UpdateApplicationInstanceActiveCertificateResponse {
    applicationInstanceCertificate: CertificateData;
  }
  export interface UpdateApplicationInstanceDisplayDataRequest {
    instanceId: applicationInstanceIdType;
    displayName?: nameType;
    icon?: iconType;
    description?: descriptionType;
  }
  export interface UpdateApplicationInstanceDisplayDataResponse {
  }
  export interface UpdateApplicationInstanceResponseConfigurationRequest {
    instanceId: applicationInstanceIdType;
    responseConfig: ResponseConfig;
  }
  export interface UpdateApplicationInstanceResponseConfigurationResponse {
  }
  export interface UpdateApplicationInstanceResponseSchemaConfigurationRequest {
    instanceId: applicationInstanceIdType;
    responseSchemaConfig: ResponseSchemaConfig;
  }
  export interface UpdateApplicationInstanceResponseSchemaConfigurationResponse {
  }
  export interface UpdateApplicationInstanceSecurityConfigurationRequest {
    instanceId: applicationInstanceIdType;
    securityConfig: SecurityConfig;
  }
  export interface UpdateApplicationInstanceSecurityConfigurationResponse {
  }
  export interface UpdateApplicationInstanceServiceProviderConfigurationRequest {
    instanceId: applicationInstanceIdType;
    serviceProviderConfig: ServiceProviderConfig;
  }
  export interface UpdateApplicationInstanceServiceProviderConfigurationResponse {
  }
  export interface UpdateApplicationInstanceStatusRequest {
    instanceId: applicationInstanceIdType;
    status: status;
  }
  export interface UpdateApplicationInstanceStatusResponse {
  }
  export interface UpdateDirectoryAssociationRequest {
    directoryId: idType;
    directoryType: directoryType;
    attributeMapping: propertyMap;
  }
  export interface UpdateDirectoryAssociationResponse {
  }
  export interface UpdateManagedApplicationInstanceStatusRequest {
    clientId: clientIdType;
    status: status;
  }
  export interface UpdateManagedApplicationInstanceStatusResponse {
  }
  export interface UpdatePermissionSetRequest {
    permissionSetId: permissionSetIdType;
    description?: PermissionSetDescriptionType;
    ttl?: durationType;
    relayState?: relayStateType;
  }
  export interface UpdatePermissionSetResponse {
  }
  export interface UpdateSsoConfigurationRequest {
    ssoConfiguration: SsoConfiguration;
    configurationType?: SSOConfigurationType;
  }
  export interface UpdateSsoConfigurationResponse {
  }
  export type UserPermissionType = "READ_ACTIONS"|"ALL_ACTIONS"|string;
  export type accessorIdType = string;
  export type accessorList = Accessor[];
  export type accessorType = "GROUP"|"USER"|"SYSTEM"|string;
  export type accountEmailType = string;
  export type accountIdList = idType[];
  export type accountIdType = string;
  export type accountNameType = string;
  export type applicationFilterKey = "displayName"|string;
  export type applicationIdType = string;
  export type applicationInstanceIdType = string;
  export type applicationInstanceList = ApplicationInstance[];
  export type applicationInstanceName = string;
  export type applicationList = Application[];
  export type applicationProfileList = ApplicationProfile[];
  export type applicationTemplateList = ApplicationTemplate[];
  export type applicationType = "firstparty"|"thirdparty"|string;
  export type assignmentList = Assignment[];
  export type assignmentRequired = boolean;
  export type attrNameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic"|"urn:oasis:names:tc:SAML:2.0:attrname-format:unspecified"|"urn:oasis:names:tc:SAML:2.0:attrname-format:uri"|string;
  export type authenticationType = "DEFAULT"|"SAML_2.0"|string;
  export type awsAccountProfileList = AWSAccountProfile[];
  export type awsProfileStatus = "IN_SYNC"|"OUT_OF_SYNC"|string;
  export type bindingType = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"|"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-REDIRECT"|string;
  export type booleanType = boolean;
  export type certificateAlgorithm = "SHA1withRSA"|"SHA256withRSA"|string;
  export type certificateId = string;
  export type certificateList = CertificateData[];
  export type certificateType = string;
  export type certificateUsage = "encryption"|"signing"|string;
  export type clientIdType = string;
  export type dateType = Date;
  export type descriptionType = string;
  export type directoryAssociationList = DirectoryAssociation[];
  export type directoryType = "MicrosoftAD"|"ADConnector"|"UserPool"|string;
  export type durationType = string;
  export type endUserVisible = boolean;
  export type file = string;
  export type filterKey = "applicationTemplateId"|string;
  export type filterMode = "INCLUSIVE"|"EXCLUSIVE"|string;
  export type filterValue = string;
  export type grantType = string;
  export type grantTypeList = grantType[];
  export type iconType = string;
  export type idType = string;
  export type includeProperty = "YES"|"NO"|"REQUIRED"|string;
  export type keySize = "K1024"|"K2048"|string;
  export type keyType = "RSA"|string;
  export type managedApplicationInstanceRegionList = ManagedApplicationInstanceRegion[];
  export type managedPolicyArn = string;
  export type markerType = string;
  export type multiValue = "YES"|"NO"|string;
  export type nameIdFormat = "urn:oasis:names:tc:SAML:1.1:nameid-format:X509SubjectName"|"urn:oasis:names:tc:SAML:1.1:nameid-format:WindowsDomainQualifiedName"|"urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"|"urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"|"urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"|"urn:oasis:names:tc:SAML:2.0:nameid-format:transient"|"urn:oasis:names:tc:SAML:2.0:nameid-format:kerberos"|"urn:oasis:names:tc:SAML:2.0:nameid-format:entity"|string;
  export type nameIdFormatList = nameIdFormat[];
  export type nameType = string;
  export type permissionSetIdType = string;
  export type permissionSetNameType = string;
  export type permissionSetPolicyDocumentType = string;
  export type profileIdType = string;
  export type propertyKeyType = string;
  export type propertyMap = {[key: string]: Property};
  export type propertyValueType = string;
  export type provisioningType = "DEFAULT"|"SCIM"|"CONFIGURABLE_SYNC"|string;
  export type provisioningTypes = provisioningType[];
  export type regionNameType = string;
  export type registeredRegionList = RegisteredRegion[];
  export type relayStateType = string;
  export type responseConsumerList = ResponseConsumer[];
  export type s3BucketName = string;
  export type s3Key = string;
  export type s3VersionId = string;
  export type schemaPropertyMap = {[key: string]: SchemaProperty};
  export type schemaPropertyValueList = propertyValueType[];
  export type scopeList = scopeType[];
  export type scopeType = string;
  export type searchKey = "AccountId"|"AccountName"|"AccountEmail"|string;
  export type searchMetadataMap = {[key: string]: searchValue};
  export type searchValue = string;
  export type serviceProviderCertificateList = ServiceProviderCertificateData[];
  export type signatureAlgorithm = "NONE"|"SHA1"|"SHA256"|string;
  export type softDeletedType = "true"|"false"|string;
  export type sourceList = propertyValueType[];
  export type ssoStatusReason = "ACCOUNT_OPT_OUT"|"ACCOUNT_SYNC"|string;
  export type ssoStatusReasons = ssoStatusReason[];
  export type status = "DISABLED"|"ENABLED"|"CREATED"|"DELETING"|"ISOLATED"|string;
  export type swbArnType = string;
  export type templateContextMap = {[key: string]: templateContextValueType};
  export type templateContextValueType = string;
  export type templateIdType = string;
  export type transform = "BASE64"|"LOWERCASE"|"UPPERCASE"|"SHA1"|"SHA256"|"TRUNCATE"|string;
  export type transformList = transform[];
  export type uriType = string;
  export type urlLocationType = string;
  export type versionType = string;
  export type visible = boolean;
  export type windowsUpnType = string;
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2017-11-28"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the SSOInternal client.
   */
  export import Types = SSOInternal;
}
export = SSOInternal;
