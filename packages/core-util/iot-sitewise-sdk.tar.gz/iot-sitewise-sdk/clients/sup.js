require('aws-sdk/lib/node_loader');
var AWS = require('aws-sdk/lib/core');
var Service = AWS.Service;
var apiLoader = AWS.apiLoader;

apiLoader.services['sup'] = {};
AWS.SUP = Service.defineService('sup', ['2017-11-28']);
Object.defineProperty(apiLoader.services['sup'], '2017-11-28', {
  get: function get() {
    var model = require('../apis/SUP-2017-11-28.min.json');
    model.paginators = require('../apis/SUP-2017-11-28.paginators.json').pagination;
    return model;
  },
  enumerable: true,
  configurable: true
});

module.exports = AWS.SUP;
