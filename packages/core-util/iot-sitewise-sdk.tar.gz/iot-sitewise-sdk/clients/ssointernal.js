require('aws-sdk/lib/node_loader');
var AWS = require('aws-sdk/lib/core');
var Service = AWS.Service;
var apiLoader = AWS.apiLoader;

apiLoader.services['ssointernal'] = {};
AWS.SSOInternal = Service.defineService('ssointernal', ['2017-11-28']);
Object.defineProperty(apiLoader.services['ssointernal'], '2017-11-28', {
  get: function get() {
    var model = require('../apis/SSO-2017-11-28.min.json');
    model.paginators = require('../apis/SSO-2017-11-28.paginators.json').pagination;
    return model;
  },
  enumerable: true,
  configurable: true
});

module.exports = AWS.SSOInternal;
