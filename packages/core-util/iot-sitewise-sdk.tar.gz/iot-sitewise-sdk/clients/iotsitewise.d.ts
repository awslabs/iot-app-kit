import {Request} from 'aws-sdk/lib/request';
import {Response} from 'aws-sdk/lib/response';
import {AWSError} from 'aws-sdk/lib/error';
import {Service} from 'aws-sdk/lib/service';
import {WaiterConfiguration} from 'aws-sdk/lib/service';
import {ServiceConfigurationOptions} from 'aws-sdk/lib/service';
import {ConfigBase as Config} from 'aws-sdk/lib/config';
import {EventStream} from 'aws-sdk/lib/event-stream/event-stream';
interface Blob {}
declare class IoTSiteWise extends Service {
  /**
   * Constructs a service object. This object has one method for each API operation.
   */
  constructor(options?: IoTSiteWise.Types.ClientConfiguration)
  config: Config & IoTSiteWise.Types.ClientConfiguration;
  /**
   * 
   */
  associateAssets(params: IoTSiteWise.Types.AssociateAssetsRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  associateAssets(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  associateTimeSeriesToAssetProperty(params: IoTSiteWise.Types.AssociateTimeSeriesToAssetPropertyRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  associateTimeSeriesToAssetProperty(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  authorizeAssetModelPropertyRoutingInternal(params: IoTSiteWise.Types.AuthorizeAssetModelPropertyRoutingInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.AuthorizeAssetModelPropertyRoutingInternalResponse) => void): Request<IoTSiteWise.Types.AuthorizeAssetModelPropertyRoutingInternalResponse, AWSError>;
  /**
   * 
   */
  authorizeAssetModelPropertyRoutingInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.AuthorizeAssetModelPropertyRoutingInternalResponse) => void): Request<IoTSiteWise.Types.AuthorizeAssetModelPropertyRoutingInternalResponse, AWSError>;
  /**
   * 
   */
  authorizeEnableSiteWiseIntegrationInternal(params: IoTSiteWise.Types.AuthorizeEnableSiteWiseIntegrationInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.AuthorizeEnableSiteWiseIntegrationInternalResponse) => void): Request<IoTSiteWise.Types.AuthorizeEnableSiteWiseIntegrationInternalResponse, AWSError>;
  /**
   * 
   */
  authorizeEnableSiteWiseIntegrationInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.AuthorizeEnableSiteWiseIntegrationInternalResponse) => void): Request<IoTSiteWise.Types.AuthorizeEnableSiteWiseIntegrationInternalResponse, AWSError>;
  /**
   * 
   */
  batchAssociateProjectAssets(params: IoTSiteWise.Types.BatchAssociateProjectAssetsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchAssociateProjectAssetsResponse) => void): Request<IoTSiteWise.Types.BatchAssociateProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  batchAssociateProjectAssets(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchAssociateProjectAssetsResponse) => void): Request<IoTSiteWise.Types.BatchAssociateProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  batchAssociateTimeSeriesToAssetProperty(params: IoTSiteWise.Types.BatchAssociateTimeSeriesToAssetPropertyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchAssociateTimeSeriesToAssetPropertyResponse) => void): Request<IoTSiteWise.Types.BatchAssociateTimeSeriesToAssetPropertyResponse, AWSError>;
  /**
   * 
   */
  batchAssociateTimeSeriesToAssetProperty(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchAssociateTimeSeriesToAssetPropertyResponse) => void): Request<IoTSiteWise.Types.BatchAssociateTimeSeriesToAssetPropertyResponse, AWSError>;
  /**
   * 
   */
  batchDisassociateProjectAssets(params: IoTSiteWise.Types.BatchDisassociateProjectAssetsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchDisassociateProjectAssetsResponse) => void): Request<IoTSiteWise.Types.BatchDisassociateProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  batchDisassociateProjectAssets(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchDisassociateProjectAssetsResponse) => void): Request<IoTSiteWise.Types.BatchDisassociateProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyAggregates(params: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyAggregatesResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyAggregates(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyAggregatesResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyAggregatesInternal(params: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesInternalResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyAggregatesInternalResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyAggregatesInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyAggregatesInternalResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyAggregatesInternalResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValue(params: IoTSiteWise.Types.BatchGetAssetPropertyValueRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValue(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValueHistory(params: IoTSiteWise.Types.BatchGetAssetPropertyValueHistoryRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueHistoryResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueHistoryResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValueHistory(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueHistoryResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueHistoryResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValueInternal(params: IoTSiteWise.Types.BatchGetAssetPropertyValueInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueInternalResponse, AWSError>;
  /**
   * 
   */
  batchGetAssetPropertyValueInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchGetAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.BatchGetAssetPropertyValueInternalResponse, AWSError>;
  /**
   * 
   */
  batchPutAssetPropertyValue(params: IoTSiteWise.Types.BatchPutAssetPropertyValueRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchPutAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.BatchPutAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  batchPutAssetPropertyValue(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchPutAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.BatchPutAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  batchPutAssetPropertyValueInternal(params: IoTSiteWise.Types.BatchPutAssetPropertyValueInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.BatchPutAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.BatchPutAssetPropertyValueInternalResponse, AWSError>;
  /**
   * 
   */
  batchPutAssetPropertyValueInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.BatchPutAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.BatchPutAssetPropertyValueInternalResponse, AWSError>;
  /**
   * 
   */
  createAccessPolicy(params: IoTSiteWise.Types.CreateAccessPolicyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAccessPolicyResponse) => void): Request<IoTSiteWise.Types.CreateAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  createAccessPolicy(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAccessPolicyResponse) => void): Request<IoTSiteWise.Types.CreateAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  createAsset(params: IoTSiteWise.Types.CreateAssetRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetResponse) => void): Request<IoTSiteWise.Types.CreateAssetResponse, AWSError>;
  /**
   * 
   */
  createAsset(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetResponse) => void): Request<IoTSiteWise.Types.CreateAssetResponse, AWSError>;
  /**
   * 
   */
  createAssetModel(params: IoTSiteWise.Types.CreateAssetModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetModelResponse) => void): Request<IoTSiteWise.Types.CreateAssetModelResponse, AWSError>;
  /**
   * 
   */
  createAssetModel(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetModelResponse) => void): Request<IoTSiteWise.Types.CreateAssetModelResponse, AWSError>;
  /**
   * 
   */
  createAssetModelCompositeModel(params: IoTSiteWise.Types.CreateAssetModelCompositeModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.CreateAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  createAssetModelCompositeModel(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.CreateAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  createAssistant(params: IoTSiteWise.Types.CreateAssistantRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssistantResponse) => void): Request<IoTSiteWise.Types.CreateAssistantResponse, AWSError>;
  /**
   * 
   */
  createAssistant(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateAssistantResponse) => void): Request<IoTSiteWise.Types.CreateAssistantResponse, AWSError>;
  /**
   * 
   */
  createBulkImportJob(params: IoTSiteWise.Types.CreateBulkImportJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateBulkImportJobResponse) => void): Request<IoTSiteWise.Types.CreateBulkImportJobResponse, AWSError>;
  /**
   * 
   */
  createBulkImportJob(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateBulkImportJobResponse) => void): Request<IoTSiteWise.Types.CreateBulkImportJobResponse, AWSError>;
  /**
   * 
   */
  createBulkImportJobInternal(params: IoTSiteWise.Types.CreateBulkImportJobInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateBulkImportJobInternalResponse) => void): Request<IoTSiteWise.Types.CreateBulkImportJobInternalResponse, AWSError>;
  /**
   * 
   */
  createBulkImportJobInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateBulkImportJobInternalResponse) => void): Request<IoTSiteWise.Types.CreateBulkImportJobInternalResponse, AWSError>;
  /**
   * 
   */
  createComputationJob(params: IoTSiteWise.Types.CreateComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateComputationJobResponse) => void): Request<IoTSiteWise.Types.CreateComputationJobResponse, AWSError>;
  /**
   * 
   */
  createComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateComputationJobResponse) => void): Request<IoTSiteWise.Types.CreateComputationJobResponse, AWSError>;
  /**
   * 
   */
  createDashboard(params: IoTSiteWise.Types.CreateDashboardRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateDashboardResponse) => void): Request<IoTSiteWise.Types.CreateDashboardResponse, AWSError>;
  /**
   * 
   */
  createDashboard(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateDashboardResponse) => void): Request<IoTSiteWise.Types.CreateDashboardResponse, AWSError>;
  /**
   * 
   */
  createGateway(params: IoTSiteWise.Types.CreateGatewayRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateGatewayResponse) => void): Request<IoTSiteWise.Types.CreateGatewayResponse, AWSError>;
  /**
   * 
   */
  createGateway(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateGatewayResponse) => void): Request<IoTSiteWise.Types.CreateGatewayResponse, AWSError>;
  /**
   * 
   */
  createPortal(params: IoTSiteWise.Types.CreatePortalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreatePortalResponse) => void): Request<IoTSiteWise.Types.CreatePortalResponse, AWSError>;
  /**
   * 
   */
  createPortal(callback?: (err: AWSError, data: IoTSiteWise.Types.CreatePortalResponse) => void): Request<IoTSiteWise.Types.CreatePortalResponse, AWSError>;
  /**
   * 
   */
  createProject(params: IoTSiteWise.Types.CreateProjectRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.CreateProjectResponse) => void): Request<IoTSiteWise.Types.CreateProjectResponse, AWSError>;
  /**
   * 
   */
  createProject(callback?: (err: AWSError, data: IoTSiteWise.Types.CreateProjectResponse) => void): Request<IoTSiteWise.Types.CreateProjectResponse, AWSError>;
  /**
   * 
   */
  deleteAccessPolicy(params: IoTSiteWise.Types.DeleteAccessPolicyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAccessPolicyResponse) => void): Request<IoTSiteWise.Types.DeleteAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  deleteAccessPolicy(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAccessPolicyResponse) => void): Request<IoTSiteWise.Types.DeleteAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  deleteAsset(params: IoTSiteWise.Types.DeleteAssetRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetResponse) => void): Request<IoTSiteWise.Types.DeleteAssetResponse, AWSError>;
  /**
   * 
   */
  deleteAsset(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetResponse) => void): Request<IoTSiteWise.Types.DeleteAssetResponse, AWSError>;
  /**
   * 
   */
  deleteAssetModel(params: IoTSiteWise.Types.DeleteAssetModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetModelResponse) => void): Request<IoTSiteWise.Types.DeleteAssetModelResponse, AWSError>;
  /**
   * 
   */
  deleteAssetModel(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetModelResponse) => void): Request<IoTSiteWise.Types.DeleteAssetModelResponse, AWSError>;
  /**
   * 
   */
  deleteAssetModelCompositeModel(params: IoTSiteWise.Types.DeleteAssetModelCompositeModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.DeleteAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  deleteAssetModelCompositeModel(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.DeleteAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  deleteAssistant(params: IoTSiteWise.Types.DeleteAssistantRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssistantResponse) => void): Request<IoTSiteWise.Types.DeleteAssistantResponse, AWSError>;
  /**
   * 
   */
  deleteAssistant(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteAssistantResponse) => void): Request<IoTSiteWise.Types.DeleteAssistantResponse, AWSError>;
  /**
   * 
   */
  deleteComputationJob(params: IoTSiteWise.Types.DeleteComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteComputationJobResponse) => void): Request<IoTSiteWise.Types.DeleteComputationJobResponse, AWSError>;
  /**
   * 
   */
  deleteComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteComputationJobResponse) => void): Request<IoTSiteWise.Types.DeleteComputationJobResponse, AWSError>;
  /**
   * 
   */
  deleteDashboard(params: IoTSiteWise.Types.DeleteDashboardRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteDashboardResponse) => void): Request<IoTSiteWise.Types.DeleteDashboardResponse, AWSError>;
  /**
   * 
   */
  deleteDashboard(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteDashboardResponse) => void): Request<IoTSiteWise.Types.DeleteDashboardResponse, AWSError>;
  /**
   * 
   */
  deleteGateway(params: IoTSiteWise.Types.DeleteGatewayRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteGateway(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteNotificationConfiguration(params: IoTSiteWise.Types.DeleteNotificationConfigurationRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteNotificationConfiguration(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deletePortal(params: IoTSiteWise.Types.DeletePortalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeletePortalResponse) => void): Request<IoTSiteWise.Types.DeletePortalResponse, AWSError>;
  /**
   * 
   */
  deletePortal(callback?: (err: AWSError, data: IoTSiteWise.Types.DeletePortalResponse) => void): Request<IoTSiteWise.Types.DeletePortalResponse, AWSError>;
  /**
   * 
   */
  deleteProject(params: IoTSiteWise.Types.DeleteProjectRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteProjectResponse) => void): Request<IoTSiteWise.Types.DeleteProjectResponse, AWSError>;
  /**
   * 
   */
  deleteProject(callback?: (err: AWSError, data: IoTSiteWise.Types.DeleteProjectResponse) => void): Request<IoTSiteWise.Types.DeleteProjectResponse, AWSError>;
  /**
   * 
   */
  deleteSubscriptionInternal(params: IoTSiteWise.Types.DeleteSubscriptionInternalRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteSubscriptionInternal(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteTimeSeries(params: IoTSiteWise.Types.DeleteTimeSeriesRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  deleteTimeSeries(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  describeAccessPolicy(params: IoTSiteWise.Types.DescribeAccessPolicyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAccessPolicyResponse) => void): Request<IoTSiteWise.Types.DescribeAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  describeAccessPolicy(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAccessPolicyResponse) => void): Request<IoTSiteWise.Types.DescribeAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  describeAction(params: IoTSiteWise.Types.DescribeActionRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeActionResponse) => void): Request<IoTSiteWise.Types.DescribeActionResponse, AWSError>;
  /**
   * 
   */
  describeAction(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeActionResponse) => void): Request<IoTSiteWise.Types.DescribeActionResponse, AWSError>;
  /**
   * 
   */
  describeAsset(params: IoTSiteWise.Types.DescribeAssetRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * 
   */
  describeAsset(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * 
   */
  describeAssetCompositeModel(params: IoTSiteWise.Types.DescribeAssetCompositeModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetCompositeModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetCompositeModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetCompositeModel(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetCompositeModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetCompositeModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetModel(params: IoTSiteWise.Types.DescribeAssetModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetModel(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetModelCompositeModel(params: IoTSiteWise.Types.DescribeAssetModelCompositeModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetModelCompositeModel(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  describeAssetProperty(params: IoTSiteWise.Types.DescribeAssetPropertyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetPropertyResponse) => void): Request<IoTSiteWise.Types.DescribeAssetPropertyResponse, AWSError>;
  /**
   * 
   */
  describeAssetProperty(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetPropertyResponse) => void): Request<IoTSiteWise.Types.DescribeAssetPropertyResponse, AWSError>;
  /**
   * 
   */
  describeBulkImportJob(params: IoTSiteWise.Types.DescribeBulkImportJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeBulkImportJobResponse) => void): Request<IoTSiteWise.Types.DescribeBulkImportJobResponse, AWSError>;
  /**
   * 
   */
  describeBulkImportJob(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeBulkImportJobResponse) => void): Request<IoTSiteWise.Types.DescribeBulkImportJobResponse, AWSError>;
  /**
   * 
   */
  describeBulkImportJobInternal(params: IoTSiteWise.Types.DescribeBulkImportJobInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeBulkImportJobInternalResponse) => void): Request<IoTSiteWise.Types.DescribeBulkImportJobInternalResponse, AWSError>;
  /**
   * 
   */
  describeBulkImportJobInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeBulkImportJobInternalResponse) => void): Request<IoTSiteWise.Types.DescribeBulkImportJobInternalResponse, AWSError>;
  /**
   * 
   */
  describeComputationJob(params: IoTSiteWise.Types.DescribeComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeComputationJobResponse) => void): Request<IoTSiteWise.Types.DescribeComputationJobResponse, AWSError>;
  /**
   * 
   */
  describeComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeComputationJobResponse) => void): Request<IoTSiteWise.Types.DescribeComputationJobResponse, AWSError>;
  /**
   * 
   */
  describeContextualQueryConfiguration(params: IoTSiteWise.Types.DescribeContextualQueryConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeContextualQueryConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeContextualQueryConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeContextualQueryConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeContextualQueryConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeContextualQueryConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeContextualQueryConfigurationInternal(params: IoTSiteWise.Types.DescribeContextualQueryConfigurationInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeContextualQueryConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.DescribeContextualQueryConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  describeContextualQueryConfigurationInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeContextualQueryConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.DescribeContextualQueryConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  describeDashboard(params: IoTSiteWise.Types.DescribeDashboardRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeDashboardResponse) => void): Request<IoTSiteWise.Types.DescribeDashboardResponse, AWSError>;
  /**
   * 
   */
  describeDashboard(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeDashboardResponse) => void): Request<IoTSiteWise.Types.DescribeDashboardResponse, AWSError>;
  /**
   * 
   */
  describeDefaultEncryptionConfiguration(params: IoTSiteWise.Types.DescribeDefaultEncryptionConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeDefaultEncryptionConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeDefaultEncryptionConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeDefaultEncryptionConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeDefaultEncryptionConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeDefaultEncryptionConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeGateway(params: IoTSiteWise.Types.DescribeGatewayRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeGatewayResponse) => void): Request<IoTSiteWise.Types.DescribeGatewayResponse, AWSError>;
  /**
   * 
   */
  describeGateway(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeGatewayResponse) => void): Request<IoTSiteWise.Types.DescribeGatewayResponse, AWSError>;
  /**
   * 
   */
  describeGatewayCapabilityConfiguration(params: IoTSiteWise.Types.DescribeGatewayCapabilityConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeGatewayCapabilityConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeGatewayCapabilityConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeGatewayCapabilityConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeGatewayCapabilityConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeGatewayCapabilityConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeLoggingOptions(params: IoTSiteWise.Types.DescribeLoggingOptionsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeLoggingOptionsResponse) => void): Request<IoTSiteWise.Types.DescribeLoggingOptionsResponse, AWSError>;
  /**
   * 
   */
  describeLoggingOptions(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeLoggingOptionsResponse) => void): Request<IoTSiteWise.Types.DescribeLoggingOptionsResponse, AWSError>;
  /**
   * 
   */
  describePortal(params: IoTSiteWise.Types.DescribePortalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
  /**
   * 
   */
  describePortal(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
  /**
   * 
   */
  describeProject(params: IoTSiteWise.Types.DescribeProjectRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeProjectResponse) => void): Request<IoTSiteWise.Types.DescribeProjectResponse, AWSError>;
  /**
   * 
   */
  describeProject(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeProjectResponse) => void): Request<IoTSiteWise.Types.DescribeProjectResponse, AWSError>;
  /**
   * 
   */
  describeStorageConfiguration(params: IoTSiteWise.Types.DescribeStorageConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeStorageConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeStorageConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeStorageConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeStorageConfigurationResponse) => void): Request<IoTSiteWise.Types.DescribeStorageConfigurationResponse, AWSError>;
  /**
   * 
   */
  describeStorageConfigurationInternal(params: IoTSiteWise.Types.DescribeStorageConfigurationInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeStorageConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.DescribeStorageConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  describeStorageConfigurationInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeStorageConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.DescribeStorageConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  describeSubscriptionInternal(params: IoTSiteWise.Types.DescribeSubscriptionInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeSubscriptionInternalResponse) => void): Request<IoTSiteWise.Types.DescribeSubscriptionInternalResponse, AWSError>;
  /**
   * 
   */
  describeSubscriptionInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeSubscriptionInternalResponse) => void): Request<IoTSiteWise.Types.DescribeSubscriptionInternalResponse, AWSError>;
  /**
   * 
   */
  describeTimeSeries(params: IoTSiteWise.Types.DescribeTimeSeriesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeTimeSeriesResponse) => void): Request<IoTSiteWise.Types.DescribeTimeSeriesResponse, AWSError>;
  /**
   * 
   */
  describeTimeSeries(callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeTimeSeriesResponse) => void): Request<IoTSiteWise.Types.DescribeTimeSeriesResponse, AWSError>;
  /**
   * 
   */
  disassociateAssets(params: IoTSiteWise.Types.DisassociateAssetsRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  disassociateAssets(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  disassociateTimeSeriesFromAssetProperty(params: IoTSiteWise.Types.DisassociateTimeSeriesFromAssetPropertyRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  disassociateTimeSeriesFromAssetProperty(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  executeAction(params: IoTSiteWise.Types.ExecuteActionRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ExecuteActionResponse) => void): Request<IoTSiteWise.Types.ExecuteActionResponse, AWSError>;
  /**
   * 
   */
  executeAction(callback?: (err: AWSError, data: IoTSiteWise.Types.ExecuteActionResponse) => void): Request<IoTSiteWise.Types.ExecuteActionResponse, AWSError>;
  /**
   * 
   */
  executeQuery(params: IoTSiteWise.Types.ExecuteQueryRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ExecuteQueryResponse) => void): Request<IoTSiteWise.Types.ExecuteQueryResponse, AWSError>;
  /**
   * 
   */
  executeQuery(callback?: (err: AWSError, data: IoTSiteWise.Types.ExecuteQueryResponse) => void): Request<IoTSiteWise.Types.ExecuteQueryResponse, AWSError>;
  /**
   * 
   */
  gatewaysLockServiceLinkedRoleInternal(params: IoTSiteWise.Types.LockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  gatewaysLockServiceLinkedRoleInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  gatewaysUnlockServiceLinkedRoleInternal(params: IoTSiteWise.Types.UnlockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  gatewaysUnlockServiceLinkedRoleInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  gatewaysVerifyResourcesExistForTagrisInternal(params: IoTSiteWise.Types.TagrisVerifyResourcesExistInput, callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * 
   */
  gatewaysVerifyResourcesExistForTagrisInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * 
   */
  getAssetPropertyAggregates(params: IoTSiteWise.Types.GetAssetPropertyAggregatesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyAggregatesResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyAggregatesResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyAggregates(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyAggregatesResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyAggregatesResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValue(params: IoTSiteWise.Types.GetAssetPropertyValueRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValue(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueHistory(params: IoTSiteWise.Types.GetAssetPropertyValueHistoryRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueHistoryResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueHistoryResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueHistory(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueHistoryResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueHistoryResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueHistoryInternal(params: IoTSiteWise.Types.GetAssetPropertyValueHistoryInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueHistoryInternalResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueHistoryInternalResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueHistoryInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueHistoryInternalResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueHistoryInternalResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueInternal(params: IoTSiteWise.Types.GetAssetPropertyValueInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueInternalResponse, AWSError>;
  /**
   * 
   */
  getAssetPropertyValueInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssetPropertyValueInternalResponse) => void): Request<IoTSiteWise.Types.GetAssetPropertyValueInternalResponse, AWSError>;
  /**
   * Get an Assistant
   */
  getAssistant(params: IoTSiteWise.Types.GetAssistantRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssistantResponse) => void): Request<IoTSiteWise.Types.GetAssistantResponse, AWSError>;
  /**
   * Get an Assistant
   */
  getAssistant(callback?: (err: AWSError, data: IoTSiteWise.Types.GetAssistantResponse) => void): Request<IoTSiteWise.Types.GetAssistantResponse, AWSError>;
  /**
   * 
   */
  getContextualQueryExecution(params: IoTSiteWise.Types.GetContextualQueryExecutionRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.GetContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  getContextualQueryExecution(callback?: (err: AWSError, data: IoTSiteWise.Types.GetContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.GetContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  getContextualQueryResults(params: IoTSiteWise.Types.GetContextualQueryResultsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetContextualQueryResultsResponse) => void): Request<IoTSiteWise.Types.GetContextualQueryResultsResponse, AWSError>;
  /**
   * 
   */
  getContextualQueryResults(callback?: (err: AWSError, data: IoTSiteWise.Types.GetContextualQueryResultsResponse) => void): Request<IoTSiteWise.Types.GetContextualQueryResultsResponse, AWSError>;
  /**
   * 
   */
  getInterpolatedAssetPropertyValues(params: IoTSiteWise.Types.GetInterpolatedAssetPropertyValuesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.GetInterpolatedAssetPropertyValuesResponse) => void): Request<IoTSiteWise.Types.GetInterpolatedAssetPropertyValuesResponse, AWSError>;
  /**
   * 
   */
  getInterpolatedAssetPropertyValues(callback?: (err: AWSError, data: IoTSiteWise.Types.GetInterpolatedAssetPropertyValuesResponse) => void): Request<IoTSiteWise.Types.GetInterpolatedAssetPropertyValuesResponse, AWSError>;
  /**
   * Invoke AI Assistant
   */
  invokeAssistant(params: IoTSiteWise.Types.InvokeAssistantRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.InvokeAssistantResponse) => void): Request<IoTSiteWise.Types.InvokeAssistantResponse, AWSError>;
  /**
   * Invoke AI Assistant
   */
  invokeAssistant(callback?: (err: AWSError, data: IoTSiteWise.Types.InvokeAssistantResponse) => void): Request<IoTSiteWise.Types.InvokeAssistantResponse, AWSError>;
  /**
   * 
   */
  listAccessPolicies(params: IoTSiteWise.Types.ListAccessPoliciesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAccessPoliciesResponse) => void): Request<IoTSiteWise.Types.ListAccessPoliciesResponse, AWSError>;
  /**
   * 
   */
  listAccessPolicies(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAccessPoliciesResponse) => void): Request<IoTSiteWise.Types.ListAccessPoliciesResponse, AWSError>;
  /**
   * 
   */
  listActions(params: IoTSiteWise.Types.ListActionsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListActionsResponse) => void): Request<IoTSiteWise.Types.ListActionsResponse, AWSError>;
  /**
   * 
   */
  listActions(callback?: (err: AWSError, data: IoTSiteWise.Types.ListActionsResponse) => void): Request<IoTSiteWise.Types.ListActionsResponse, AWSError>;
  /**
   * 
   */
  listAssetModelCompositeModels(params: IoTSiteWise.Types.ListAssetModelCompositeModelsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelCompositeModelsResponse) => void): Request<IoTSiteWise.Types.ListAssetModelCompositeModelsResponse, AWSError>;
  /**
   * 
   */
  listAssetModelCompositeModels(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelCompositeModelsResponse) => void): Request<IoTSiteWise.Types.ListAssetModelCompositeModelsResponse, AWSError>;
  /**
   * 
   */
  listAssetModelProperties(params: IoTSiteWise.Types.ListAssetModelPropertiesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelPropertiesResponse) => void): Request<IoTSiteWise.Types.ListAssetModelPropertiesResponse, AWSError>;
  /**
   * 
   */
  listAssetModelProperties(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelPropertiesResponse) => void): Request<IoTSiteWise.Types.ListAssetModelPropertiesResponse, AWSError>;
  /**
   * 
   */
  listAssetModels(params: IoTSiteWise.Types.ListAssetModelsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelsResponse) => void): Request<IoTSiteWise.Types.ListAssetModelsResponse, AWSError>;
  /**
   * 
   */
  listAssetModels(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetModelsResponse) => void): Request<IoTSiteWise.Types.ListAssetModelsResponse, AWSError>;
  /**
   * 
   */
  listAssetProperties(params: IoTSiteWise.Types.ListAssetPropertiesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetPropertiesResponse) => void): Request<IoTSiteWise.Types.ListAssetPropertiesResponse, AWSError>;
  /**
   * 
   */
  listAssetProperties(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetPropertiesResponse) => void): Request<IoTSiteWise.Types.ListAssetPropertiesResponse, AWSError>;
  /**
   * 
   */
  listAssetRelationships(params: IoTSiteWise.Types.ListAssetRelationshipsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetRelationshipsResponse) => void): Request<IoTSiteWise.Types.ListAssetRelationshipsResponse, AWSError>;
  /**
   * 
   */
  listAssetRelationships(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetRelationshipsResponse) => void): Request<IoTSiteWise.Types.ListAssetRelationshipsResponse, AWSError>;
  /**
   * 
   */
  listAssets(params: IoTSiteWise.Types.ListAssetsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetsResponse) => void): Request<IoTSiteWise.Types.ListAssetsResponse, AWSError>;
  /**
   * 
   */
  listAssets(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssetsResponse) => void): Request<IoTSiteWise.Types.ListAssetsResponse, AWSError>;
  /**
   * Get an Assistant
   */
  listAssistants(params: IoTSiteWise.Types.ListAssistantsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssistantsResponse) => void): Request<IoTSiteWise.Types.ListAssistantsResponse, AWSError>;
  /**
   * Get an Assistant
   */
  listAssistants(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssistantsResponse) => void): Request<IoTSiteWise.Types.ListAssistantsResponse, AWSError>;
  /**
   * 
   */
  listAssociatedAssets(params: IoTSiteWise.Types.ListAssociatedAssetsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssociatedAssetsResponse) => void): Request<IoTSiteWise.Types.ListAssociatedAssetsResponse, AWSError>;
  /**
   * 
   */
  listAssociatedAssets(callback?: (err: AWSError, data: IoTSiteWise.Types.ListAssociatedAssetsResponse) => void): Request<IoTSiteWise.Types.ListAssociatedAssetsResponse, AWSError>;
  /**
   * 
   */
  listBulkImportJobs(params: IoTSiteWise.Types.ListBulkImportJobsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListBulkImportJobsResponse) => void): Request<IoTSiteWise.Types.ListBulkImportJobsResponse, AWSError>;
  /**
   * 
   */
  listBulkImportJobs(callback?: (err: AWSError, data: IoTSiteWise.Types.ListBulkImportJobsResponse) => void): Request<IoTSiteWise.Types.ListBulkImportJobsResponse, AWSError>;
  /**
   * 
   */
  listBulkImportJobsInternal(params: IoTSiteWise.Types.ListBulkImportJobsInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListBulkImportJobsInternalResponse) => void): Request<IoTSiteWise.Types.ListBulkImportJobsInternalResponse, AWSError>;
  /**
   * 
   */
  listBulkImportJobsInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.ListBulkImportJobsInternalResponse) => void): Request<IoTSiteWise.Types.ListBulkImportJobsInternalResponse, AWSError>;
  /**
   * 
   */
  listCompositionRelationships(params: IoTSiteWise.Types.ListCompositionRelationshipsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListCompositionRelationshipsResponse) => void): Request<IoTSiteWise.Types.ListCompositionRelationshipsResponse, AWSError>;
  /**
   * 
   */
  listCompositionRelationships(callback?: (err: AWSError, data: IoTSiteWise.Types.ListCompositionRelationshipsResponse) => void): Request<IoTSiteWise.Types.ListCompositionRelationshipsResponse, AWSError>;
  /**
   * 
   */
  listComputationJobs(params: IoTSiteWise.Types.ListComputationJobsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListComputationJobsResponse) => void): Request<IoTSiteWise.Types.ListComputationJobsResponse, AWSError>;
  /**
   * 
   */
  listComputationJobs(callback?: (err: AWSError, data: IoTSiteWise.Types.ListComputationJobsResponse) => void): Request<IoTSiteWise.Types.ListComputationJobsResponse, AWSError>;
  /**
   * 
   */
  listContextualQueries(params: IoTSiteWise.Types.ListContextualQueriesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListContextualQueriesResponse) => void): Request<IoTSiteWise.Types.ListContextualQueriesResponse, AWSError>;
  /**
   * 
   */
  listContextualQueries(callback?: (err: AWSError, data: IoTSiteWise.Types.ListContextualQueriesResponse) => void): Request<IoTSiteWise.Types.ListContextualQueriesResponse, AWSError>;
  /**
   * 
   */
  listDashboards(params: IoTSiteWise.Types.ListDashboardsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListDashboardsResponse) => void): Request<IoTSiteWise.Types.ListDashboardsResponse, AWSError>;
  /**
   * 
   */
  listDashboards(callback?: (err: AWSError, data: IoTSiteWise.Types.ListDashboardsResponse) => void): Request<IoTSiteWise.Types.ListDashboardsResponse, AWSError>;
  /**
   * 
   */
  listGateways(params: IoTSiteWise.Types.ListGatewaysRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListGatewaysResponse) => void): Request<IoTSiteWise.Types.ListGatewaysResponse, AWSError>;
  /**
   * 
   */
  listGateways(callback?: (err: AWSError, data: IoTSiteWise.Types.ListGatewaysResponse) => void): Request<IoTSiteWise.Types.ListGatewaysResponse, AWSError>;
  /**
   * 
   */
  listNotificationConfigurations(params: IoTSiteWise.Types.ListNotificationConfigurationsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListNotificationConfigurationsResponse) => void): Request<IoTSiteWise.Types.ListNotificationConfigurationsResponse, AWSError>;
  /**
   * 
   */
  listNotificationConfigurations(callback?: (err: AWSError, data: IoTSiteWise.Types.ListNotificationConfigurationsResponse) => void): Request<IoTSiteWise.Types.ListNotificationConfigurationsResponse, AWSError>;
  /**
   * 
   */
  listNotificationConfigurationsInternal(params: IoTSiteWise.Types.ListNotificationConfigurationsInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListNotificationConfigurationsInternalResponse) => void): Request<IoTSiteWise.Types.ListNotificationConfigurationsInternalResponse, AWSError>;
  /**
   * 
   */
  listNotificationConfigurationsInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.ListNotificationConfigurationsInternalResponse) => void): Request<IoTSiteWise.Types.ListNotificationConfigurationsInternalResponse, AWSError>;
  /**
   * 
   */
  listPortals(params: IoTSiteWise.Types.ListPortalsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListPortalsResponse) => void): Request<IoTSiteWise.Types.ListPortalsResponse, AWSError>;
  /**
   * 
   */
  listPortals(callback?: (err: AWSError, data: IoTSiteWise.Types.ListPortalsResponse) => void): Request<IoTSiteWise.Types.ListPortalsResponse, AWSError>;
  /**
   * 
   */
  listProjectAssets(params: IoTSiteWise.Types.ListProjectAssetsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListProjectAssetsResponse) => void): Request<IoTSiteWise.Types.ListProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  listProjectAssets(callback?: (err: AWSError, data: IoTSiteWise.Types.ListProjectAssetsResponse) => void): Request<IoTSiteWise.Types.ListProjectAssetsResponse, AWSError>;
  /**
   * 
   */
  listProjects(params: IoTSiteWise.Types.ListProjectsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListProjectsResponse) => void): Request<IoTSiteWise.Types.ListProjectsResponse, AWSError>;
  /**
   * 
   */
  listProjects(callback?: (err: AWSError, data: IoTSiteWise.Types.ListProjectsResponse) => void): Request<IoTSiteWise.Types.ListProjectsResponse, AWSError>;
  /**
   * 
   */
  listSubscriptionsInternal(params: IoTSiteWise.Types.ListSubscriptionsInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListSubscriptionsInternalResponse) => void): Request<IoTSiteWise.Types.ListSubscriptionsInternalResponse, AWSError>;
  /**
   * 
   */
  listSubscriptionsInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.ListSubscriptionsInternalResponse) => void): Request<IoTSiteWise.Types.ListSubscriptionsInternalResponse, AWSError>;
  /**
   * 
   */
  listTagsForResource(params: IoTSiteWise.Types.ListTagsForResourceRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListTagsForResourceResponse) => void): Request<IoTSiteWise.Types.ListTagsForResourceResponse, AWSError>;
  /**
   * 
   */
  listTagsForResource(callback?: (err: AWSError, data: IoTSiteWise.Types.ListTagsForResourceResponse) => void): Request<IoTSiteWise.Types.ListTagsForResourceResponse, AWSError>;
  /**
   * 
   */
  listTimeSeries(params: IoTSiteWise.Types.ListTimeSeriesRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ListTimeSeriesResponse) => void): Request<IoTSiteWise.Types.ListTimeSeriesResponse, AWSError>;
  /**
   * 
   */
  listTimeSeries(callback?: (err: AWSError, data: IoTSiteWise.Types.ListTimeSeriesResponse) => void): Request<IoTSiteWise.Types.ListTimeSeriesResponse, AWSError>;
  /**
   * 
   */
  lockServiceLinkedRole(params: IoTSiteWise.Types.LockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  lockServiceLinkedRole(callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  modelsLockServiceLinkedRoleInternal(params: IoTSiteWise.Types.LockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  modelsLockServiceLinkedRoleInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.LockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.LockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  modelsUnlockServiceLinkedRoleInternal(params: IoTSiteWise.Types.UnlockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  modelsUnlockServiceLinkedRoleInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  modelsVerifyResourcesExistForTagrisInternal(params: IoTSiteWise.Types.TagrisVerifyResourcesExistInput, callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * 
   */
  modelsVerifyResourcesExistForTagrisInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * 
   */
  pauseComputationJob(params: IoTSiteWise.Types.PauseComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PauseComputationJobResponse) => void): Request<IoTSiteWise.Types.PauseComputationJobResponse, AWSError>;
  /**
   * 
   */
  pauseComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.PauseComputationJobResponse) => void): Request<IoTSiteWise.Types.PauseComputationJobResponse, AWSError>;
  /**
   * 
   */
  putContextualQueryConfiguration(params: IoTSiteWise.Types.PutContextualQueryConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutContextualQueryConfigurationResponse) => void): Request<IoTSiteWise.Types.PutContextualQueryConfigurationResponse, AWSError>;
  /**
   * 
   */
  putContextualQueryConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.PutContextualQueryConfigurationResponse) => void): Request<IoTSiteWise.Types.PutContextualQueryConfigurationResponse, AWSError>;
  /**
   * 
   */
  putDefaultEncryptionConfiguration(params: IoTSiteWise.Types.PutDefaultEncryptionConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutDefaultEncryptionConfigurationResponse) => void): Request<IoTSiteWise.Types.PutDefaultEncryptionConfigurationResponse, AWSError>;
  /**
   * 
   */
  putDefaultEncryptionConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.PutDefaultEncryptionConfigurationResponse) => void): Request<IoTSiteWise.Types.PutDefaultEncryptionConfigurationResponse, AWSError>;
  /**
   * 
   */
  putLoggingOptions(params: IoTSiteWise.Types.PutLoggingOptionsRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutLoggingOptionsResponse) => void): Request<IoTSiteWise.Types.PutLoggingOptionsResponse, AWSError>;
  /**
   * 
   */
  putLoggingOptions(callback?: (err: AWSError, data: IoTSiteWise.Types.PutLoggingOptionsResponse) => void): Request<IoTSiteWise.Types.PutLoggingOptionsResponse, AWSError>;
  /**
   * 
   */
  putNotificationConfiguration(params: IoTSiteWise.Types.PutNotificationConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutNotificationConfigurationResponse) => void): Request<IoTSiteWise.Types.PutNotificationConfigurationResponse, AWSError>;
  /**
   * 
   */
  putNotificationConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.PutNotificationConfigurationResponse) => void): Request<IoTSiteWise.Types.PutNotificationConfigurationResponse, AWSError>;
  /**
   * 
   */
  putStorageConfiguration(params: IoTSiteWise.Types.PutStorageConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutStorageConfigurationResponse) => void): Request<IoTSiteWise.Types.PutStorageConfigurationResponse, AWSError>;
  /**
   * 
   */
  putStorageConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.PutStorageConfigurationResponse) => void): Request<IoTSiteWise.Types.PutStorageConfigurationResponse, AWSError>;
  /**
   * 
   */
  putStorageConfigurationInternal(params: IoTSiteWise.Types.PutStorageConfigurationInternalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.PutStorageConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.PutStorageConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  putStorageConfigurationInternal(callback?: (err: AWSError, data: IoTSiteWise.Types.PutStorageConfigurationInternalResponse) => void): Request<IoTSiteWise.Types.PutStorageConfigurationInternalResponse, AWSError>;
  /**
   * 
   */
  resumeComputationJob(params: IoTSiteWise.Types.ResumeComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.ResumeComputationJobResponse) => void): Request<IoTSiteWise.Types.ResumeComputationJobResponse, AWSError>;
  /**
   * 
   */
  resumeComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.ResumeComputationJobResponse) => void): Request<IoTSiteWise.Types.ResumeComputationJobResponse, AWSError>;
  /**
   * 
   */
  startContextualQueryExecution(params: IoTSiteWise.Types.StartContextualQueryExecutionRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.StartContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.StartContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  startContextualQueryExecution(callback?: (err: AWSError, data: IoTSiteWise.Types.StartContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.StartContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  stopContextualQueryExecution(params: IoTSiteWise.Types.StopContextualQueryExecutionRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.StopContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.StopContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  stopContextualQueryExecution(callback?: (err: AWSError, data: IoTSiteWise.Types.StopContextualQueryExecutionResponse) => void): Request<IoTSiteWise.Types.StopContextualQueryExecutionResponse, AWSError>;
  /**
   * 
   */
  tagResource(params: IoTSiteWise.Types.TagResourceRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.TagResourceResponse) => void): Request<IoTSiteWise.Types.TagResourceResponse, AWSError>;
  /**
   * 
   */
  tagResource(callback?: (err: AWSError, data: IoTSiteWise.Types.TagResourceResponse) => void): Request<IoTSiteWise.Types.TagResourceResponse, AWSError>;
  /**
   * 
   */
  unlockServiceLinkedRole(params: IoTSiteWise.Types.UnlockServiceLinkedRoleRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  unlockServiceLinkedRole(callback?: (err: AWSError, data: IoTSiteWise.Types.UnlockServiceLinkedRoleResponse) => void): Request<IoTSiteWise.Types.UnlockServiceLinkedRoleResponse, AWSError>;
  /**
   * 
   */
  untagResource(params: IoTSiteWise.Types.UntagResourceRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UntagResourceResponse) => void): Request<IoTSiteWise.Types.UntagResourceResponse, AWSError>;
  /**
   * 
   */
  untagResource(callback?: (err: AWSError, data: IoTSiteWise.Types.UntagResourceResponse) => void): Request<IoTSiteWise.Types.UntagResourceResponse, AWSError>;
  /**
   * 
   */
  updateAccessPolicy(params: IoTSiteWise.Types.UpdateAccessPolicyRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAccessPolicyResponse) => void): Request<IoTSiteWise.Types.UpdateAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  updateAccessPolicy(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAccessPolicyResponse) => void): Request<IoTSiteWise.Types.UpdateAccessPolicyResponse, AWSError>;
  /**
   * 
   */
  updateAsset(params: IoTSiteWise.Types.UpdateAssetRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetResponse) => void): Request<IoTSiteWise.Types.UpdateAssetResponse, AWSError>;
  /**
   * 
   */
  updateAsset(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetResponse) => void): Request<IoTSiteWise.Types.UpdateAssetResponse, AWSError>;
  /**
   * 
   */
  updateAssetModel(params: IoTSiteWise.Types.UpdateAssetModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetModelResponse) => void): Request<IoTSiteWise.Types.UpdateAssetModelResponse, AWSError>;
  /**
   * 
   */
  updateAssetModel(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetModelResponse) => void): Request<IoTSiteWise.Types.UpdateAssetModelResponse, AWSError>;
  /**
   * 
   */
  updateAssetModelCompositeModel(params: IoTSiteWise.Types.UpdateAssetModelCompositeModelRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.UpdateAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  updateAssetModelCompositeModel(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateAssetModelCompositeModelResponse) => void): Request<IoTSiteWise.Types.UpdateAssetModelCompositeModelResponse, AWSError>;
  /**
   * 
   */
  updateAssetProperty(params: IoTSiteWise.Types.UpdateAssetPropertyRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  updateAssetProperty(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  updateComputationJob(params: IoTSiteWise.Types.UpdateComputationJobRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateComputationJobResponse) => void): Request<IoTSiteWise.Types.UpdateComputationJobResponse, AWSError>;
  /**
   * 
   */
  updateComputationJob(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateComputationJobResponse) => void): Request<IoTSiteWise.Types.UpdateComputationJobResponse, AWSError>;
  /**
   * 
   */
  updateDashboard(params: IoTSiteWise.Types.UpdateDashboardRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateDashboardResponse) => void): Request<IoTSiteWise.Types.UpdateDashboardResponse, AWSError>;
  /**
   * 
   */
  updateDashboard(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateDashboardResponse) => void): Request<IoTSiteWise.Types.UpdateDashboardResponse, AWSError>;
  /**
   * 
   */
  updateGateway(params: IoTSiteWise.Types.UpdateGatewayRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  updateGateway(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  updateGatewayCapabilityConfiguration(params: IoTSiteWise.Types.UpdateGatewayCapabilityConfigurationRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateGatewayCapabilityConfigurationResponse) => void): Request<IoTSiteWise.Types.UpdateGatewayCapabilityConfigurationResponse, AWSError>;
  /**
   * 
   */
  updateGatewayCapabilityConfiguration(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateGatewayCapabilityConfigurationResponse) => void): Request<IoTSiteWise.Types.UpdateGatewayCapabilityConfigurationResponse, AWSError>;
  /**
   * 
   */
  updatePortal(params: IoTSiteWise.Types.UpdatePortalRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdatePortalResponse) => void): Request<IoTSiteWise.Types.UpdatePortalResponse, AWSError>;
  /**
   * 
   */
  updatePortal(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdatePortalResponse) => void): Request<IoTSiteWise.Types.UpdatePortalResponse, AWSError>;
  /**
   * 
   */
  updateProject(params: IoTSiteWise.Types.UpdateProjectRequest, callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateProjectResponse) => void): Request<IoTSiteWise.Types.UpdateProjectResponse, AWSError>;
  /**
   * 
   */
  updateProject(callback?: (err: AWSError, data: IoTSiteWise.Types.UpdateProjectResponse) => void): Request<IoTSiteWise.Types.UpdateProjectResponse, AWSError>;
  /**
   * 
   */
  updateSubscriptionInternal(params: IoTSiteWise.Types.UpdateSubscriptionInternalRequest, callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  updateSubscriptionInternal(callback?: (err: AWSError, data: {}) => void): Request<{}, AWSError>;
  /**
   * 
   */
  verifyResourcesExistForTagris(params: IoTSiteWise.Types.TagrisVerifyResourcesExistInput, callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * 
   */
  verifyResourcesExistForTagris(callback?: (err: AWSError, data: IoTSiteWise.Types.TagrisVerifyResourcesExistOutput) => void): Request<IoTSiteWise.Types.TagrisVerifyResourcesExistOutput, AWSError>;
  /**
   * Waits for the assetModelNotExists state by periodically calling the underlying IoTSiteWise.describeAssetModeloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetModelNotExists", params: IoTSiteWise.Types.DescribeAssetModelRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * Waits for the assetModelNotExists state by periodically calling the underlying IoTSiteWise.describeAssetModeloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetModelNotExists", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * Waits for the assetModelActive state by periodically calling the underlying IoTSiteWise.describeAssetModeloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetModelActive", params: IoTSiteWise.Types.DescribeAssetModelRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * Waits for the assetModelActive state by periodically calling the underlying IoTSiteWise.describeAssetModeloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetModelActive", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetModelResponse) => void): Request<IoTSiteWise.Types.DescribeAssetModelResponse, AWSError>;
  /**
   * Waits for the assetNotExists state by periodically calling the underlying IoTSiteWise.describeAssetoperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetNotExists", params: IoTSiteWise.Types.DescribeAssetRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * Waits for the assetNotExists state by periodically calling the underlying IoTSiteWise.describeAssetoperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetNotExists", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * Waits for the assetActive state by periodically calling the underlying IoTSiteWise.describeAssetoperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetActive", params: IoTSiteWise.Types.DescribeAssetRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * Waits for the assetActive state by periodically calling the underlying IoTSiteWise.describeAssetoperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "assetActive", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribeAssetResponse) => void): Request<IoTSiteWise.Types.DescribeAssetResponse, AWSError>;
  /**
   * Waits for the portalNotExists state by periodically calling the underlying IoTSiteWise.describePortaloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "portalNotExists", params: IoTSiteWise.Types.DescribePortalRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
  /**
   * Waits for the portalNotExists state by periodically calling the underlying IoTSiteWise.describePortaloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "portalNotExists", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
  /**
   * Waits for the portalActive state by periodically calling the underlying IoTSiteWise.describePortaloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "portalActive", params: IoTSiteWise.Types.DescribePortalRequest & {$waiter?: WaiterConfiguration}, callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
  /**
   * Waits for the portalActive state by periodically calling the underlying IoTSiteWise.describePortaloperation every 3 seconds (at most 20 times).
   */
  waitFor(state: "portalActive", callback?: (err: AWSError, data: IoTSiteWise.Types.DescribePortalResponse) => void): Request<IoTSiteWise.Types.DescribePortalResponse, AWSError>;
}
declare namespace IoTSiteWise {
  export type ARN = string;
  export type AccessPolicySummaries = AccessPolicySummary[];
  export interface AccessPolicySummary {
    id: ID;
    identity: Identity;
    resource: Resource;
    permission: Permission;
    creationDate?: Timestamp;
    lastUpdateDate?: Timestamp;
  }
  export interface ActionDefinition {
    actionDefinitionId: ID;
    actionName: Name;
    actionType: Name;
  }
  export type ActionDefinitions = ActionDefinition[];
  export interface ActionPayload {
    stringValue: ActionPayloadString;
  }
  export type ActionPayloadString = string;
  export type ActionSummaries = ActionSummary[];
  export interface ActionSummary {
    actionId?: ID;
    actionDefinitionId?: ID;
    targetResource?: TargetResource;
  }
  export type AdaptiveIngestion = boolean;
  export type AggregateType = "AVERAGE"|"COUNT"|"MAXIMUM"|"MINIMUM"|"SUM"|"STANDARD_DEVIATION"|string;
  export type AggregateTypes = AggregateType[];
  export type AggregatedDoubleValue = number;
  export interface AggregatedValue {
    timestamp: Timestamp;
    quality?: Quality;
    value: Aggregates;
  }
  export type AggregatedValues = AggregatedValue[];
  export interface Aggregates {
    average?: AggregatedDoubleValue;
    count?: AggregatedDoubleValue;
    maximum?: AggregatedDoubleValue;
    minimum?: AggregatedDoubleValue;
    sum?: AggregatedDoubleValue;
    standardDeviation?: AggregatedDoubleValue;
  }
  export interface Alarms {
    alarmRoleArn: IamArn;
    notificationLambdaArn?: ARN;
  }
  export type Alias = string;
  export type AmazonResourceName = string;
  export interface AssetCompositeModel {
    name: Name;
    description?: Description;
    type: Name;
    properties: AssetProperties;
    id?: ID;
    externalId?: ExternalId;
  }
  export type AssetCompositeModelPath = AssetCompositeModelPathSegment[];
  export interface AssetCompositeModelPathSegment {
    id?: ID;
    name?: Name;
  }
  export type AssetCompositeModelSummaries = AssetCompositeModelSummary[];
  export interface AssetCompositeModelSummary {
    id: ID;
    externalId?: ExternalId;
    name: Name;
    type: Name;
    description: Description;
    path: AssetCompositeModelPath;
  }
  export type AssetCompositeModels = AssetCompositeModel[];
  export type AssetErrorCode = "INTERNAL_FAILURE"|string;
  export interface AssetErrorDetails {
    assetId: ID;
    code: AssetErrorCode;
    message: AssetErrorMessage;
  }
  export type AssetErrorMessage = string;
  export type AssetFilter = ID[];
  export type AssetHierarchies = AssetHierarchy[];
  export interface AssetHierarchy {
    id?: ID;
    externalId?: ExternalId;
    name: Name;
  }
  export interface AssetHierarchyInfo {
    parentAssetId?: ID;
    childAssetId?: ID;
  }
  export type AssetIDs = ID[];
  export interface AssetModel {
    assetModelId: ID;
    assetFilter?: AssetFilter;
    assetPropertyFilter?: AssetPropertyFilter;
  }
  export interface AssetModelAuthInfo {
    assetModelId: ID;
    propertyId: ID;
    destinationResourceArn: ARN;
  }
  export type AssetModelAuthInfoList = AssetModelAuthInfo[];
  export interface AssetModelCompositeModel {
    name: Name;
    description?: Description;
    type: Name;
    properties?: AssetModelProperties;
    id?: CustomID;
    externalId?: ExternalId;
  }
  export interface AssetModelCompositeModelDefinition {
    id?: ID;
    externalId?: ExternalId;
    name: Name;
    description?: Description;
    type: Name;
    properties?: AssetModelPropertyDefinitions;
  }
  export type AssetModelCompositeModelDefinitions = AssetModelCompositeModelDefinition[];
  export type AssetModelCompositeModelPath = AssetModelCompositeModelPathSegment[];
  export interface AssetModelCompositeModelPathSegment {
    id?: ID;
    name?: Name;
  }
  export type AssetModelCompositeModelSummaries = AssetModelCompositeModelSummary[];
  export interface AssetModelCompositeModelSummary {
    id: ID;
    externalId?: ExternalId;
    name: Name;
    type: Name;
    description?: Description;
    path?: AssetModelCompositeModelPath;
  }
  export type AssetModelCompositeModels = AssetModelCompositeModel[];
  export type AssetModelHierarchies = AssetModelHierarchy[];
  export interface AssetModelHierarchy {
    id?: CustomID;
    externalId?: ExternalId;
    logicalId?: LogicalId;
    name: Name;
    childAssetModelId: CustomID;
  }
  export interface AssetModelHierarchyDefinition {
    id?: ID;
    externalId?: ExternalId;
    name: Name;
    logicalId?: LogicalId;
    childAssetModelId: CustomID;
  }
  export type AssetModelHierarchyDefinitions = AssetModelHierarchyDefinition[];
  export type AssetModelProperties = AssetModelProperty[];
  export interface AssetModelProperty {
    id?: CustomID;
    externalId?: ExternalId;
    logicalId?: LogicalId;
    name: Name;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    unit?: PropertyUnit;
    type: PropertyType;
    path?: AssetModelPropertyPath;
  }
  export interface AssetModelPropertyDefinition {
    id?: ID;
    externalId?: ExternalId;
    name: Name;
    logicalId?: LogicalId;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    unit?: PropertyUnit;
    type: PropertyType;
  }
  export type AssetModelPropertyDefinitions = AssetModelPropertyDefinition[];
  export type AssetModelPropertyPath = AssetModelPropertyPathSegment[];
  export interface AssetModelPropertyPathSegment {
    id?: ID;
    name?: Name;
  }
  export type AssetModelPropertySummaries = AssetModelPropertySummary[];
  export interface AssetModelPropertySummary {
    id?: ID;
    externalId?: ExternalId;
    logicalId?: LogicalId;
    name: Name;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    unit?: PropertyUnit;
    type: PropertyType;
    assetModelCompositeModelId?: ID;
    path?: AssetModelPropertyPath;
  }
  export type AssetModelState = "CREATING"|"ACTIVE"|"UPDATING"|"PROPAGATING"|"DELETING"|"FAILED"|string;
  export interface AssetModelStatus {
    state: AssetModelState;
    error?: ErrorDetails;
  }
  export type AssetModelSummaries = AssetModelSummary[];
  export interface AssetModelSummary {
    id: ID;
    externalId?: ExternalId;
    arn: ARN;
    name: Name;
    assetModelType?: AssetModelType;
    description: Description;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    status: AssetModelStatus;
    version?: Version;
  }
  export type AssetModelType = "ASSET_MODEL"|"COMPONENT_MODEL"|string;
  export type AssetModelVersionFilter = string;
  export type AssetModels = AssetModel[];
  export type AssetProperties = AssetProperty[];
  export interface AssetProperty {
    id: ID;
    externalId?: ExternalId;
    name: Name;
    alias?: PropertyAlias;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    unit?: PropertyUnit;
    path?: AssetPropertyPath;
  }
  export type AssetPropertyAlias = string;
  export type AssetPropertyFilter = ID[];
  export type AssetPropertyPath = AssetPropertyPathSegment[];
  export interface AssetPropertyPathSegment {
    id?: ID;
    name?: Name;
  }
  export type AssetPropertySummaries = AssetPropertySummary[];
  export interface AssetPropertySummary {
    id: ID;
    externalId?: ExternalId;
    alias?: PropertyAlias;
    unit?: PropertyUnit;
    notification?: PropertyNotification;
    assetCompositeModelId?: ID;
    path?: AssetPropertyPath;
  }
  export interface AssetPropertyValue {
    value: Variant;
    timestamp: TimeInNanos;
    quality?: Quality;
  }
  export type AssetPropertyValueHistory = AssetPropertyValue[];
  export interface AssetPropertyValueInternal {
    value: Variant;
    timestamp: TimeInNanos;
    quality?: Quality;
    version?: AssetPropertyValueVersionNumber;
    triggerTimestamp?: Timestamp;
  }
  export type AssetPropertyValueVersionNumber = number;
  export type AssetPropertyValues = AssetPropertyValue[];
  export type AssetPropertyValuesInternal = AssetPropertyValueInternal[];
  export type AssetRelationshipSummaries = AssetRelationshipSummary[];
  export interface AssetRelationshipSummary {
    hierarchyInfo?: AssetHierarchyInfo;
    relationshipType: AssetRelationshipType;
  }
  export type AssetRelationshipType = "HIERARCHY"|string;
  export type AssetState = "CREATING"|"ACTIVE"|"UPDATING"|"DELETING"|"FAILED"|string;
  export interface AssetStatus {
    state: AssetState;
    error?: ErrorDetails;
  }
  export type AssetSummaries = AssetSummary[];
  export interface AssetSummary {
    id: ID;
    externalId?: ExternalId;
    arn: ARN;
    name: Name;
    assetModelId: ID;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    status: AssetStatus;
    hierarchies: AssetHierarchies;
    description?: Description;
  }
  export type AssistantSummaries = AssistantSummary[];
  export interface AssistantSummary {
    assistantName: String;
    assistantId: String;
  }
  export interface AssociateAssetsRequest {
    assetId: CustomID;
    hierarchyId: CustomID;
    childAssetId: CustomID;
    clientToken?: ClientToken;
  }
  export interface AssociateTimeSeriesToAssetPropertyRequest {
    alias: PropertyAlias;
    assetId: CustomID;
    propertyId: CustomID;
    clientToken?: ClientToken;
  }
  export type AssociatedAssetsSummaries = AssociatedAssetsSummary[];
  export interface AssociatedAssetsSummary {
    id: ID;
    externalId?: ExternalId;
    arn: ARN;
    name: Name;
    assetModelId: ID;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    status: AssetStatus;
    hierarchies: AssetHierarchies;
    description?: Description;
  }
  export interface Attribute {
    defaultValue?: DefaultValue;
  }
  export type AuthMode = "IAM"|"SSO"|string;
  export interface AuthorizeAssetModelPropertyRoutingInternalRequest {
    assetModelAuthInfoList: AssetModelAuthInfoList;
  }
  export interface AuthorizeAssetModelPropertyRoutingInternalResponse {
  }
  export interface AuthorizeEnableSiteWiseIntegrationInternalRequest {
    workspaceId?: WorkspaceId;
  }
  export interface AuthorizeEnableSiteWiseIntegrationInternalResponse {
  }
  export type AwsAccountId = string;
  export type BatchAssociateProjectAssetsErrors = AssetErrorDetails[];
  export interface BatchAssociateProjectAssetsRequest {
    projectId: ID;
    assetIds: IDs;
    clientToken?: ClientToken;
  }
  export interface BatchAssociateProjectAssetsResponse {
    errors?: BatchAssociateProjectAssetsErrors;
  }
  export interface BatchAssociateTimeSeriesToAssetPropertyAssociation {
    alias: PropertyAlias;
    assetId: ID;
    propertyId: ID;
  }
  export type BatchAssociateTimeSeriesToAssetPropertyAssociations = BatchAssociateTimeSeriesToAssetPropertyAssociation[];
  export interface BatchAssociateTimeSeriesToAssetPropertyError {
    alias: PropertyAlias;
    propertyId: ID;
    assetId: ID;
    code: PropertyErrorCode;
    message: PropertyErrorMessage;
  }
  export type BatchAssociateTimeSeriesToAssetPropertyErrors = BatchAssociateTimeSeriesToAssetPropertyError[];
  export interface BatchAssociateTimeSeriesToAssetPropertyRequest {
    clientToken?: ClientToken;
    timeSeriesAssociations: BatchAssociateTimeSeriesToAssetPropertyAssociations;
  }
  export interface BatchAssociateTimeSeriesToAssetPropertyResponse {
    errors: BatchAssociateTimeSeriesToAssetPropertyErrors;
  }
  export type BatchDisassociateProjectAssetsErrors = AssetErrorDetails[];
  export interface BatchDisassociateProjectAssetsRequest {
    projectId: ID;
    assetIds: IDs;
    clientToken?: ClientToken;
  }
  export interface BatchDisassociateProjectAssetsResponse {
    errors?: BatchDisassociateProjectAssetsErrors;
  }
  export type BatchEntryCompletionStatus = "SUCCESS"|"ERROR"|string;
  export type BatchGetAssetPropertyAggregatesEntries = BatchGetAssetPropertyAggregatesEntry[];
  export interface BatchGetAssetPropertyAggregatesEntry {
    entryId: EntryId;
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    aggregateTypes: AggregateTypes;
    resolution: Resolution;
    startDate: Timestamp;
    endDate: Timestamp;
    qualities?: Qualities;
    timeOrdering?: TimeOrdering;
  }
  export type BatchGetAssetPropertyAggregatesErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"AccessDeniedException"|string;
  export type BatchGetAssetPropertyAggregatesErrorEntries = BatchGetAssetPropertyAggregatesErrorEntry[];
  export interface BatchGetAssetPropertyAggregatesErrorEntry {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorMessage: ErrorMessage;
    entryId: EntryId;
  }
  export interface BatchGetAssetPropertyAggregatesErrorInfo {
    errorCode: BatchGetAssetPropertyAggregatesErrorCode;
    errorTimestamp: Timestamp;
  }
  export type BatchGetAssetPropertyAggregatesInternalErrorCode = "InvalidRequestException"|"ResourceNotFoundException"|"InvalidCustomerConfigurationException"|string;
  export type BatchGetAssetPropertyAggregatesInternalErrorEntries = BatchGetAssetPropertyAggregatesInternalErrorEntry[];
  export interface BatchGetAssetPropertyAggregatesInternalErrorEntry {
    errorCode: BatchGetAssetPropertyAggregatesInternalErrorCode;
    errorMessage: ErrorMessage;
    entryId: EntryId;
  }
  export interface BatchGetAssetPropertyAggregatesInternalErrorInfo {
    errorCode: BatchGetAssetPropertyAggregatesInternalErrorCode;
    errorTimestamp: Timestamp;
  }
  export interface BatchGetAssetPropertyAggregatesInternalRequest {
    accountId: AwsAccountId;
    entries: BatchGetAssetPropertyAggregatesEntries;
    nextToken?: NextToken;
    maxResults?: BatchGetAssetPropertyAggregatesMaxResults;
  }
  export interface BatchGetAssetPropertyAggregatesInternalResponse {
    errorEntries: BatchGetAssetPropertyAggregatesInternalErrorEntries;
    successEntries: BatchGetAssetPropertyAggregatesSuccessEntries;
    skippedEntries: BatchGetAssetPropertyAggregatesInternalSkippedEntries;
    nextToken?: NextToken;
    billableUsage?: BillableQueryUsageList;
  }
  export type BatchGetAssetPropertyAggregatesInternalSkippedEntries = BatchGetAssetPropertyAggregatesInternalSkippedEntry[];
  export interface BatchGetAssetPropertyAggregatesInternalSkippedEntry {
    entryId: EntryId;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyAggregatesInternalErrorInfo;
  }
  export type BatchGetAssetPropertyAggregatesMaxResults = number;
  export interface BatchGetAssetPropertyAggregatesRequest {
    entries: BatchGetAssetPropertyAggregatesEntries;
    nextToken?: NextToken;
    maxResults?: BatchGetAssetPropertyAggregatesMaxResults;
  }
  export interface BatchGetAssetPropertyAggregatesResponse {
    errorEntries: BatchGetAssetPropertyAggregatesErrorEntries;
    successEntries: BatchGetAssetPropertyAggregatesSuccessEntries;
    skippedEntries: BatchGetAssetPropertyAggregatesSkippedEntries;
    nextToken?: NextToken;
  }
  export type BatchGetAssetPropertyAggregatesSkippedEntries = BatchGetAssetPropertyAggregatesSkippedEntry[];
  export interface BatchGetAssetPropertyAggregatesSkippedEntry {
    entryId: EntryId;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyAggregatesErrorInfo;
  }
  export type BatchGetAssetPropertyAggregatesSuccessEntries = BatchGetAssetPropertyAggregatesSuccessEntry[];
  export interface BatchGetAssetPropertyAggregatesSuccessEntry {
    entryId: EntryId;
    aggregatedValues: AggregatedValues;
  }
  export type BatchGetAssetPropertyValueEntries = BatchGetAssetPropertyValueEntry[];
  export interface BatchGetAssetPropertyValueEntry {
    entryId: EntryId;
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
  }
  export type BatchGetAssetPropertyValueErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"AccessDeniedException"|string;
  export type BatchGetAssetPropertyValueErrorEntries = BatchGetAssetPropertyValueErrorEntry[];
  export interface BatchGetAssetPropertyValueErrorEntry {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorMessage: ErrorMessage;
    entryId: EntryId;
  }
  export interface BatchGetAssetPropertyValueErrorInfo {
    errorCode: BatchGetAssetPropertyValueErrorCode;
    errorTimestamp: Timestamp;
  }
  export type BatchGetAssetPropertyValueHistoryEntries = BatchGetAssetPropertyValueHistoryEntry[];
  export interface BatchGetAssetPropertyValueHistoryEntry {
    entryId: EntryId;
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    startDate?: Timestamp;
    endDate?: Timestamp;
    qualities?: Qualities;
    timeOrdering?: TimeOrdering;
  }
  export type BatchGetAssetPropertyValueHistoryErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"AccessDeniedException"|string;
  export type BatchGetAssetPropertyValueHistoryErrorEntries = BatchGetAssetPropertyValueHistoryErrorEntry[];
  export interface BatchGetAssetPropertyValueHistoryErrorEntry {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorMessage: ErrorMessage;
    entryId: EntryId;
  }
  export interface BatchGetAssetPropertyValueHistoryErrorInfo {
    errorCode: BatchGetAssetPropertyValueHistoryErrorCode;
    errorTimestamp: Timestamp;
  }
  export type BatchGetAssetPropertyValueHistoryMaxResults = number;
  export interface BatchGetAssetPropertyValueHistoryRequest {
    entries: BatchGetAssetPropertyValueHistoryEntries;
    nextToken?: NextToken;
    maxResults?: BatchGetAssetPropertyValueHistoryMaxResults;
  }
  export interface BatchGetAssetPropertyValueHistoryResponse {
    errorEntries: BatchGetAssetPropertyValueHistoryErrorEntries;
    successEntries: BatchGetAssetPropertyValueHistorySuccessEntries;
    skippedEntries: BatchGetAssetPropertyValueHistorySkippedEntries;
    nextToken?: NextToken;
  }
  export type BatchGetAssetPropertyValueHistorySkippedEntries = BatchGetAssetPropertyValueHistorySkippedEntry[];
  export interface BatchGetAssetPropertyValueHistorySkippedEntry {
    entryId: EntryId;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueHistoryErrorInfo;
  }
  export type BatchGetAssetPropertyValueHistorySuccessEntries = BatchGetAssetPropertyValueHistorySuccessEntry[];
  export interface BatchGetAssetPropertyValueHistorySuccessEntry {
    entryId: EntryId;
    assetPropertyValueHistory: AssetPropertyValueHistory;
  }
  export type BatchGetAssetPropertyValueInternalErrorCode = "InvalidRequestException"|"ResourceNotFoundException"|"InvalidCustomerConfigurationException"|string;
  export type BatchGetAssetPropertyValueInternalErrorEntries = BatchGetAssetPropertyValueInternalErrorEntry[];
  export interface BatchGetAssetPropertyValueInternalErrorEntry {
    errorCode: BatchGetAssetPropertyValueInternalErrorCode;
    errorMessage: ErrorMessage;
    entryId: EntryId;
  }
  export interface BatchGetAssetPropertyValueInternalErrorInfo {
    errorCode: BatchGetAssetPropertyValueInternalErrorCode;
    errorTimestamp: Timestamp;
  }
  export interface BatchGetAssetPropertyValueInternalRequest {
    accountId: AwsAccountId;
    entries: BatchGetAssetPropertyValueEntries;
    nextToken?: NextToken;
  }
  export interface BatchGetAssetPropertyValueInternalResponse {
    errorEntries: BatchGetAssetPropertyValueInternalErrorEntries;
    successEntries: BatchGetAssetPropertyValueSuccessEntries;
    skippedEntries: BatchGetAssetPropertyValueInternalSkippedEntries;
    nextToken?: NextToken;
    billableUsage?: BillableQueryUsageList;
  }
  export type BatchGetAssetPropertyValueInternalSkippedEntries = BatchGetAssetPropertyValueInternalSkippedEntry[];
  export interface BatchGetAssetPropertyValueInternalSkippedEntry {
    entryId: EntryId;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueInternalErrorInfo;
  }
  export interface BatchGetAssetPropertyValueRequest {
    entries: BatchGetAssetPropertyValueEntries;
    nextToken?: NextToken;
  }
  export interface BatchGetAssetPropertyValueResponse {
    errorEntries: BatchGetAssetPropertyValueErrorEntries;
    successEntries: BatchGetAssetPropertyValueSuccessEntries;
    skippedEntries: BatchGetAssetPropertyValueSkippedEntries;
    nextToken?: NextToken;
  }
  export type BatchGetAssetPropertyValueSkippedEntries = BatchGetAssetPropertyValueSkippedEntry[];
  export interface BatchGetAssetPropertyValueSkippedEntry {
    entryId: EntryId;
    completionStatus: BatchEntryCompletionStatus;
    errorInfo?: BatchGetAssetPropertyValueErrorInfo;
  }
  export type BatchGetAssetPropertyValueSuccessEntries = BatchGetAssetPropertyValueSuccessEntry[];
  export interface BatchGetAssetPropertyValueSuccessEntry {
    entryId: EntryId;
    assetPropertyValue?: AssetPropertyValue;
  }
  export interface BatchPutAssetPropertyError {
    errorCode: BatchPutAssetPropertyValueErrorCode;
    errorMessage: ErrorMessage;
    timestamps: Timestamps;
  }
  export type BatchPutAssetPropertyErrorEntries = BatchPutAssetPropertyErrorEntry[];
  export interface BatchPutAssetPropertyErrorEntry {
    entryId: EntryId;
    errors: BatchPutAssetPropertyErrors;
  }
  export type BatchPutAssetPropertyErrors = BatchPutAssetPropertyError[];
  export interface BatchPutAssetPropertyInternalError {
    errorCode: BatchPutAssetPropertyValueInternalErrorCode;
    errorMessage: ErrorMessage;
    timestamps: Timestamps;
  }
  export type BatchPutAssetPropertyInternalErrorEntries = BatchPutAssetPropertyInternalErrorEntry[];
  export interface BatchPutAssetPropertyInternalErrorEntry {
    entryId: EntryId;
    errors: BatchPutAssetPropertyInternalErrors;
  }
  export type BatchPutAssetPropertyInternalErrors = BatchPutAssetPropertyInternalError[];
  export type BatchPutAssetPropertyValueErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"InternalFailureException"|"ServiceUnavailableException"|"ThrottlingException"|"LimitExceededException"|"ConflictingOperationException"|"TimestampOutOfRangeException"|"AccessDeniedException"|string;
  export type BatchPutAssetPropertyValueInternalErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"InternalFailureException"|"ServiceUnavailableException"|"ThrottlingException"|"LimitExceededException"|"ConflictingOperationException"|"TimestampOutOfRangeException"|"AccessDeniedException"|"VersionCheckFailedException"|"InvalidCustomerKMSKeyException"|"EdgeComputedPropertyException"|string;
  export interface BatchPutAssetPropertyValueInternalRequest {
    entries: PutAssetPropertyValueInternalEntries;
  }
  export interface BatchPutAssetPropertyValueInternalResponse {
    errorEntries: BatchPutAssetPropertyInternalErrorEntries;
  }
  export interface BatchPutAssetPropertyValueRequest {
    entries: PutAssetPropertyValueEntries;
  }
  export interface BatchPutAssetPropertyValueResponse {
    errorEntries: BatchPutAssetPropertyErrorEntries;
  }
  export interface BillableQueryUsage {
    messageCount?: MessageCount;
    warmMessageCount?: MessageCount;
    resourceId?: MeteringResourceId;
    resourceType?: MeteringResourceType;
  }
  export type BillableQueryUsageList = BillableQueryUsage[];
  export type Boolean = boolean;
  export type BooleanValue = boolean;
  export type Bucket = string;
  export type BucketOwner = string;
  export type CapabilityConfiguration = string;
  export type CapabilityNamespace = string;
  export type CapabilitySyncStatus = "IN_SYNC"|"OUT_OF_SYNC"|"SYNC_FAILED"|"UNKNOWN"|"NOT_APPLICABLE"|string;
  export interface CellData {
    varcharValue?: NonEmptyResponseString;
  }
  export type ClientToken = string;
  export interface ColumnHeader {
    name: NonEmptyResponseString;
    type: NonEmptyResponseString;
    precision?: Integer;
    scale?: Integer;
    tableName?: NonEmptyResponseString;
  }
  export type ColumnHeaders = ColumnHeader[];
  export interface ColumnInfo {
    name?: String;
    type?: ColumnType;
  }
  export type ColumnName = "ALIAS"|"ASSET_ID"|"PROPERTY_ID"|"DATA_TYPE"|"TIMESTAMP_SECONDS"|"TIMESTAMP_NANO_OFFSET"|"QUALITY"|"VALUE"|string;
  export type ColumnNames = ColumnName[];
  export interface ColumnType {
    scalarType?: ScalarType;
  }
  export type ColumnsList = ColumnInfo[];
  export interface CompositeModelProperty {
    name: Name;
    type: Name;
    assetProperty: Property;
    id?: ID;
    externalId?: ExternalId;
  }
  export interface CompositionDetails {
    compositionRelationship?: CompositionRelationship;
  }
  export type CompositionRelationship = CompositionRelationshipItem[];
  export interface CompositionRelationshipItem {
    id?: ID;
  }
  export type CompositionRelationshipSummaries = CompositionRelationshipSummary[];
  export interface CompositionRelationshipSummary {
    assetModelId: ID;
    assetModelCompositeModelId: ID;
    assetModelCompositeModelType: Name;
  }
  export type CompressionFormat = "GZIP"|"BZIP2"|"DEFLATE"|"LZ4"|"LZO"|"SNAPPY"|"ZLIB"|"ZSTD"|string;
  export type ComputationJobState = "PENDING"|"RUNNING"|"UPLOADING"|"COMPLETED"|"FAILED"|"PAUSING"|"PAUSED"|"EXPIRED"|"DELETING"|string;
  export interface ComputationJobStatus {
    state?: ComputationJobState;
    reason?: Reason;
  }
  export type ComputationJobSummaries = ComputationJobSummary[];
  export interface ComputationJobSummary {
    jobId?: JobId;
    status?: ComputationJobStatus;
    creationTime?: Timestamp;
    lastUpdateTime?: Timestamp;
    progress?: Progress;
  }
  export type ComputationPercentage = number;
  export type ComputeLocation = "EDGE"|"CLOUD"|string;
  export interface ConfigurationErrorDetails {
    code: ErrorCode;
    message: ErrorMessage;
  }
  export type ConfigurationState = "ACTIVE"|"UPDATE_IN_PROGRESS"|"UPDATE_FAILED"|string;
  export interface ConfigurationStatus {
    state: ConfigurationState;
    error?: ConfigurationErrorDetails;
  }
  export type CoreDeviceThingName = string;
  export interface CreateAccessPolicyRequest {
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: ClientToken;
    tags?: TagMap;
  }
  export interface CreateAccessPolicyResponse {
    accessPolicyId: ID;
    accessPolicyArn: ARN;
  }
  export interface CreateAssetModelCompositeModelRequest {
    assetModelId: CustomID;
    assetModelCompositeModelExternalId?: ExternalId;
    parentAssetModelCompositeModelId?: CustomID;
    assetModelCompositeModelId?: ID;
    assetModelCompositeModelDescription?: Description;
    assetModelCompositeModelName: Name;
    assetModelCompositeModelType: Name;
    clientToken?: ClientToken;
    composedAssetModelId?: CustomID;
    assetModelCompositeModelProperties?: AssetModelPropertyDefinitions;
  }
  export interface CreateAssetModelCompositeModelResponse {
    assetModelCompositeModelId: ID;
    assetModelCompositeModelPath: AssetModelCompositeModelPath;
    assetModelStatus: AssetModelStatus;
  }
  export interface CreateAssetModelRequest {
    assetModelName: Name;
    assetModelType?: AssetModelType;
    assetModelId?: ID;
    assetModelExternalId?: ExternalId;
    assetModelDescription?: Description;
    assetModelProperties?: AssetModelPropertyDefinitions;
    assetModelHierarchies?: AssetModelHierarchyDefinitions;
    assetModelCompositeModels?: AssetModelCompositeModelDefinitions;
    clientToken?: ClientToken;
    tags?: TagMap;
  }
  export interface CreateAssetModelResponse {
    assetModelId: ID;
    assetModelArn: ARN;
    assetModelStatus: AssetModelStatus;
  }
  export interface CreateAssetRequest {
    assetName: Name;
    assetModelId: CustomID;
    assetId?: ID;
    assetExternalId?: ExternalId;
    clientToken?: ClientToken;
    tags?: TagMap;
    assetDescription?: Description;
  }
  export interface CreateAssetResponse {
    assetId: ID;
    assetArn: ARN;
    assetStatus: AssetStatus;
  }
  export interface CreateAssistantRequest {
    assistantName: String;
  }
  export interface CreateAssistantResponse {
    assistantId: String;
  }
  export interface CreateBulkImportJobInternalRequest {
    accountId: AwsAccountId;
    jobName: Name;
    jobRoleArn: ARN;
    files: Files;
    errorReportLocation: ErrorReportLocation;
    jobConfiguration: JobConfiguration;
    adaptiveIngestion?: AdaptiveIngestion;
    deleteFilesAfterImport?: DeleteFilesAfterImport;
  }
  export interface CreateBulkImportJobInternalResponse {
    jobId: ID;
    jobName: Name;
    jobStatus: JobStatus;
  }
  export interface CreateBulkImportJobRequest {
    jobName: Name;
    jobRoleArn: ARN;
    files: Files;
    errorReportLocation: ErrorReportLocation;
    jobConfiguration: JobConfiguration;
    adaptiveIngestion?: AdaptiveIngestion;
    deleteFilesAfterImport?: DeleteFilesAfterImport;
  }
  export interface CreateBulkImportJobResponse {
    jobId: ID;
    jobName: Name;
    jobStatus: JobStatus;
  }
  export interface CreateComputationJobRequest {
    jobId?: JobId;
    onDemandComputation: OnDemandComputation;
  }
  export interface CreateComputationJobResponse {
    jobId: JobId;
    creationTime: Timestamp;
    status: ComputationJobStatus;
  }
  export interface CreateDashboardRequest {
    projectId: ID;
    dashboardName: Name;
    dashboardDescription?: Description;
    dashboardDefinition: DashboardDefinition;
    clientToken?: ClientToken;
    tags?: TagMap;
  }
  export interface CreateDashboardResponse {
    dashboardId: ID;
    dashboardArn: ARN;
  }
  export interface CreateGatewayRequest {
    gatewayName: Name;
    gatewayPlatform: GatewayPlatform;
    tags?: TagMap;
  }
  export interface CreateGatewayResponse {
    gatewayId: ID;
    gatewayArn: ARN;
  }
  export interface CreatePortalRequest {
    portalName: Name;
    portalDescription?: Description;
    portalContactEmail: Email;
    clientToken?: ClientToken;
    portalLogoImageFile?: ImageFile;
    roleArn: IamArn;
    tags?: TagMap;
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: Email;
    alarms?: Alarms;
    edgeConfig?: PortalEdgeConfig;
    projectPublicSharing?: ProjectSharingStatus;
  }
  export interface CreatePortalResponse {
    portalId: ID;
    portalArn: ARN;
    portalStartUrl: Url;
    portalStatus: PortalStatus;
    ssoApplicationId: SSOApplicationId;
  }
  export interface CreateProjectRequest {
    portalId: ID;
    projectName: Name;
    projectDescription?: Description;
    clientToken?: ClientToken;
    tags?: TagMap;
    projectSharing?: ProjectSharing;
  }
  export interface CreateProjectResponse {
    projectId: ID;
    projectArn: ARN;
  }
  export interface Csv {
    columnNames: ColumnNames;
  }
  export type CustomID = string;
  export interface CustomerManagedS3Storage {
    s3ResourceArn: ARN;
    roleArn: ARN;
  }
  export interface CustomerManagedTimestreamStorage {
    roleArn: ARN;
    databaseArn: ARN;
    tables: TimestreamTables;
  }
  export type DashboardDefinition = string;
  export type DashboardSummaries = DashboardSummary[];
  export interface DashboardSummary {
    id: ID;
    name: Name;
    description?: Description;
    creationDate?: Timestamp;
    lastUpdateDate?: Timestamp;
  }
  export type DataVersion = number;
  export interface Datum {
    scalarValue?: ScalarValue;
    arrayValue?: DatumList;
    rowValue?: Row;
    nullValue?: NullableBoolean;
  }
  export type DatumList = Datum[];
  export type DefaultValue = string;
  export interface DeleteAccessPolicyRequest {
    accessPolicyId: ID;
    clientToken?: ClientToken;
  }
  export interface DeleteAccessPolicyResponse {
  }
  export interface DeleteAssetModelCompositeModelRequest {
    assetModelId: CustomID;
    assetModelCompositeModelId: CustomID;
    clientToken?: ClientToken;
  }
  export interface DeleteAssetModelCompositeModelResponse {
    assetModelStatus: AssetModelStatus;
  }
  export interface DeleteAssetModelRequest {
    assetModelId: CustomID;
    clientToken?: ClientToken;
  }
  export interface DeleteAssetModelResponse {
    assetModelStatus: AssetModelStatus;
  }
  export interface DeleteAssetRequest {
    assetId: CustomID;
    clientToken?: ClientToken;
  }
  export interface DeleteAssetResponse {
    assetStatus: AssetStatus;
  }
  export interface DeleteAssistantRequest {
    assistantId: String;
  }
  export interface DeleteAssistantResponse {
  }
  export interface DeleteComputationJobRequest {
    jobId: JobId;
  }
  export interface DeleteComputationJobResponse {
    jobId: JobId;
    status: ComputationJobStatus;
  }
  export interface DeleteDashboardRequest {
    dashboardId: ID;
    clientToken?: ClientToken;
  }
  export interface DeleteDashboardResponse {
  }
  export type DeleteFilesAfterImport = boolean;
  export interface DeleteGatewayRequest {
    gatewayId: ID;
  }
  export interface DeleteNotificationConfigurationRequest {
    notificationId: ID;
  }
  export interface DeletePortalRequest {
    portalId: ID;
    clientToken?: ClientToken;
  }
  export interface DeletePortalResponse {
    portalStatus: PortalStatus;
  }
  export interface DeleteProjectRequest {
    projectId: ID;
    clientToken?: ClientToken;
  }
  export interface DeleteProjectResponse {
  }
  export interface DeleteSubscriptionInternalRequest {
    accountId: AwsAccountId;
    assetModelId?: ID;
    assetId?: ID;
    propertyId: ID;
    service: SubscriptionService;
    subscriptionVersion?: SubscriptionVersion;
    clientToken?: ClientToken;
  }
  export interface DeleteTimeSeriesRequest {
    alias?: PropertyAlias;
    assetId?: CustomID;
    propertyId?: CustomID;
    clientToken?: ClientToken;
  }
  export interface DescribeAccessPolicyRequest {
    accessPolicyId: ID;
  }
  export interface DescribeAccessPolicyResponse {
    accessPolicyId: ID;
    accessPolicyArn: ARN;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    accessPolicyCreationDate: Timestamp;
    accessPolicyLastUpdateDate: Timestamp;
  }
  export interface DescribeActionRequest {
    actionId: ID;
  }
  export interface DescribeActionResponse {
    actionId: ID;
    targetResource: TargetResource;
    actionDefinitionId: ID;
    actionPayload: ActionPayload;
    executionTime: Timestamp;
  }
  export interface DescribeAssetCompositeModelRequest {
    assetId: CustomID;
    assetCompositeModelId: CustomID;
  }
  export interface DescribeAssetCompositeModelResponse {
    assetId: ID;
    assetCompositeModelId: ID;
    assetCompositeModelExternalId?: ExternalId;
    assetCompositeModelPath: AssetCompositeModelPath;
    assetCompositeModelName: Name;
    assetCompositeModelDescription: Description;
    assetCompositeModelType: Name;
    assetCompositeModelProperties: AssetProperties;
    assetCompositeModelSummaries: AssetCompositeModelSummaries;
    actionDefinitions?: ActionDefinitions;
  }
  export interface DescribeAssetModelCompositeModelRequest {
    assetModelId: CustomID;
    assetModelCompositeModelId: CustomID;
    assetModelVersion?: AssetModelVersionFilter;
  }
  export interface DescribeAssetModelCompositeModelResponse {
    assetModelId: ID;
    assetModelCompositeModelId: ID;
    assetModelCompositeModelExternalId?: ExternalId;
    assetModelCompositeModelPath: AssetModelCompositeModelPath;
    assetModelCompositeModelName: Name;
    assetModelCompositeModelDescription: Description;
    assetModelCompositeModelType: Name;
    assetModelCompositeModelProperties: AssetModelProperties;
    compositionDetails?: CompositionDetails;
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummaries;
    actionDefinitions?: ActionDefinitions;
  }
  export interface DescribeAssetModelRequest {
    assetModelId: CustomID;
    excludeProperties?: ExcludeProperties;
    assetModelVersion?: AssetModelVersionFilter;
  }
  export interface DescribeAssetModelResponse {
    assetModelId: ID;
    assetModelExternalId?: ExternalId;
    assetModelArn: ARN;
    assetModelName: Name;
    assetModelType?: AssetModelType;
    assetModelDescription: Description;
    assetModelProperties: AssetModelProperties;
    assetModelHierarchies: AssetModelHierarchies;
    assetModelCompositeModels?: AssetModelCompositeModels;
    assetModelCompositeModelSummaries?: AssetModelCompositeModelSummaries;
    assetModelCreationDate: Timestamp;
    assetModelLastUpdateDate: Timestamp;
    assetModelStatus: AssetModelStatus;
    assetModelVersion?: Version;
  }
  export interface DescribeAssetPropertyRequest {
    assetId: CustomID;
    propertyId: CustomID;
  }
  export interface DescribeAssetPropertyResponse {
    assetId: ID;
    assetExternalId?: ExternalId;
    assetName: Name;
    assetModelId: ID;
    assetProperty?: Property;
    compositeModel?: CompositeModelProperty;
  }
  export interface DescribeAssetRequest {
    assetId: CustomID;
    excludeProperties?: ExcludeProperties;
  }
  export interface DescribeAssetResponse {
    assetId: ID;
    assetExternalId?: ExternalId;
    assetArn: ARN;
    assetName: Name;
    assetModelId: ID;
    assetProperties: AssetProperties;
    assetHierarchies: AssetHierarchies;
    assetCompositeModels?: AssetCompositeModels;
    assetCreationDate: Timestamp;
    assetLastUpdateDate: Timestamp;
    assetStatus: AssetStatus;
    assetDescription?: Description;
    assetCompositeModelSummaries?: AssetCompositeModelSummaries;
  }
  export interface DescribeBulkImportJobInternalRequest {
    jobId?: ID;
    jobName?: Name;
  }
  export interface DescribeBulkImportJobInternalResponse {
    accountId: AwsAccountId;
    jobId: ID;
    jobName: Name;
    jobStatus: JobStatus;
    jobRoleArn: ARN;
    files: Files;
    errorReportLocation: ErrorReportLocation;
    jobConfiguration: JobConfiguration;
    jobCreationDate: Timestamp;
    jobLastUpdateDate: Timestamp;
    adaptiveIngestion?: AdaptiveIngestion;
    deleteFilesAfterImport?: DeleteFilesAfterImport;
  }
  export interface DescribeBulkImportJobRequest {
    jobId: ID;
  }
  export interface DescribeBulkImportJobResponse {
    jobId: ID;
    jobName: Name;
    jobStatus: JobStatus;
    jobRoleArn: ARN;
    files: Files;
    errorReportLocation: ErrorReportLocation;
    jobConfiguration: JobConfiguration;
    jobCreationDate: Timestamp;
    jobLastUpdateDate: Timestamp;
    adaptiveIngestion?: AdaptiveIngestion;
    deleteFilesAfterImport?: DeleteFilesAfterImport;
  }
  export interface DescribeComputationJobRequest {
    jobId: JobId;
  }
  export interface DescribeComputationJobResponse {
    jobId: JobId;
    onDemandComputation: OnDemandComputation;
    status: ComputationJobStatus;
    progress?: Progress;
    creationTime: Timestamp;
    lastUpdateTime: Timestamp;
    startTime?: Timestamp;
    endTime?: Timestamp;
  }
  export interface DescribeContextualQueryConfigurationInternalRequest {
    accountId: AwsAccountId;
    workspaceUuid: WorkspaceUuid;
  }
  export interface DescribeContextualQueryConfigurationInternalResponse {
    workspaceUuid: WorkspaceUuid;
    queryStateNotifications: QueryStateNotifications;
    configurationStatus: ConfigurationStatus;
  }
  export interface DescribeContextualQueryConfigurationRequest {
    workspaceId: WorkspaceId;
  }
  export interface DescribeContextualQueryConfigurationResponse {
    workspaceId: WorkspaceId;
    queryStateNotifications: QueryStateNotifications;
    lastUpdateDate: Timestamp;
    configurationStatus: ConfigurationStatus;
  }
  export interface DescribeDashboardRequest {
    dashboardId: ID;
  }
  export interface DescribeDashboardResponse {
    dashboardId: ID;
    dashboardArn: ARN;
    dashboardName: Name;
    projectId: ID;
    dashboardDescription?: Description;
    dashboardDefinition: DashboardDefinition;
    dashboardCreationDate: Timestamp;
    dashboardLastUpdateDate: Timestamp;
  }
  export interface DescribeDefaultEncryptionConfigurationRequest {
  }
  export interface DescribeDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: ARN;
    configurationStatus: ConfigurationStatus;
  }
  export interface DescribeGatewayCapabilityConfigurationRequest {
    gatewayId: ID;
    capabilityNamespace: CapabilityNamespace;
  }
  export interface DescribeGatewayCapabilityConfigurationResponse {
    gatewayId: ID;
    capabilityNamespace: CapabilityNamespace;
    capabilityConfiguration: CapabilityConfiguration;
    capabilitySyncStatus: CapabilitySyncStatus;
  }
  export interface DescribeGatewayRequest {
    gatewayId: ID;
  }
  export interface DescribeGatewayResponse {
    gatewayId: ID;
    gatewayName: Name;
    gatewayArn: ARN;
    gatewayPlatform?: GatewayPlatform;
    gatewayCapabilitySummaries: GatewayCapabilitySummaries;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
  }
  export interface DescribeLoggingOptionsRequest {
  }
  export interface DescribeLoggingOptionsResponse {
    loggingOptions: LoggingOptions;
  }
  export interface DescribePortalRequest {
    portalId: ID;
  }
  export interface DescribePortalResponse {
    portalId: ID;
    portalArn: ARN;
    portalName: Name;
    portalDescription?: Description;
    portalClientId: PortalClientId;
    portalStartUrl: Url;
    portalContactEmail: Email;
    portalStatus: PortalStatus;
    portalCreationDate: Timestamp;
    portalLastUpdateDate: Timestamp;
    portalLogoImageLocation?: ImageLocation;
    roleArn?: IamArn;
    portalAuthMode?: AuthMode;
    notificationSenderEmail?: Email;
    alarms?: Alarms;
    edgeConfig?: PortalEdgeConfig;
    projectPublicSharing?: ProjectSharingStatus;
  }
  export interface DescribeProjectRequest {
    projectId: ID;
  }
  export interface DescribeProjectResponse {
    projectId: ID;
    projectArn: ARN;
    projectName: Name;
    portalId: ID;
    projectDescription?: Description;
    projectCreationDate: Timestamp;
    projectLastUpdateDate: Timestamp;
    projectSharing?: ProjectSharing;
  }
  export interface DescribeStorageConfigurationInternalRequest {
    accountId: AwsAccountId;
  }
  export interface DescribeStorageConfigurationInternalResponse {
    accountId: AwsAccountId;
    currentActiveConfiguration: StorageConfiguration;
    targetConfiguration: StorageConfiguration;
    targetConfigurationStatus: ConfigurationStatus;
    dataVersion: DataVersion;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
  }
  export interface DescribeStorageConfigurationRequest {
  }
  export interface DescribeStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    timestreamStorage?: TimestreamStorage;
    lastUpdateDate?: Timestamp;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
  }
  export interface DescribeSubscriptionInternalRequest {
    accountId: AwsAccountId;
    assetModelId?: ID;
    assetId?: ID;
    propertyId: ID;
    service: SubscriptionService;
  }
  export interface DescribeSubscriptionInternalResponse {
    assetModelId?: ID;
    assetId?: ID;
    propertyId: ID;
    service: SubscriptionService;
    disabled?: Disabled;
    subscriptionVersion?: SubscriptionVersion;
  }
  export interface DescribeTimeSeriesRequest {
    alias?: PropertyAlias;
    assetId?: CustomID;
    propertyId?: CustomID;
  }
  export interface DescribeTimeSeriesResponse {
    assetId?: ID;
    propertyId?: ID;
    alias?: PropertyAlias;
    timeSeriesId: TimeSeriesId;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    timeSeriesCreationDate: Timestamp;
    timeSeriesLastUpdateDate: Timestamp;
    timeSeriesArn: ARN;
  }
  export type Description = string;
  export interface DestinationType {
    eventBus?: EventBus;
    snsTopic?: SnsTopic;
  }
  export interface DetailedError {
    code: DetailedErrorCode;
    message: DetailedErrorMessage;
  }
  export type DetailedErrorCode = "INCOMPATIBLE_COMPUTE_LOCATION"|"INCOMPATIBLE_FORWARDING_CONFIGURATION"|string;
  export type DetailedErrorMessage = string;
  export type DetailedErrors = DetailedError[];
  export type Disabled = boolean;
  export interface DisassociateAssetsRequest {
    assetId: CustomID;
    hierarchyId: CustomID;
    childAssetId: CustomID;
    clientToken?: ClientToken;
  }
  export interface DisassociateTimeSeriesFromAssetPropertyRequest {
    alias: PropertyAlias;
    assetId: CustomID;
    propertyId: CustomID;
    clientToken?: ClientToken;
  }
  export type DisassociatedDataStorageState = "ENABLED"|"DISABLED"|string;
  export type Email = string;
  export interface EncryptionConfiguration {
    encryptionOption: EncryptionOption;
    kmsKey?: KmsKey;
  }
  export type EncryptionOption = "SSE_S3"|"SSE_KMS"|"CSE_KMS"|string;
  export type EncryptionType = "SITEWISE_DEFAULT_ENCRYPTION"|"KMS_BASED_ENCRYPTION"|string;
  export type EntryId = string;
  export type ErrorCode = "VALIDATION_ERROR"|"INTERNAL_FAILURE"|string;
  export interface ErrorDetails {
    code: ErrorCode;
    message: ErrorMessage;
    details?: DetailedErrors;
  }
  export type ErrorMessage = string;
  export interface ErrorReportLocation {
    bucket: Bucket;
    prefix: String;
  }
  export interface EventBus {
    eventBusArn: ARN;
  }
  export type ExcludeProperties = boolean;
  export interface ExecuteActionRequest {
    targetResource: TargetResource;
    actionDefinitionId: ID;
    actionPayload: ActionPayload;
    clientToken?: ClientToken;
  }
  export interface ExecuteActionResponse {
    actionId: ID;
  }
  export type ExecuteQueryMaxResults = number;
  export type ExecuteQueryNextToken = string;
  export interface ExecuteQueryRequest {
    queryStatement: QueryStatement;
    nextToken?: ExecuteQueryNextToken;
    maxResults?: ExecuteQueryMaxResults;
  }
  export interface ExecuteQueryResponse {
    columns?: ColumnsList;
    rows?: Rows;
    nextToken?: ExecuteQueryNextToken;
  }
  export type ExecutionParameter = string;
  export type ExecutionParameters = ExecutionParameter[];
  export type ExpirationTime = number;
  export type Expression = string;
  export interface ExpressionVariable {
    name: VariableName;
    value: VariableValue;
  }
  export type ExpressionVariables = ExpressionVariable[];
  export type ExternalId = string;
  export interface File {
    bucket: Bucket;
    key: String;
    versionId?: String;
  }
  export interface FileFormat {
    csv?: Csv;
    parquet?: Parquet;
  }
  export type Files = File[];
  export interface FinalResponse {
    text?: String;
  }
  export interface ForwardingConfig {
    state: ForwardingConfigState;
  }
  export type ForwardingConfigState = "DISABLED"|"ENABLED"|string;
  export type GatewayCapabilitySummaries = GatewayCapabilitySummary[];
  export interface GatewayCapabilitySummary {
    capabilityNamespace: CapabilityNamespace;
    capabilitySyncStatus: CapabilitySyncStatus;
  }
  export interface GatewayPlatform {
    greengrass?: Greengrass;
    greengrassV2?: GreengrassV2;
    siemensIE?: SiemensIE;
  }
  export type GatewaySummaries = GatewaySummary[];
  export interface GatewaySummary {
    gatewayId: ID;
    gatewayName: Name;
    gatewayPlatform?: GatewayPlatform;
    gatewayCapabilitySummaries?: GatewayCapabilitySummaries;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
  }
  export interface GetAssetPropertyAggregatesRequest {
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    aggregateTypes: AggregateTypes;
    resolution: Resolution;
    qualities?: Qualities;
    startDate: Timestamp;
    endDate: Timestamp;
    timeOrdering?: TimeOrdering;
    nextToken?: NextToken;
    maxResults?: GetAssetPropertyValueAggregatesMaxResults;
  }
  export interface GetAssetPropertyAggregatesResponse {
    aggregatedValues: AggregatedValues;
    nextToken?: NextToken;
  }
  export type GetAssetPropertyValueAggregatesMaxResults = number;
  export type GetAssetPropertyValueHistoryInternalMaxResults = number;
  export interface GetAssetPropertyValueHistoryInternalRequest {
    accountId: AwsAccountId;
    assetId?: ID;
    propertyId?: ID;
    propertyIdVersion?: PropertyIdVersion;
    propertyAlias?: AssetPropertyAlias;
    startDate?: Timestamp;
    endDate?: Timestamp;
    qualities?: Qualities;
    timeOrdering?: TimeOrdering;
    nextToken?: NextToken;
    maxResults?: GetAssetPropertyValueHistoryInternalMaxResults;
  }
  export interface GetAssetPropertyValueHistoryInternalResponse {
    assetPropertyValueHistory: AssetPropertyValueHistory;
    nextToken?: NextToken;
    billableUsage?: BillableQueryUsage;
  }
  export type GetAssetPropertyValueHistoryMaxResults = number;
  export interface GetAssetPropertyValueHistoryRequest {
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    startDate?: Timestamp;
    endDate?: Timestamp;
    qualities?: Qualities;
    timeOrdering?: TimeOrdering;
    nextToken?: NextToken;
    maxResults?: GetAssetPropertyValueHistoryMaxResults;
  }
  export interface GetAssetPropertyValueHistoryResponse {
    assetPropertyValueHistory: AssetPropertyValueHistory;
    nextToken?: NextToken;
  }
  export interface GetAssetPropertyValueInternalRequest {
    accountId: AwsAccountId;
    assetId?: ID;
    propertyId?: ID;
    propertyIdVersion?: PropertyIdVersion;
    propertyAlias?: AssetPropertyAlias;
  }
  export interface GetAssetPropertyValueInternalResponse {
    propertyValue?: AssetPropertyValue;
    billableUsage?: BillableQueryUsage;
  }
  export interface GetAssetPropertyValueRequest {
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
  }
  export interface GetAssetPropertyValueResponse {
    propertyValue?: AssetPropertyValue;
  }
  export interface GetAssistantRequest {
    assistantId: String;
  }
  export interface GetAssistantResponse {
    assistantId: String;
    assistantName: String;
  }
  export interface GetContextualQueryExecutionRequest {
    workspaceId: Id;
    queryExecutionId: Id;
  }
  export interface GetContextualQueryExecutionResponse {
    workspaceId: Id;
    queryExecutionId: Id;
    queryStatement?: SqlStatement;
    resultConfiguration?: ResultConfiguration;
    statistics?: QueryExecutionStatistics;
    status?: QueryExecutionStatus;
    executionParameters?: ExecutionParameters;
  }
  export interface GetContextualQueryResultsRequest {
    workspaceId: Id;
    queryExecutionId: Id;
    maxResults?: PanzaMaxResults;
    nextToken?: NextToken;
  }
  export interface GetContextualQueryResultsResponse {
    resultSet: QueryResultSet;
    nextToken?: NextToken;
  }
  export interface GetInterpolatedAssetPropertyValuesRequest {
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    startTimeInSeconds: TimeInSeconds;
    startTimeOffsetInNanos?: OffsetInNanos;
    endTimeInSeconds: TimeInSeconds;
    endTimeOffsetInNanos?: OffsetInNanos;
    quality: Quality;
    intervalInSeconds: IntervalInSeconds;
    nextToken?: NextToken;
    maxResults?: MaxInterpolatedResults;
    type: InterpolationType;
    intervalWindowInSeconds?: IntervalWindowInSeconds;
  }
  export interface GetInterpolatedAssetPropertyValuesResponse {
    interpolatedAssetPropertyValues: InterpolatedAssetPropertyValues;
    nextToken?: NextToken;
  }
  export interface Greengrass {
    groupArn: ARN;
  }
  export interface GreengrassV2 {
    coreDeviceThingName: CoreDeviceThingName;
  }
  export interface GroupIdentity {
    id: IdentityId;
  }
  export interface IAMRoleIdentity {
    arn: IamArn;
  }
  export interface IAMUserIdentity {
    arn: IamArn;
  }
  export type ID = string;
  export type IDs = ID[];
  export type IamArn = string;
  export type Id = string;
  export interface Identity {
    user?: UserIdentity;
    group?: GroupIdentity;
    iamUser?: IAMUserIdentity;
    iamRole?: IAMRoleIdentity;
  }
  export type IdentityId = string;
  export type IdentityType = "USER"|"GROUP"|"IAM"|string;
  export interface Image {
    id?: ID;
    file?: ImageFile;
  }
  export interface ImageFile {
    data: ImageFileData;
    type: ImageFileType;
  }
  export type ImageFileData = Buffer|Uint8Array|Blob|string;
  export type ImageFileType = "PNG"|string;
  export interface ImageLocation {
    id: ID;
    url: Url;
  }
  export type Integer = number;
  export interface InterpolatedAssetPropertyValue {
    timestamp: TimeInNanos;
    value: Variant;
  }
  export type InterpolatedAssetPropertyValues = InterpolatedAssetPropertyValue[];
  export type InterpolationType = string;
  export type Interval = string;
  export type IntervalInSeconds = number;
  export type IntervalWindowInSeconds = number;
  export interface InvokeAssistantRequest {
    conversationId?: String;
    message?: String;
  }
  export interface InvokeAssistantResponse {
    body: ResponseStream;
    conversationId: String;
  }
  export interface InvokeAssistantStep {
    stepId?: String;
    rationale?: Rationale;
    toolInvocation?: ToolInvocation;
  }
  export type IotCoreThingName = string;
  export interface JobConfiguration {
    fileFormat: FileFormat;
  }
  export type JobId = string;
  export type JobStatus = "PENDING"|"CANCELLED"|"RUNNING"|"COMPLETED"|"FAILED"|"COMPLETED_WITH_FAILURES"|string;
  export type JobSummaries = JobSummary[];
  export type JobSummariesInternal = JobSummaryInternal[];
  export interface JobSummary {
    id: ID;
    name: Name;
    status: JobStatus;
  }
  export interface JobSummaryInternal {
    id: ID;
    name: Name;
    status: JobStatus;
    accountId: AwsAccountId;
  }
  export type KmsKey = string;
  export type KmsKeyId = string;
  export interface ListAccessPoliciesRequest {
    identityType?: IdentityType;
    identityId?: IdentityId;
    resourceType?: ResourceType;
    resourceId?: ID;
    iamArn?: IamArn;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListAccessPoliciesResponse {
    accessPolicySummaries: AccessPolicySummaries;
    nextToken?: NextToken;
  }
  export interface ListActionsRequest {
    targetResourceType: TargetResourceType;
    targetResourceId: CustomID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListActionsResponse {
    actionSummaries: ActionSummaries;
    nextToken: NextToken;
  }
  export interface ListAssetModelCompositeModelsRequest {
    assetModelId: CustomID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetModelVersion?: AssetModelVersionFilter;
  }
  export interface ListAssetModelCompositeModelsResponse {
    assetModelCompositeModelSummaries: AssetModelCompositeModelSummaries;
    nextToken?: NextToken;
  }
  export type ListAssetModelPropertiesFilter = "ALL"|"BASE"|string;
  export interface ListAssetModelPropertiesRequest {
    assetModelId: CustomID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
    filter?: ListAssetModelPropertiesFilter;
    assetModelVersion?: AssetModelVersionFilter;
  }
  export interface ListAssetModelPropertiesResponse {
    assetModelPropertySummaries: AssetModelPropertySummaries;
    nextToken?: NextToken;
  }
  export interface ListAssetModelsRequest {
    assetModelTypes?: ListAssetModelsTypeFilter;
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetModelVersion?: AssetModelVersionFilter;
  }
  export interface ListAssetModelsResponse {
    assetModelSummaries: AssetModelSummaries;
    nextToken?: NextToken;
  }
  export type ListAssetModelsTypeFilter = AssetModelType[];
  export type ListAssetPropertiesFilter = "ALL"|"BASE"|string;
  export interface ListAssetPropertiesRequest {
    assetId: CustomID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
    filter?: ListAssetPropertiesFilter;
  }
  export interface ListAssetPropertiesResponse {
    assetPropertySummaries: AssetPropertySummaries;
    nextToken?: NextToken;
  }
  export interface ListAssetRelationshipsRequest {
    assetId: CustomID;
    traversalType: TraversalType;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListAssetRelationshipsResponse {
    assetRelationshipSummaries: AssetRelationshipSummaries;
    nextToken?: NextToken;
  }
  export type ListAssetsFilter = "ALL"|"TOP_LEVEL"|string;
  export interface ListAssetsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetModelId?: CustomID;
    filter?: ListAssetsFilter;
  }
  export interface ListAssetsResponse {
    assetSummaries: AssetSummaries;
    nextToken?: NextToken;
  }
  export interface ListAssistantsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListAssistantsResponse {
    assistantSummaries: AssistantSummaries;
    nextToken?: NextToken;
  }
  export interface ListAssociatedAssetsRequest {
    assetId: CustomID;
    hierarchyId?: CustomID;
    traversalDirection?: TraversalDirection;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListAssociatedAssetsResponse {
    assetSummaries: AssociatedAssetsSummaries;
    nextToken?: NextToken;
  }
  export type ListBulkImportJobsFilter = "ALL"|"PENDING"|"RUNNING"|"CANCELLED"|"FAILED"|"COMPLETED_WITH_FAILURES"|"COMPLETED"|string;
  export interface ListBulkImportJobsInternalRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
    filter?: ListBulkImportJobsFilter;
  }
  export interface ListBulkImportJobsInternalResponse {
    jobSummaries: JobSummariesInternal;
    nextToken?: NextToken;
  }
  export interface ListBulkImportJobsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
    filter?: ListBulkImportJobsFilter;
  }
  export interface ListBulkImportJobsResponse {
    jobSummaries: JobSummaries;
    nextToken?: NextToken;
  }
  export interface ListCompositionRelationshipsRequest {
    assetModelId: ID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListCompositionRelationshipsResponse {
    compositionRelationshipSummaries: CompositionRelationshipSummaries;
    nextToken?: NextToken;
  }
  export interface ListComputationJobsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetModelId?: ID;
  }
  export interface ListComputationJobsResponse {
    computationJobSummaries: ComputationJobSummaries;
    nextToken?: NextToken;
  }
  export interface ListContextualQueriesExecutionFilter {
    submissionDateTimeAfter?: Timestamp;
    submissionDateTimeBefore?: Timestamp;
  }
  export interface ListContextualQueriesRequest {
    workspaceId: Id;
    maxResults?: PanzaListQueryMaxResults;
    nextToken?: NextToken;
    filter?: ListContextualQueriesExecutionFilter;
  }
  export interface ListContextualQueriesResponse {
    workspaceId: Id;
    queryExecutionSummaries: QueryExecutionSummaries;
    nextToken?: NextToken;
  }
  export interface ListDashboardsRequest {
    projectId: ID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListDashboardsResponse {
    dashboardSummaries: DashboardSummaries;
    nextToken?: NextToken;
  }
  export interface ListGatewaysRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListGatewaysResponse {
    gatewaySummaries: GatewaySummaries;
    nextToken?: NextToken;
  }
  export interface ListNotificationConfigurationsInternalRequest {
    accountId: AwsAccountId;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListNotificationConfigurationsInternalResponse {
    notificationSummaries: NotificationSummaries;
    nextToken?: NextToken;
  }
  export interface ListNotificationConfigurationsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListNotificationConfigurationsResponse {
    notificationSummaries: NotificationSummaries;
    nextToken?: NextToken;
  }
  export interface ListPortalsRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListPortalsResponse {
    portalSummaries?: PortalSummaries;
    nextToken?: NextToken;
  }
  export interface ListProjectAssetsRequest {
    projectId: ID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListProjectAssetsResponse {
    assetIds: AssetIDs;
    nextToken?: NextToken;
  }
  export interface ListProjectsRequest {
    portalId: ID;
    nextToken?: NextToken;
    maxResults?: MaxResults;
  }
  export interface ListProjectsResponse {
    projectSummaries: ProjectSummaries;
    nextToken?: NextToken;
  }
  export interface ListSubscriptionsInternalRequest {
    accountId: AwsAccountId;
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetModelId?: ID;
    assetId?: ID;
  }
  export interface ListSubscriptionsInternalResponse {
    subscriptionSummaries: SubscriptionSummaries;
    nextToken?: NextToken;
  }
  export interface ListTagsForResourceRequest {
    resourceArn: AmazonResourceName;
  }
  export interface ListTagsForResourceResponse {
    tags?: TagMap;
  }
  export interface ListTimeSeriesRequest {
    nextToken?: NextToken;
    maxResults?: MaxResults;
    assetId?: CustomID;
    aliasPrefix?: PropertyAlias;
    timeSeriesType?: ListTimeSeriesType;
  }
  export interface ListTimeSeriesResponse {
    TimeSeriesSummaries: TimeSeriesSummaries;
    nextToken?: NextToken;
  }
  export type ListTimeSeriesType = "ASSOCIATED"|"DISASSOCIATED"|string;
  export interface LockServiceLinkedRoleRequest {
    RoleArn: arnType;
    Timeout: longType;
  }
  export interface LockServiceLinkedRoleResponse {
    CanBeDeleted: booleanType;
    ReasonOfFailure?: stringType;
    RelatedResources?: stringListType;
  }
  export type LoggingLevel = "ERROR"|"INFO"|"OFF"|string;
  export interface LoggingOptions {
    level: LoggingLevel;
  }
  export type LogicalId = string;
  export type Long = number;
  export type Macro = string;
  export type MaxInterpolatedResults = number;
  export type MaxResults = number;
  export interface Measurement {
    processingConfig?: MeasurementProcessingConfig;
  }
  export interface MeasurementProcessingConfig {
    forwardingConfig: ForwardingConfig;
  }
  export type MessageCount = number;
  export type MeteringOperation = "BatchPutAssetPropertyValueInternal"|"Notification"|string;
  export type MeteringOperations = MeteringOperation[];
  export type MeteringResourceId = string;
  export type MeteringResourceType = "ASSET"|"SERIES"|string;
  export interface Metric {
    expression: Expression;
    variables: ExpressionVariables;
    window: MetricWindow;
    processingConfig?: MetricProcessingConfig;
  }
  export interface MetricProcessingConfig {
    computeLocation: ComputeLocation;
  }
  export interface MetricWindow {
    tumbling?: TumblingWindow;
  }
  export type MonitorErrorCode = "INTERNAL_FAILURE"|"VALIDATION_ERROR"|"LIMIT_EXCEEDED"|string;
  export interface MonitorErrorDetails {
    code?: MonitorErrorCode;
    message?: MonitorErrorMessage;
  }
  export type MonitorErrorMessage = string;
  export interface MultiLayerStorage {
    customerManagedS3Storage: CustomerManagedS3Storage;
  }
  export type Name = string;
  export type NextToken = string;
  export type NonEmptyResponseString = string;
  export interface NotificationConfiguration {
    snsArn?: ARN;
  }
  export type NotificationConfigurations = NotificationConfiguration[];
  export type NotificationEvent = "ASSET_MODEL_CREATE"|"ASSET_MODEL_UPDATE"|"ASSET_MODEL_DELETE"|string;
  export type NotificationEvents = NotificationEvent[];
  export type NotificationName = string;
  export type NotificationSubscriber = "IOT_EVENTS"|"IOT_CORE"|string;
  export type NotificationSubscribers = NotificationSubscriber[];
  export type NotificationSummaries = NotificationSummary[];
  export interface NotificationSummary {
    accountId: AwsAccountId;
    notificationName: NotificationName;
    notificationId: ID;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    notificationEvents: NotificationEvents;
    notificationType: NotificationType;
    notificationConfigurations: NotificationConfigurations;
  }
  export type NotificationType = "SNS"|string;
  export type NullableBoolean = boolean;
  export type NumberOfDays = number;
  export type Offset = string;
  export type OffsetInNanos = number;
  export interface OnDemandComputation {
    assetModels: AssetModels;
    timeRange?: TimeRange;
  }
  export type OutputFormat = "TEXTFILE"|"PARQUET"|"ORC"|"AVRO"|"JSON"|string;
  export interface OutputFormatConfiguration {
    format: OutputFormat;
    compression?: CompressionFormat;
  }
  export type PanzaClientToken = string;
  export type PanzaListQueryMaxResults = number;
  export type PanzaMaxResults = number;
  export type PanzaS3Url = string;
  export interface Parquet {
  }
  export interface PauseComputationJobRequest {
    jobId: JobId;
  }
  export interface PauseComputationJobResponse {
    jobId: JobId;
    status: ComputationJobStatus;
  }
  export type Permission = "ADMINISTRATOR"|"VIEWER"|string;
  export type PortalClientId = string;
  export type PortalEdgeAccessState = "ENABLED"|"DISABLED"|string;
  export interface PortalEdgeConfig {
    edgeAccess?: PortalEdgeAccessState;
  }
  export interface PortalResource {
    id: ID;
  }
  export type PortalState = "CREATING"|"PENDING"|"UPDATING"|"DELETING"|"ACTIVE"|"FAILED"|string;
  export interface PortalStatus {
    state: PortalState;
    error?: MonitorErrorDetails;
  }
  export type PortalSummaries = PortalSummary[];
  export interface PortalSummary {
    id: ID;
    name: Name;
    description?: Description;
    startUrl: Url;
    creationDate?: Timestamp;
    lastUpdateDate?: Timestamp;
    roleArn?: IamArn;
    status: PortalStatus;
  }
  export interface Progress {
    percentage?: ComputationPercentage;
  }
  export interface ProjectResource {
    id: ID;
  }
  export type ProjectSharing = ProjectSharingConfig[];
  export interface ProjectSharingConfig {
    sharingScope: ProjectSharingScope;
    status?: ProjectSharingStatus;
    sharingAlias: Alias;
    expirationTime: ExpirationTime;
    sharingId?: ID;
    sharingUrl?: Url;
  }
  export type ProjectSharingScope = "PUBLIC"|string;
  export type ProjectSharingStatus = "ENABLED"|"DISABLED"|string;
  export type ProjectSharingSummaries = ProjectSharingSummary[];
  export interface ProjectSharingSummary {
    sharingScope: ProjectSharingScope;
    status: ProjectSharingStatus;
  }
  export type ProjectSummaries = ProjectSummary[];
  export interface ProjectSummary {
    id: ID;
    name: Name;
    description?: Description;
    creationDate?: Timestamp;
    lastUpdateDate?: Timestamp;
    projectSharing?: ProjectSharingSummaries;
  }
  export interface Property {
    id: ID;
    externalId?: ExternalId;
    name: Name;
    alias?: PropertyAlias;
    notification?: PropertyNotification;
    dataType: PropertyDataType;
    unit?: PropertyUnit;
    type?: PropertyType;
    path?: AssetPropertyPath;
  }
  export type PropertyAlias = string;
  export type PropertyDataType = "STRING"|"INTEGER"|"DOUBLE"|"BOOLEAN"|"STRUCT"|string;
  export type PropertyErrorCode = "ResourceNotFoundException"|"InvalidRequestException"|"InternalFailureException"|"ThrottlingException"|"AccessDeniedException"|string;
  export type PropertyErrorMessage = string;
  export type PropertyIdVersion = number;
  export interface PropertyNotification {
    topic: PropertyNotificationTopic;
    state: PropertyNotificationState;
  }
  export type PropertyNotificationState = "ENABLED"|"DISABLED"|string;
  export type PropertyNotificationTopic = string;
  export interface PropertySubscription {
    assetModelId?: ID;
    assetId?: ID;
    propertyId: ID;
    service: SubscriptionService;
  }
  export interface PropertyType {
    attribute?: Attribute;
    measurement?: Measurement;
    transform?: Transform;
    metric?: Metric;
  }
  export type PropertyUnit = string;
  export type PropertyValueBooleanValue = boolean;
  export type PropertyValueDoubleValue = number;
  export type PropertyValueIntegerValue = number;
  export interface PropertyValueNullValue {
    valueType: RawValueType;
  }
  export type PropertyValueStringValue = string;
  export type PutAssetPropertyValueEntries = PutAssetPropertyValueEntry[];
  export interface PutAssetPropertyValueEntry {
    entryId: EntryId;
    assetId?: ID;
    propertyId?: ID;
    propertyAlias?: AssetPropertyAlias;
    propertyValues: AssetPropertyValues;
  }
  export type PutAssetPropertyValueInternalEntries = PutAssetPropertyValueInternalEntry[];
  export interface PutAssetPropertyValueInternalEntry {
    accountId: AwsAccountId;
    entryId: EntryId;
    assetId?: ID;
    propertyId?: ID;
    propertyIdVersion?: PropertyIdVersion;
    propertyAlias?: AssetPropertyAlias;
    propertyValues: AssetPropertyValuesInternal;
    enableMetering?: MeteringOperations;
    disableStorage?: BooleanValue;
    disableDependencyRouting?: BooleanValue;
    disableNotifications?: BooleanValue;
    allowedNotificationSubscribers?: NotificationSubscribers;
    ingestToWarmTier?: BooleanValue;
  }
  export interface PutContextualQueryConfigurationRequest {
    workspaceId: WorkspaceId;
    queryStateNotifications: QueryStateNotifications;
  }
  export interface PutContextualQueryConfigurationResponse {
    configurationStatus: ConfigurationStatus;
  }
  export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyId?: KmsKeyId;
  }
  export interface PutDefaultEncryptionConfigurationResponse {
    encryptionType: EncryptionType;
    kmsKeyArn?: ARN;
    configurationStatus: ConfigurationStatus;
  }
  export interface PutLoggingOptionsRequest {
    loggingOptions: LoggingOptions;
  }
  export interface PutLoggingOptionsResponse {
  }
  export interface PutNotificationConfigurationRequest {
    notificationName: NotificationName;
    notificationId?: ID;
    notificationEvents: NotificationEvents;
    notificationType: NotificationType;
    notificationConfigurations: NotificationConfigurations;
  }
  export interface PutNotificationConfigurationResponse {
    notificationName: NotificationName;
    notificationId: ID;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    notificationEvents: NotificationEvents;
    notificationType: NotificationType;
    notificationConfigurations: NotificationConfigurations;
  }
  export interface PutStorageConfigurationInternalRequest {
    accountId: AwsAccountId;
    dataVersion: DataVersion;
    configurationStatus: ConfigurationStatus;
  }
  export interface PutStorageConfigurationInternalResponse {
    accountId: AwsAccountId;
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    timestreamStorage?: TimestreamStorage;
    configurationStatus: ConfigurationStatus;
    dataVersion: DataVersion;
    creationDate: Timestamp;
    lastUpdateDate: Timestamp;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
  }
  export interface PutStorageConfigurationRequest {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    timestreamStorage?: TimestreamStorage;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
  }
  export interface PutStorageConfigurationResponse {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    configurationStatus: ConfigurationStatus;
    timestreamStorage?: TimestreamStorage;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
  }
  export type Qualities = Quality[];
  export type Quality = "GOOD"|"BAD"|"UNCERTAIN"|string;
  export interface QueryExecutionError {
    errorCategory?: Integer;
    errorType?: Integer;
    errorMessage?: NonEmptyResponseString;
    retryable?: Boolean;
  }
  export type QueryExecutionState = "QUEUED"|"RUNNING"|"SUCCEEDED"|"FAILED"|"CANCELLED"|string;
  export interface QueryExecutionStatistics {
    dataScannedInBytes?: Long;
    totalExecutionTimeInMillis?: Long;
  }
  export interface QueryExecutionStatus {
    state?: QueryExecutionState;
    submissionDateTime?: Timestamp;
    completionDateTime?: Timestamp;
    error?: QueryExecutionError;
  }
  export interface QueryExecutionStatusSummary {
    state: QueryExecutionState;
    submissionDateTime: Timestamp;
    completionDateTime: Timestamp;
  }
  export type QueryExecutionSummaries = QueryExecutionSummary[];
  export interface QueryExecutionSummary {
    queryExecutionType: QueryExecutionType;
    queryExecutionId: Id;
    queryStatement: SqlStatement;
    materializedViewTableName?: NonEmptyResponseString;
    statistics: QueryExecutionStatistics;
    status: QueryExecutionStatusSummary;
  }
  export type QueryExecutionType = "NORMAL_QUERY"|"REFRESH_QUERY"|string;
  export interface QueryResultSet {
    resultSetMetadata?: ResultSetMetadata;
    rows?: ResultRows;
  }
  export interface QueryStateNotifications {
    destinationType: DestinationType;
  }
  export type QueryStatement = string;
  export interface Rationale {
    text?: String;
  }
  export type RawValueType = "D"|"B"|"S"|"I"|string;
  export type Reason = string;
  export type Resolution = string;
  export interface Resource {
    portal?: PortalResource;
    project?: ProjectResource;
  }
  export type ResourceType = "PORTAL"|"PROJECT"|string;
  export type ResponseStream = EventStream<{step?:InvokeAssistantStep,finalResponse?:FinalResponse}>;
  export interface ResultConfiguration {
    outputLocation: PanzaS3Url;
    outputFormat?: OutputFormatConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
    outputLocationBucketOwner?: BucketOwner;
  }
  export interface ResultRow {
    data?: ResultRowData;
  }
  export type ResultRowData = CellData[];
  export type ResultRows = ResultRow[];
  export interface ResultSetMetadata {
    columnInfo?: ColumnHeaders;
  }
  export interface ResumeComputationJobRequest {
    jobId: JobId;
  }
  export interface ResumeComputationJobResponse {
    jobId: JobId;
    status: ComputationJobStatus;
  }
  export interface RetentionPeriod {
    numberOfDays?: NumberOfDays;
    lastCutoffDate?: Timestamp;
    unlimited?: Unlimited;
  }
  export interface Row {
    data: DatumList;
  }
  export type Rows = Row[];
  export type SSOApplicationId = string;
  export type ScalarType = "BOOLEAN"|"INT"|"DOUBLE"|"TIMESTAMP"|"STRING"|string;
  export type ScalarValue = string;
  export type SendCurrentValue = boolean;
  export interface SiemensIE {
    iotCoreThingName: IotCoreThingName;
  }
  export interface SnsTopic {
    snsTopicArn: ARN;
  }
  export type SqlStatement = string;
  export interface StartContextualQueryExecutionRequest {
    workspaceId: Id;
    queryStatement: SqlStatement;
    resultConfiguration: ResultConfiguration;
    executionParameters?: ExecutionParameters;
    clientRequestToken?: PanzaClientToken;
  }
  export interface StartContextualQueryExecutionResponse {
    queryExecutionId: Id;
  }
  export interface StopContextualQueryExecutionRequest {
    workspaceId: Id;
    queryExecutionId: Id;
  }
  export interface StopContextualQueryExecutionResponse {
  }
  export interface StorageConfiguration {
    storageType: StorageType;
    multiLayerStorage?: MultiLayerStorage;
    disassociatedDataStorage?: DisassociatedDataStorageState;
    retentionPeriod?: RetentionPeriod;
    timestreamStorage?: TimestreamStorage;
    warmTier?: WarmTierState;
    warmTierRetentionPeriod?: WarmTierRetentionPeriod;
  }
  export type StorageType = "SITEWISE_DEFAULT_STORAGE"|"MULTI_LAYER_STORAGE"|string;
  export type String = string;
  export type SubscriptionService = "IOT_EVENTS"|string;
  export type SubscriptionSummaries = PropertySubscription[];
  export type SubscriptionVersion = number;
  export type TagKey = string;
  export type TagKeyList = TagKey[];
  export type TagMap = {[key: string]: TagValue};
  export interface TagResourceRequest {
    resourceArn: AmazonResourceName;
    tags: TagMap;
  }
  export interface TagResourceResponse {
  }
  export type TagValue = string;
  export type TagrisAccountId = string;
  export type TagrisAmazonResourceName = string;
  export type TagrisInternalId = string;
  export type TagrisStatus = "ACTIVE"|"NOT_ACTIVE"|string;
  export type TagrisSweepList = TagrisSweepListItem[];
  export interface TagrisSweepListItem {
    TagrisAccountId?: TagrisAccountId;
    TagrisAmazonResourceName?: TagrisAmazonResourceName;
    TagrisInternalId?: TagrisInternalId;
    TagrisVersion?: TagrisVersion;
  }
  export type TagrisSweepListResult = {[key: string]: TagrisStatus};
  export interface TagrisVerifyResourcesExistInput {
    TagrisSweepList: TagrisSweepList;
  }
  export interface TagrisVerifyResourcesExistOutput {
    TagrisSweepListResult: TagrisSweepListResult;
  }
  export type TagrisVersion = number;
  export interface TargetResource {
    assetId: CustomID;
  }
  export type TargetResourceType = "ASSET"|string;
  export interface TimeInNanos {
    timeInSeconds: TimeInSeconds;
    offsetInNanos?: OffsetInNanos;
  }
  export type TimeInSeconds = number;
  export type TimeOrdering = "ASCENDING"|"DESCENDING"|string;
  export interface TimeRange {
    startTimeExclusive?: Timestamp;
    endTimeInclusive?: Timestamp;
  }
  export type TimeSeriesId = string;
  export type TimeSeriesSummaries = TimeSeriesSummary[];
  export interface TimeSeriesSummary {
    assetId?: ID;
    propertyId?: ID;
    alias?: PropertyAlias;
    timeSeriesId: TimeSeriesId;
    dataType: PropertyDataType;
    dataTypeSpec?: Name;
    timeSeriesCreationDate: Timestamp;
    timeSeriesLastUpdateDate: Timestamp;
    timeSeriesArn: ARN;
  }
  export type Timestamp = Date;
  export type Timestamps = TimeInNanos[];
  export interface TimestreamStorage {
    customerManagedTimestreamStorage: CustomerManagedTimestreamStorage;
  }
  export interface TimestreamTables {
    rawDataTableArn: ARN;
    previewAssetTableArn: ARN;
    previewAssetPropertyTableArn: ARN;
    previewAssetHierarchyTableArn: ARN;
  }
  export interface ToolInvocation {
    name?: String;
    parameters?: ToolInvocationParameters;
  }
  export interface ToolInvocationParameter {
    name?: String;
    value?: String;
    type?: String;
  }
  export type ToolInvocationParameters = ToolInvocationParameter[];
  export interface Transform {
    expression: Expression;
    variables: ExpressionVariables;
    processingConfig?: TransformProcessingConfig;
  }
  export interface TransformProcessingConfig {
    computeLocation: ComputeLocation;
    forwardingConfig?: ForwardingConfig;
  }
  export type TraversalDirection = "PARENT"|"CHILD"|string;
  export type TraversalType = "PATH_TO_ROOT"|string;
  export interface TumblingWindow {
    interval: Interval;
    offset?: Offset;
  }
  export type Unlimited = boolean;
  export interface UnlockServiceLinkedRoleRequest {
    RoleArn: arnType;
    DeletionStatus?: deletionStatus;
  }
  export interface UnlockServiceLinkedRoleResponse {
  }
  export interface UntagResourceRequest {
    resourceArn: AmazonResourceName;
    tagKeys: TagKeyList;
  }
  export interface UntagResourceResponse {
  }
  export interface UpdateAccessPolicyRequest {
    accessPolicyId: ID;
    accessPolicyIdentity: Identity;
    accessPolicyResource: Resource;
    accessPolicyPermission: Permission;
    clientToken?: ClientToken;
  }
  export interface UpdateAccessPolicyResponse {
  }
  export interface UpdateAssetModelCompositeModelRequest {
    assetModelId: CustomID;
    assetModelCompositeModelId: CustomID;
    assetModelCompositeModelExternalId?: ExternalId;
    assetModelCompositeModelDescription?: Description;
    assetModelCompositeModelName: Name;
    clientToken?: ClientToken;
    composedAssetModelId?: CustomID;
    assetModelCompositeModelProperties?: AssetModelProperties;
  }
  export interface UpdateAssetModelCompositeModelResponse {
    assetModelCompositeModelPath: AssetModelCompositeModelPath;
    assetModelStatus: AssetModelStatus;
  }
  export interface UpdateAssetModelRequest {
    assetModelId: CustomID;
    assetModelExternalId?: ExternalId;
    assetModelName: Name;
    assetModelDescription?: Description;
    assetModelProperties?: AssetModelProperties;
    assetModelHierarchies?: AssetModelHierarchies;
    assetModelCompositeModels?: AssetModelCompositeModels;
    clientToken?: ClientToken;
  }
  export interface UpdateAssetModelResponse {
    assetModelStatus: AssetModelStatus;
  }
  export interface UpdateAssetPropertyRequest {
    assetId: CustomID;
    propertyId: CustomID;
    propertyAlias?: PropertyAlias;
    propertyNotificationState?: PropertyNotificationState;
    clientToken?: ClientToken;
    propertyUnit?: PropertyUnit;
  }
  export interface UpdateAssetRequest {
    assetId: CustomID;
    assetExternalId?: ExternalId;
    assetName: Name;
    clientToken?: ClientToken;
    assetDescription?: Description;
  }
  export interface UpdateAssetResponse {
    assetStatus: AssetStatus;
  }
  export interface UpdateComputationJobRequest {
    jobId: JobId;
    onDemandComputation?: OnDemandComputation;
  }
  export interface UpdateComputationJobResponse {
    jobId?: JobId;
    lastUpdateTime?: Timestamp;
    status?: ComputationJobStatus;
  }
  export interface UpdateDashboardRequest {
    dashboardId: ID;
    dashboardName: Name;
    dashboardDescription?: Description;
    dashboardDefinition: DashboardDefinition;
    clientToken?: ClientToken;
  }
  export interface UpdateDashboardResponse {
  }
  export interface UpdateGatewayCapabilityConfigurationRequest {
    gatewayId: ID;
    capabilityNamespace: CapabilityNamespace;
    capabilityConfiguration: CapabilityConfiguration;
  }
  export interface UpdateGatewayCapabilityConfigurationResponse {
    capabilityNamespace: CapabilityNamespace;
    capabilitySyncStatus: CapabilitySyncStatus;
  }
  export interface UpdateGatewayRequest {
    gatewayId: ID;
    gatewayName: Name;
  }
  export interface UpdatePortalRequest {
    portalId: ID;
    portalName: Name;
    portalDescription?: Description;
    portalContactEmail: Email;
    portalLogoImage?: Image;
    roleArn: IamArn;
    clientToken?: ClientToken;
    notificationSenderEmail?: Email;
    alarms?: Alarms;
    edgeConfig?: PortalEdgeConfig;
    projectPublicSharing?: ProjectSharingStatus;
  }
  export interface UpdatePortalResponse {
    portalStatus: PortalStatus;
  }
  export interface UpdateProjectRequest {
    projectId: ID;
    projectName: Name;
    projectDescription?: Description;
    clientToken?: ClientToken;
    projectSharing?: ProjectSharing;
  }
  export interface UpdateProjectResponse {
  }
  export interface UpdateSubscriptionInternalRequest {
    accountId: AwsAccountId;
    assetModelId?: ID;
    assetId?: ID;
    propertyId: ID;
    service: SubscriptionService;
    disabled?: Disabled;
    sendCurrentValue?: SendCurrentValue;
    clientToken?: ClientToken;
  }
  export type Url = string;
  export interface UserIdentity {
    id: IdentityId;
  }
  export type VariableName = string;
  export interface VariableValue {
    propertyId?: Macro;
    hierarchyId?: Macro;
    propertyPath?: AssetModelPropertyPath;
  }
  export interface Variant {
    stringValue?: PropertyValueStringValue;
    integerValue?: PropertyValueIntegerValue;
    doubleValue?: PropertyValueDoubleValue;
    booleanValue?: PropertyValueBooleanValue;
    nullValue?: PropertyValueNullValue;
  }
  export type Version = string;
  export interface WarmTierRetentionPeriod {
    numberOfDays?: NumberOfDays;
    lastCutoffDate?: Timestamp;
    unlimited?: Unlimited;
    creationHotTierCutoffDate?: Timestamp;
  }
  export type WarmTierState = "ENABLED"|"DISABLED"|string;
  export type WorkspaceId = string;
  export type WorkspaceUuid = string;
  export type arnType = string;
  export type booleanType = boolean;
  export type deletionStatus = "SUCCEEDED"|"FAILED"|string;
  export type longType = number;
  export type stringListType = stringType[];
  export type stringType = string;
  /**
   * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
   */
  export type apiVersion = "2019-12-02"|"latest"|string;
  export interface ClientApiVersions {
    /**
     * A string in YYYY-MM-DD format that represents the latest possible API version that can be used in this service. Specify 'latest' to use the latest possible version.
     */
    apiVersion?: apiVersion;
  }
  export type ClientConfiguration = ServiceConfigurationOptions & ClientApiVersions;
  /**
   * Contains interfaces for use with the IoTSiteWise client.
   */
  export import Types = IoTSiteWise;
}
export = IoTSiteWise;
