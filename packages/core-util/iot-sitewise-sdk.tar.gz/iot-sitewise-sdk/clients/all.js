require('aws-sdk/lib/node_loader');
module.exports = {
  SSOInternal: require('./ssointernal'),
  SUP: require('./sup'),
  SUPRest: require('./suprest'),
  GreengrassV2: require('./greengrassv2'),
  IdentityStore: require('./identitystore'),
  IoTAnalytics: require('./iotanalytics'),
  IotBifrostMLOrchestratorLambda: require('./iotbifrostmlorchestratorlambda'),
  AbeautifulandamazingIotBlackPearlConsoleLambda: require('./abeautifulandamazingiotblackpearlconsolelambda'),
  IoTEvents: require('./iotevents'),
  IoTEventsData: require('./ioteventsdata'),
  IoTSiteWise: require('./iotsitewise'),
  KMS: require('./kms')
};