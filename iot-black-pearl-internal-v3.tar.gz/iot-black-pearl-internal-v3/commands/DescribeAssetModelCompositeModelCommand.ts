import {
  IoTSiteWiseClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../IoTSiteWiseClient";
import {
  DescribeAssetModelCompositeModelRequest,
  DescribeAssetModelCompositeModelResponse,
} from "../models/models_0";
import {
  deserializeAws_restJson1DescribeAssetModelCompositeModelCommand,
  serializeAws_restJson1DescribeAssetModelCompositeModelCommand,
} from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@aws-sdk/middleware-serde";
import {
  HttpRequest as __HttpRequest,
  HttpResponse as __HttpResponse,
} from "@aws-sdk/protocol-http";
import { Command as $Command } from "@aws-sdk/smithy-client";
import {
  FinalizeHandlerArguments,
  Handler,
  HandlerExecutionContext,
  MiddlewareStack,
  HttpHandlerOptions as __HttpHandlerOptions,
  MetadataBearer as __MetadataBearer,
  SerdeContext as __SerdeContext,
} from "@aws-sdk/types";

export interface DescribeAssetModelCompositeModelCommandInput extends DescribeAssetModelCompositeModelRequest {}
export interface DescribeAssetModelCompositeModelCommandOutput extends DescribeAssetModelCompositeModelResponse, __MetadataBearer {}

export class DescribeAssetModelCompositeModelCommand extends $Command<DescribeAssetModelCompositeModelCommandInput, DescribeAssetModelCompositeModelCommandOutput, IoTSiteWiseClientResolvedConfig> {
  // Start section: command_properties
  // End section: command_properties

  constructor(readonly input: DescribeAssetModelCompositeModelCommandInput) {
    // Start section: command_constructor
    super();
    // End section: command_constructor
  }

  /**
   * @internal
   */
  resolveMiddleware(
    clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>,
    configuration: IoTSiteWiseClientResolvedConfig,
    options?: __HttpHandlerOptions
  ): Handler<DescribeAssetModelCompositeModelCommandInput, DescribeAssetModelCompositeModelCommandOutput> {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));

    const stack = clientStack.concat(this.middlewareStack);

    const { logger } = configuration;
    const clientName = "IoTSiteWiseClient";
    const commandName = "DescribeAssetModelCompositeModelCommand";
    const handlerExecutionContext: HandlerExecutionContext = {
      logger,
      clientName,
      commandName,
      inputFilterSensitiveLog:
        DescribeAssetModelCompositeModelRequest.filterSensitiveLog,
      outputFilterSensitiveLog:
        DescribeAssetModelCompositeModelResponse.filterSensitiveLog,
    }
    const { requestHandler } = configuration;
    return stack.resolve(
      (request: FinalizeHandlerArguments<any>) =>
        requestHandler.handle(request.request as __HttpRequest, options || {}),
      handlerExecutionContext
    );
  }

  private serialize(
    input: DescribeAssetModelCompositeModelCommandInput,
    context: __SerdeContext
  ): Promise<__HttpRequest> {
    return serializeAws_restJson1DescribeAssetModelCompositeModelCommand(input, context);
  }

  private deserialize(
    output: __HttpResponse,
    context: __SerdeContext
  ): Promise<DescribeAssetModelCompositeModelCommandOutput> {
    return deserializeAws_restJson1DescribeAssetModelCompositeModelCommand(output, context);
  }

  // Start section: command_body_extra
  // End section: command_body_extra
}
