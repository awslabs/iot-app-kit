import {
  IoTSiteWiseClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../IoTSiteWiseClient";
import {
  DescribeAssetCompositeModelRequest,
  DescribeAssetCompositeModelResponse,
} from "../models/models_0";
import {
  deserializeAws_restJson1DescribeAssetCompositeModelCommand,
  serializeAws_restJson1DescribeAssetCompositeModelCommand,
} from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@aws-sdk/middleware-serde";
import {
  HttpRequest as __HttpRequest,
  HttpResponse as __HttpResponse,
} from "@aws-sdk/protocol-http";
import { Command as $Command } from "@aws-sdk/smithy-client";
import {
  FinalizeHandlerArguments,
  Handler,
  HandlerExecutionContext,
  MiddlewareStack,
  HttpHandlerOptions as __HttpHandlerOptions,
  MetadataBearer as __MetadataBearer,
  SerdeContext as __SerdeContext,
} from "@aws-sdk/types";

export interface DescribeAssetCompositeModelCommandInput extends DescribeAssetCompositeModelRequest {}
export interface DescribeAssetCompositeModelCommandOutput extends DescribeAssetCompositeModelResponse, __MetadataBearer {}

export class DescribeAssetCompositeModelCommand extends $Command<DescribeAssetCompositeModelCommandInput, DescribeAssetCompositeModelCommandOutput, IoTSiteWiseClientResolvedConfig> {
  // Start section: command_properties
  // End section: command_properties

  constructor(readonly input: DescribeAssetCompositeModelCommandInput) {
    // Start section: command_constructor
    super();
    // End section: command_constructor
  }

  /**
   * @internal
   */
  resolveMiddleware(
    clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>,
    configuration: IoTSiteWiseClientResolvedConfig,
    options?: __HttpHandlerOptions
  ): Handler<DescribeAssetCompositeModelCommandInput, DescribeAssetCompositeModelCommandOutput> {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));

    const stack = clientStack.concat(this.middlewareStack);

    const { logger } = configuration;
    const clientName = "IoTSiteWiseClient";
    const commandName = "DescribeAssetCompositeModelCommand";
    const handlerExecutionContext: HandlerExecutionContext = {
      logger,
      clientName,
      commandName,
      inputFilterSensitiveLog:
        DescribeAssetCompositeModelRequest.filterSensitiveLog,
      outputFilterSensitiveLog:
        DescribeAssetCompositeModelResponse.filterSensitiveLog,
    }
    const { requestHandler } = configuration;
    return stack.resolve(
      (request: FinalizeHandlerArguments<any>) =>
        requestHandler.handle(request.request as __HttpRequest, options || {}),
      handlerExecutionContext
    );
  }

  private serialize(
    input: DescribeAssetCompositeModelCommandInput,
    context: __SerdeContext
  ): Promise<__HttpRequest> {
    return serializeAws_restJson1DescribeAssetCompositeModelCommand(input, context);
  }

  private deserialize(
    output: __HttpResponse,
    context: __SerdeContext
  ): Promise<DescribeAssetCompositeModelCommandOutput> {
    return deserializeAws_restJson1DescribeAssetCompositeModelCommand(output, context);
  }

  // Start section: command_body_extra
  // End section: command_body_extra
}
