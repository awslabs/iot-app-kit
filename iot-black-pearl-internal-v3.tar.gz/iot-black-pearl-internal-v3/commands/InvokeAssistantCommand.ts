import {
  IoTSiteWiseClientResolvedConfig,
  ServiceInputTypes,
  ServiceOutputTypes,
} from "../IoTSiteWiseClient";
import {
  InvokeAssistantRequest,
  InvokeAssistantResponse,
} from "../models/models_0";
import {
  deserializeAws_restJson1InvokeAssistantCommand,
  serializeAws_restJson1InvokeAssistantCommand,
} from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@aws-sdk/middleware-serde";
import {
  HttpRequest as __HttpRequest,
  HttpResponse as __HttpResponse,
} from "@aws-sdk/protocol-http";
import { Command as $Command } from "@aws-sdk/smithy-client";
import {
  FinalizeHandlerArguments,
  Handler,
  HandlerExecutionContext,
  MiddlewareStack,
  EventStreamSerdeContext as __EventStreamSerdeContext,
  HttpHandlerOptions as __HttpHandlerOptions,
  MetadataBearer as __MetadataBearer,
  SerdeContext as __SerdeContext,
} from "@aws-sdk/types";

export interface InvokeAssistantCommandInput extends InvokeAssistantRequest {}
export interface InvokeAssistantCommandOutput extends InvokeAssistantResponse, __MetadataBearer {}

/**
 * Invoke AI Assistant
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { IoTSiteWiseClient, InvokeAssistantCommand } from "@amzn/iot-black-pearl-internal-v3"; // ES Modules import
 * // const { IoTSiteWiseClient, InvokeAssistantCommand } = require("@amzn/iot-black-pearl-internal-v3"); // CommonJS import
 * const client = new IoTSiteWiseClient(config);
 * const command = new InvokeAssistantCommand(input);
 * const response = await client.send(command);
 * ```
 *
 * @see {@link InvokeAssistantCommandInput} for command's `input` shape.
 * @see {@link InvokeAssistantCommandOutput} for command's `response` shape.
 * @see {@link IoTSiteWiseClientResolvedConfig | config} for command's `input` shape.
 *
 */
export class InvokeAssistantCommand extends $Command<InvokeAssistantCommandInput, InvokeAssistantCommandOutput, IoTSiteWiseClientResolvedConfig> {
  // Start section: command_properties
  // End section: command_properties

  constructor(readonly input: InvokeAssistantCommandInput) {
    // Start section: command_constructor
    super();
    // End section: command_constructor
  }

  /**
   * @internal
   */
  resolveMiddleware(
    clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>,
    configuration: IoTSiteWiseClientResolvedConfig,
    options?: __HttpHandlerOptions
  ): Handler<InvokeAssistantCommandInput, InvokeAssistantCommandOutput> {
    this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));

    const stack = clientStack.concat(this.middlewareStack);

    const { logger } = configuration;
    const clientName = "IoTSiteWiseClient";
    const commandName = "InvokeAssistantCommand";
    const handlerExecutionContext: HandlerExecutionContext = {
      logger,
      clientName,
      commandName,
      inputFilterSensitiveLog:
        InvokeAssistantRequest.filterSensitiveLog,
      outputFilterSensitiveLog:
        InvokeAssistantResponse.filterSensitiveLog,
    }
    const { requestHandler } = configuration;
    return stack.resolve(
      (request: FinalizeHandlerArguments<any>) =>
        requestHandler.handle(request.request as __HttpRequest, options || {}),
      handlerExecutionContext
    );
  }

  private serialize(
    input: InvokeAssistantCommandInput,
    context: __SerdeContext
  ): Promise<__HttpRequest> {
    return serializeAws_restJson1InvokeAssistantCommand(input, context);
  }

  private deserialize(
    output: __HttpResponse,
    context: __SerdeContext & __EventStreamSerdeContext
  ): Promise<InvokeAssistantCommandOutput> {
    return deserializeAws_restJson1InvokeAssistantCommand(output, context);
  }

  // Start section: command_body_extra
  // End section: command_body_extra
}
