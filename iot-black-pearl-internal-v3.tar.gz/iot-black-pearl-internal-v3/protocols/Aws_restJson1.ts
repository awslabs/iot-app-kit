import {
  AssociateAssetsCommandInput,
  AssociateAssetsCommandOutput,
} from "../commands/AssociateAssetsCommand";
import {
  AssociateTimeSeriesToAssetPropertyCommandInput,
  AssociateTimeSeriesToAssetPropertyCommandOutput,
} from "../commands/AssociateTimeSeriesToAssetPropertyCommand";
import {
  BatchAssociateProjectAssetsCommandInput,
  BatchAssociateProjectAssetsCommandOutput,
} from "../commands/BatchAssociateProjectAssetsCommand";
import {
  BatchDisassociateProjectAssetsCommandInput,
  BatchDisassociateProjectAssetsCommandOutput,
} from "../commands/BatchDisassociateProjectAssetsCommand";
import {
  CreateAccessPolicyCommandInput,
  CreateAccessPolicyCommandOutput,
} from "../commands/CreateAccessPolicyCommand";
import {
  CreateAssetCommandInput,
  CreateAssetCommandOutput,
} from "../commands/CreateAssetCommand";
import {
  CreateAssetModelCommandInput,
  CreateAssetModelCommandOutput,
} from "../commands/CreateAssetModelCommand";
import {
  CreateAssetModelCompositeModelCommandInput,
  CreateAssetModelCompositeModelCommandOutput,
} from "../commands/CreateAssetModelCompositeModelCommand";
import {
  CreateDashboardCommandInput,
  CreateDashboardCommandOutput,
} from "../commands/CreateDashboardCommand";
import {
  CreateGatewayCommandInput,
  CreateGatewayCommandOutput,
} from "../commands/CreateGatewayCommand";
import {
  CreatePortalCommandInput,
  CreatePortalCommandOutput,
} from "../commands/CreatePortalCommand";
import {
  CreateProjectCommandInput,
  CreateProjectCommandOutput,
} from "../commands/CreateProjectCommand";
import {
  DeleteAccessPolicyCommandInput,
  DeleteAccessPolicyCommandOutput,
} from "../commands/DeleteAccessPolicyCommand";
import {
  DeleteAssetCommandInput,
  DeleteAssetCommandOutput,
} from "../commands/DeleteAssetCommand";
import {
  DeleteAssetModelCommandInput,
  DeleteAssetModelCommandOutput,
} from "../commands/DeleteAssetModelCommand";
import {
  DeleteAssetModelCompositeModelCommandInput,
  DeleteAssetModelCompositeModelCommandOutput,
} from "../commands/DeleteAssetModelCompositeModelCommand";
import {
  DeleteDashboardCommandInput,
  DeleteDashboardCommandOutput,
} from "../commands/DeleteDashboardCommand";
import {
  DeleteGatewayCommandInput,
  DeleteGatewayCommandOutput,
} from "../commands/DeleteGatewayCommand";
import {
  DeletePortalCommandInput,
  DeletePortalCommandOutput,
} from "../commands/DeletePortalCommand";
import {
  DeleteProjectCommandInput,
  DeleteProjectCommandOutput,
} from "../commands/DeleteProjectCommand";
import {
  DeleteTimeSeriesCommandInput,
  DeleteTimeSeriesCommandOutput,
} from "../commands/DeleteTimeSeriesCommand";
import {
  DescribeAccessPolicyCommandInput,
  DescribeAccessPolicyCommandOutput,
} from "../commands/DescribeAccessPolicyCommand";
import {
  DescribeActionCommandInput,
  DescribeActionCommandOutput,
} from "../commands/DescribeActionCommand";
import {
  DescribeAssetCommandInput,
  DescribeAssetCommandOutput,
} from "../commands/DescribeAssetCommand";
import {
  DescribeAssetCompositeModelCommandInput,
  DescribeAssetCompositeModelCommandOutput,
} from "../commands/DescribeAssetCompositeModelCommand";
import {
  DescribeAssetModelCommandInput,
  DescribeAssetModelCommandOutput,
} from "../commands/DescribeAssetModelCommand";
import {
  DescribeAssetModelCompositeModelCommandInput,
  DescribeAssetModelCompositeModelCommandOutput,
} from "../commands/DescribeAssetModelCompositeModelCommand";
import {
  DescribeAssetPropertyCommandInput,
  DescribeAssetPropertyCommandOutput,
} from "../commands/DescribeAssetPropertyCommand";
import {
  DescribeDashboardCommandInput,
  DescribeDashboardCommandOutput,
} from "../commands/DescribeDashboardCommand";
import {
  DescribeGatewayCapabilityConfigurationCommandInput,
  DescribeGatewayCapabilityConfigurationCommandOutput,
} from "../commands/DescribeGatewayCapabilityConfigurationCommand";
import {
  DescribeGatewayCommandInput,
  DescribeGatewayCommandOutput,
} from "../commands/DescribeGatewayCommand";
import {
  DescribeLoggingOptionsCommandInput,
  DescribeLoggingOptionsCommandOutput,
} from "../commands/DescribeLoggingOptionsCommand";
import {
  DescribePortalCommandInput,
  DescribePortalCommandOutput,
} from "../commands/DescribePortalCommand";
import {
  DescribeProjectCommandInput,
  DescribeProjectCommandOutput,
} from "../commands/DescribeProjectCommand";
import {
  DescribeTimeSeriesCommandInput,
  DescribeTimeSeriesCommandOutput,
} from "../commands/DescribeTimeSeriesCommand";
import {
  DisassociateAssetsCommandInput,
  DisassociateAssetsCommandOutput,
} from "../commands/DisassociateAssetsCommand";
import {
  DisassociateTimeSeriesFromAssetPropertyCommandInput,
  DisassociateTimeSeriesFromAssetPropertyCommandOutput,
} from "../commands/DisassociateTimeSeriesFromAssetPropertyCommand";
import {
  ExecuteActionCommandInput,
  ExecuteActionCommandOutput,
} from "../commands/ExecuteActionCommand";
import {
  InvokeAssistantCommandInput,
  InvokeAssistantCommandOutput,
} from "../commands/InvokeAssistantCommand";
import {
  ListAccessPoliciesCommandInput,
  ListAccessPoliciesCommandOutput,
} from "../commands/ListAccessPoliciesCommand";
import {
  ListActionsCommandInput,
  ListActionsCommandOutput,
} from "../commands/ListActionsCommand";
import {
  ListAssetModelCompositeModelsCommandInput,
  ListAssetModelCompositeModelsCommandOutput,
} from "../commands/ListAssetModelCompositeModelsCommand";
import {
  ListAssetModelPropertiesCommandInput,
  ListAssetModelPropertiesCommandOutput,
} from "../commands/ListAssetModelPropertiesCommand";
import {
  ListAssetModelsCommandInput,
  ListAssetModelsCommandOutput,
} from "../commands/ListAssetModelsCommand";
import {
  ListAssetPropertiesCommandInput,
  ListAssetPropertiesCommandOutput,
} from "../commands/ListAssetPropertiesCommand";
import {
  ListAssetRelationshipsCommandInput,
  ListAssetRelationshipsCommandOutput,
} from "../commands/ListAssetRelationshipsCommand";
import {
  ListAssetsCommandInput,
  ListAssetsCommandOutput,
} from "../commands/ListAssetsCommand";
import {
  ListAssociatedAssetsCommandInput,
  ListAssociatedAssetsCommandOutput,
} from "../commands/ListAssociatedAssetsCommand";
import {
  ListCompositionRelationshipsCommandInput,
  ListCompositionRelationshipsCommandOutput,
} from "../commands/ListCompositionRelationshipsCommand";
import {
  ListDashboardsCommandInput,
  ListDashboardsCommandOutput,
} from "../commands/ListDashboardsCommand";
import {
  ListGatewaysCommandInput,
  ListGatewaysCommandOutput,
} from "../commands/ListGatewaysCommand";
import {
  ListPortalsCommandInput,
  ListPortalsCommandOutput,
} from "../commands/ListPortalsCommand";
import {
  ListProjectAssetsCommandInput,
  ListProjectAssetsCommandOutput,
} from "../commands/ListProjectAssetsCommand";
import {
  ListProjectsCommandInput,
  ListProjectsCommandOutput,
} from "../commands/ListProjectsCommand";
import {
  ListTimeSeriesCommandInput,
  ListTimeSeriesCommandOutput,
} from "../commands/ListTimeSeriesCommand";
import {
  PutLoggingOptionsCommandInput,
  PutLoggingOptionsCommandOutput,
} from "../commands/PutLoggingOptionsCommand";
import {
  UpdateAccessPolicyCommandInput,
  UpdateAccessPolicyCommandOutput,
} from "../commands/UpdateAccessPolicyCommand";
import {
  UpdateAssetCommandInput,
  UpdateAssetCommandOutput,
} from "../commands/UpdateAssetCommand";
import {
  UpdateAssetModelCommandInput,
  UpdateAssetModelCommandOutput,
} from "../commands/UpdateAssetModelCommand";
import {
  UpdateAssetModelCompositeModelCommandInput,
  UpdateAssetModelCompositeModelCommandOutput,
} from "../commands/UpdateAssetModelCompositeModelCommand";
import {
  UpdateAssetPropertyCommandInput,
  UpdateAssetPropertyCommandOutput,
} from "../commands/UpdateAssetPropertyCommand";
import {
  UpdateDashboardCommandInput,
  UpdateDashboardCommandOutput,
} from "../commands/UpdateDashboardCommand";
import {
  UpdateGatewayCapabilityConfigurationCommandInput,
  UpdateGatewayCapabilityConfigurationCommandOutput,
} from "../commands/UpdateGatewayCapabilityConfigurationCommand";
import {
  UpdateGatewayCommandInput,
  UpdateGatewayCommandOutput,
} from "../commands/UpdateGatewayCommand";
import {
  UpdatePortalCommandInput,
  UpdatePortalCommandOutput,
} from "../commands/UpdatePortalCommand";
import {
  UpdateProjectCommandInput,
  UpdateProjectCommandOutput,
} from "../commands/UpdateProjectCommand";
import {
  AccessPolicySummary,
  ActionDefinition,
  ActionPayload,
  ActionSummary,
  Alarms,
  AssetCompositeModel,
  AssetCompositeModelPathSegment,
  AssetCompositeModelSummary,
  AssetErrorDetails,
  AssetHierarchy,
  AssetHierarchyInfo,
  AssetModelCompositeModel,
  AssetModelCompositeModelDefinition,
  AssetModelCompositeModelPathSegment,
  AssetModelCompositeModelSummary,
  AssetModelHierarchy,
  AssetModelHierarchyDefinition,
  AssetModelProperty,
  AssetModelPropertyDefinition,
  AssetModelPropertyPathSegment,
  AssetModelPropertySummary,
  AssetModelStatus,
  AssetModelSummary,
  AssetProperty,
  AssetPropertyPathSegment,
  AssetPropertySummary,
  AssetRelationshipSummary,
  AssetStatus,
  AssetSummary,
  AssociatedAssetsSummary,
  Attribute,
  BadGatewayException,
  CompositeModelProperty,
  CompositionDetails,
  CompositionRelationshipItem,
  CompositionRelationshipSummary,
  ConflictException,
  ConflictingOperationException,
  DashboardSummary,
  DetailedError,
  ErrorDetails,
  ExpressionVariable,
  FinalResponse,
  ForwardingConfig,
  GatewayCapabilitySummary,
  GatewayPlatform,
  GatewaySummary,
  Greengrass,
  GreengrassV2,
  GroupIdentity,
  IAMRoleIdentity,
  IAMUserIdentity,
  Identity,
  Image,
  ImageFile,
  ImageLocation,
  InternalFailureException,
  InternalServerException,
  InvalidRequestException,
  InvokeAssistantStep,
  LimitExceededException,
  LoggingOptions,
  Measurement,
  MeasurementProcessingConfig,
  Metric,
  MetricProcessingConfig,
  MetricWindow,
  MonitorErrorDetails,
  PortalEdgeConfig,
  PortalResource,
  PortalStatus,
  PortalSummary,
  PreconditionFailedException,
  ProjectResource,
  ProjectSharingConfig,
  ProjectSharingSummary,
  ProjectSummary,
  Property,
  PropertyNotification,
  PropertyType,
  Rationale,
  Resource,
  ResourceAlreadyExistsException,
  ResourceNotFoundException,
  ResponseStream,
  ServiceQuotaExceededException,
  TargetResource,
  ThrottlingException,
  TimeSeriesSummary,
  ToolInvocation,
  ToolInvocationParameter,
  Transform,
  TransformProcessingConfig,
  TumblingWindow,
  UserIdentity,
  VariableValue,
} from "../models/models_0";
import {
  HttpRequest as __HttpRequest,
  HttpResponse as __HttpResponse,
  isValidHostname as __isValidHostname,
} from "@aws-sdk/protocol-http";
import {
  expectInt32 as __expectInt32,
  expectNonNull as __expectNonNull,
  expectObject as __expectObject,
  expectString as __expectString,
  extendedEncodeURIComponent as __extendedEncodeURIComponent,
} from "@aws-sdk/smithy-client";
import {
  Endpoint as __Endpoint,
  EventStreamSerdeContext as __EventStreamSerdeContext,
  MetadataBearer as __MetadataBearer,
  ResponseMetadata as __ResponseMetadata,
  SerdeContext as __SerdeContext,
  SmithyException as __SmithyException,
} from "@aws-sdk/types";
import { v4 as generateIdempotencyToken } from "uuid";

export const serializeAws_restJson1CreateGatewayCommand = async(
  input: CreateGatewayCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways";
  let body: any;
  body = JSON.stringify({
    ...(input.gatewayName !== undefined && input.gatewayName !== null &&{ "gatewayName": input.gatewayName }),
    ...(input.gatewayPlatform !== undefined && input.gatewayPlatform !== null &&{ "gatewayPlatform": serializeAws_restJson1GatewayPlatform(input.gatewayPlatform, context) }),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DeleteGatewayCommand = async(
  input: DeleteGatewayCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways/{gatewayId}";
  if (input.gatewayId !== undefined) {
    const labelValue: string = input.gatewayId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: gatewayId.');
    }
    resolvedPath = resolvedPath.replace("{gatewayId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: gatewayId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeGatewayCommand = async(
  input: DescribeGatewayCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways/{gatewayId}";
  if (input.gatewayId !== undefined) {
    const labelValue: string = input.gatewayId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: gatewayId.');
    }
    resolvedPath = resolvedPath.replace("{gatewayId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: gatewayId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeGatewayCapabilityConfigurationCommand = async(
  input: DescribeGatewayCapabilityConfigurationCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways/{gatewayId}/capability/{capabilityNamespace}";
  if (input.gatewayId !== undefined) {
    const labelValue: string = input.gatewayId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: gatewayId.');
    }
    resolvedPath = resolvedPath.replace("{gatewayId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: gatewayId.');
  }
  if (input.capabilityNamespace !== undefined) {
    const labelValue: string = input.capabilityNamespace;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: capabilityNamespace.');
    }
    resolvedPath = resolvedPath.replace("{capabilityNamespace}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: capabilityNamespace.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1ListGatewaysCommand = async(
  input: ListGatewaysCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways";
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1UpdateGatewayCommand = async(
  input: UpdateGatewayCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways/{gatewayId}";
  if (input.gatewayId !== undefined) {
    const labelValue: string = input.gatewayId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: gatewayId.');
    }
    resolvedPath = resolvedPath.replace("{gatewayId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: gatewayId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.gatewayName !== undefined && input.gatewayName !== null &&{ "gatewayName": input.gatewayName }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateGatewayCapabilityConfigurationCommand = async(
  input: UpdateGatewayCapabilityConfigurationCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/20200301/gateways/{gatewayId}/capability";
  if (input.gatewayId !== undefined) {
    const labelValue: string = input.gatewayId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: gatewayId.');
    }
    resolvedPath = resolvedPath.replace("{gatewayId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: gatewayId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.capabilityConfiguration !== undefined && input.capabilityConfiguration !== null &&{ "capabilityConfiguration": input.capabilityConfiguration }),
    ...(input.capabilityNamespace !== undefined && input.capabilityNamespace !== null &&{ "capabilityNamespace": input.capabilityNamespace }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1AssociateAssetsCommand = async(
  input: AssociateAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/associate";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.childAssetId !== undefined && input.childAssetId !== null &&{ "childAssetId": input.childAssetId }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.hierarchyId !== undefined && input.hierarchyId !== null &&{ "hierarchyId": input.hierarchyId }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1AssociateTimeSeriesToAssetPropertyCommand = async(
  input: AssociateTimeSeriesToAssetPropertyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/timeseries/associate";
  const query: any = {
    ...(input.alias !== undefined && { "alias": input.alias }),
    ...(input.assetId !== undefined && { "assetId": input.assetId }),
    ...(input.propertyId !== undefined && { "propertyId": input.propertyId }),
  };
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1CreateAssetCommand = async(
  input: CreateAssetCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets";
  let body: any;
  body = JSON.stringify({
    ...(input.assetDescription !== undefined && input.assetDescription !== null &&{ "assetDescription": input.assetDescription }),
    ...(input.assetExternalId !== undefined && input.assetExternalId !== null &&{ "assetExternalId": input.assetExternalId }),
    ...(input.assetId !== undefined && input.assetId !== null &&{ "assetId": input.assetId }),
    ...(input.assetModelId !== undefined && input.assetModelId !== null &&{ "assetModelId": input.assetModelId }),
    ...(input.assetName !== undefined && input.assetName !== null &&{ "assetName": input.assetName }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreateAssetModelCommand = async(
  input: CreateAssetModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models";
  let body: any;
  body = JSON.stringify({
    ...(input.assetModelCompositeModels !== undefined && input.assetModelCompositeModels !== null &&{ "assetModelCompositeModels": serializeAws_restJson1AssetModelCompositeModelDefinitions(input.assetModelCompositeModels, context) }),
    ...(input.assetModelDescription !== undefined && input.assetModelDescription !== null &&{ "assetModelDescription": input.assetModelDescription }),
    ...(input.assetModelExternalId !== undefined && input.assetModelExternalId !== null &&{ "assetModelExternalId": input.assetModelExternalId }),
    ...(input.assetModelHierarchies !== undefined && input.assetModelHierarchies !== null &&{ "assetModelHierarchies": serializeAws_restJson1AssetModelHierarchyDefinitions(input.assetModelHierarchies, context) }),
    ...(input.assetModelId !== undefined && input.assetModelId !== null &&{ "assetModelId": input.assetModelId }),
    ...(input.assetModelName !== undefined && input.assetModelName !== null &&{ "assetModelName": input.assetModelName }),
    ...(input.assetModelProperties !== undefined && input.assetModelProperties !== null &&{ "assetModelProperties": serializeAws_restJson1AssetModelPropertyDefinitions(input.assetModelProperties, context) }),
    ...(input.assetModelType !== undefined && input.assetModelType !== null &&{ "assetModelType": input.assetModelType }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreateAssetModelCompositeModelCommand = async(
  input: CreateAssetModelCompositeModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composite-models";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetModelCompositeModelDescription !== undefined && input.assetModelCompositeModelDescription !== null &&{ "assetModelCompositeModelDescription": input.assetModelCompositeModelDescription }),
    ...(input.assetModelCompositeModelExternalId !== undefined && input.assetModelCompositeModelExternalId !== null &&{ "assetModelCompositeModelExternalId": input.assetModelCompositeModelExternalId }),
    ...(input.assetModelCompositeModelId !== undefined && input.assetModelCompositeModelId !== null &&{ "assetModelCompositeModelId": input.assetModelCompositeModelId }),
    ...(input.assetModelCompositeModelName !== undefined && input.assetModelCompositeModelName !== null &&{ "assetModelCompositeModelName": input.assetModelCompositeModelName }),
    ...(input.assetModelCompositeModelProperties !== undefined && input.assetModelCompositeModelProperties !== null &&{ "assetModelCompositeModelProperties": serializeAws_restJson1AssetModelPropertyDefinitions(input.assetModelCompositeModelProperties, context) }),
    ...(input.assetModelCompositeModelType !== undefined && input.assetModelCompositeModelType !== null &&{ "assetModelCompositeModelType": input.assetModelCompositeModelType }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.composedAssetModelId !== undefined && input.composedAssetModelId !== null &&{ "composedAssetModelId": input.composedAssetModelId }),
    ...(input.parentAssetModelCompositeModelId !== undefined && input.parentAssetModelCompositeModelId !== null &&{ "parentAssetModelCompositeModelId": input.parentAssetModelCompositeModelId }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DeleteAssetCommand = async(
  input: DeleteAssetCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeleteAssetModelCommand = async(
  input: DeleteAssetModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeleteAssetModelCompositeModelCommand = async(
  input: DeleteAssetModelCompositeModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composite-models/{assetModelCompositeModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  if (input.assetModelCompositeModelId !== undefined) {
    const labelValue: string = input.assetModelCompositeModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelCompositeModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelCompositeModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelCompositeModelId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeleteTimeSeriesCommand = async(
  input: DeleteTimeSeriesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/timeseries/delete";
  const query: any = {
    ...(input.alias !== undefined && { "alias": input.alias }),
    ...(input.assetId !== undefined && { "assetId": input.assetId }),
    ...(input.propertyId !== undefined && { "propertyId": input.propertyId }),
  };
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DescribeActionCommand = async(
  input: DescribeActionCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/actions/{actionId}";
  if (input.actionId !== undefined) {
    const labelValue: string = input.actionId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: actionId.');
    }
    resolvedPath = resolvedPath.replace("{actionId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: actionId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeAssetCommand = async(
  input: DescribeAssetCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  const query: any = {
    ...(input.excludeProperties !== undefined && { "excludeProperties": input.excludeProperties.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DescribeAssetCompositeModelCommand = async(
  input: DescribeAssetCompositeModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/composite-models/{assetCompositeModelId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  if (input.assetCompositeModelId !== undefined) {
    const labelValue: string = input.assetCompositeModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetCompositeModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetCompositeModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetCompositeModelId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeAssetModelCommand = async(
  input: DescribeAssetModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  const query: any = {
    ...(input.excludeProperties !== undefined && { "excludeProperties": input.excludeProperties.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DescribeAssetModelCompositeModelCommand = async(
  input: DescribeAssetModelCompositeModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composite-models/{assetModelCompositeModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  if (input.assetModelCompositeModelId !== undefined) {
    const labelValue: string = input.assetModelCompositeModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelCompositeModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelCompositeModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelCompositeModelId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeAssetPropertyCommand = async(
  input: DescribeAssetPropertyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/properties/{propertyId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  if (input.propertyId !== undefined) {
    const labelValue: string = input.propertyId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: propertyId.');
    }
    resolvedPath = resolvedPath.replace("{propertyId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: propertyId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeLoggingOptionsCommand = async(
  input: DescribeLoggingOptionsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/logging";
  let body: any;
  body = "";
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeTimeSeriesCommand = async(
  input: DescribeTimeSeriesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/timeseries/describe";
  const query: any = {
    ...(input.alias !== undefined && { "alias": input.alias }),
    ...(input.assetId !== undefined && { "assetId": input.assetId }),
    ...(input.propertyId !== undefined && { "propertyId": input.propertyId }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DisassociateAssetsCommand = async(
  input: DisassociateAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/disassociate";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.childAssetId !== undefined && input.childAssetId !== null &&{ "childAssetId": input.childAssetId }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.hierarchyId !== undefined && input.hierarchyId !== null &&{ "hierarchyId": input.hierarchyId }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DisassociateTimeSeriesFromAssetPropertyCommand = async(
  input: DisassociateTimeSeriesFromAssetPropertyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/timeseries/disassociate";
  const query: any = {
    ...(input.alias !== undefined && { "alias": input.alias }),
    ...(input.assetId !== undefined && { "assetId": input.assetId }),
    ...(input.propertyId !== undefined && { "propertyId": input.propertyId }),
  };
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ExecuteActionCommand = async(
  input: ExecuteActionCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/actions";
  let body: any;
  body = JSON.stringify({
    ...(input.actionDefinitionId !== undefined && input.actionDefinitionId !== null &&{ "actionDefinitionId": input.actionDefinitionId }),
    ...(input.actionPayload !== undefined && input.actionPayload !== null &&{ "actionPayload": serializeAws_restJson1ActionPayload(input.actionPayload, context) }),
    ...(input.clientToken !== undefined && input.clientToken !== null &&{ "clientToken": input.clientToken }),
    ...(input.targetResource !== undefined && input.targetResource !== null &&{ "targetResource": serializeAws_restJson1TargetResource(input.targetResource, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1ListActionsCommand = async(
  input: ListActionsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/actions";
  const query: any = {
    ...(input.targetResourceType !== undefined && { "targetResourceType": input.targetResourceType }),
    ...(input.targetResourceId !== undefined && { "targetResourceId": input.targetResourceId }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetModelCompositeModelsCommand = async(
  input: ListAssetModelCompositeModelsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composite-models";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetModelPropertiesCommand = async(
  input: ListAssetModelPropertiesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/properties";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
    ...(input.filter !== undefined && { "filter": input.filter }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetModelsCommand = async(
  input: ListAssetModelsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models";
  const query: any = {
    ...(input.assetModelTypes !== undefined && { "assetModelTypes": (input.assetModelTypes || []).map(_entry => _entry as any) }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetPropertiesCommand = async(
  input: ListAssetPropertiesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/properties";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
    ...(input.filter !== undefined && { "filter": input.filter }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetRelationshipsCommand = async(
  input: ListAssetRelationshipsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/assetRelationships";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  const query: any = {
    ...(input.traversalType !== undefined && { "traversalType": input.traversalType }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssetsCommand = async(
  input: ListAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets";
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
    ...(input.assetModelId !== undefined && { "assetModelId": input.assetModelId }),
    ...(input.filter !== undefined && { "filter": input.filter }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListAssociatedAssetsCommand = async(
  input: ListAssociatedAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/hierarchies";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  const query: any = {
    ...(input.hierarchyId !== undefined && { "hierarchyId": input.hierarchyId }),
    ...(input.traversalDirection !== undefined && { "traversalDirection": input.traversalDirection }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListCompositionRelationshipsCommand = async(
  input: ListCompositionRelationshipsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composition-relationships";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListTimeSeriesCommand = async(
  input: ListTimeSeriesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/timeseries";
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
    ...(input.assetId !== undefined && { "assetId": input.assetId }),
    ...(input.aliasPrefix !== undefined && { "aliasPrefix": input.aliasPrefix }),
    ...(input.timeSeriesType !== undefined && { "timeSeriesType": input.timeSeriesType }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1PutLoggingOptionsCommand = async(
  input: PutLoggingOptionsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/logging";
  let body: any;
  body = JSON.stringify({
    ...(input.loggingOptions !== undefined && input.loggingOptions !== null &&{ "loggingOptions": serializeAws_restJson1LoggingOptions(input.loggingOptions, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateAssetCommand = async(
  input: UpdateAssetCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetDescription !== undefined && input.assetDescription !== null &&{ "assetDescription": input.assetDescription }),
    ...(input.assetExternalId !== undefined && input.assetExternalId !== null &&{ "assetExternalId": input.assetExternalId }),
    ...(input.assetName !== undefined && input.assetName !== null &&{ "assetName": input.assetName }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateAssetModelCommand = async(
  input: UpdateAssetModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetModelCompositeModels !== undefined && input.assetModelCompositeModels !== null &&{ "assetModelCompositeModels": serializeAws_restJson1AssetModelCompositeModels(input.assetModelCompositeModels, context) }),
    ...(input.assetModelDescription !== undefined && input.assetModelDescription !== null &&{ "assetModelDescription": input.assetModelDescription }),
    ...(input.assetModelExternalId !== undefined && input.assetModelExternalId !== null &&{ "assetModelExternalId": input.assetModelExternalId }),
    ...(input.assetModelHierarchies !== undefined && input.assetModelHierarchies !== null &&{ "assetModelHierarchies": serializeAws_restJson1AssetModelHierarchies(input.assetModelHierarchies, context) }),
    ...(input.assetModelName !== undefined && input.assetModelName !== null &&{ "assetModelName": input.assetModelName }),
    ...(input.assetModelProperties !== undefined && input.assetModelProperties !== null &&{ "assetModelProperties": serializeAws_restJson1AssetModelProperties(input.assetModelProperties, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateAssetModelCompositeModelCommand = async(
  input: UpdateAssetModelCompositeModelCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/asset-models/{assetModelId}/composite-models/{assetModelCompositeModelId}";
  if (input.assetModelId !== undefined) {
    const labelValue: string = input.assetModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelId.');
  }
  if (input.assetModelCompositeModelId !== undefined) {
    const labelValue: string = input.assetModelCompositeModelId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetModelCompositeModelId.');
    }
    resolvedPath = resolvedPath.replace("{assetModelCompositeModelId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetModelCompositeModelId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetModelCompositeModelDescription !== undefined && input.assetModelCompositeModelDescription !== null &&{ "assetModelCompositeModelDescription": input.assetModelCompositeModelDescription }),
    ...(input.assetModelCompositeModelExternalId !== undefined && input.assetModelCompositeModelExternalId !== null &&{ "assetModelCompositeModelExternalId": input.assetModelCompositeModelExternalId }),
    ...(input.assetModelCompositeModelName !== undefined && input.assetModelCompositeModelName !== null &&{ "assetModelCompositeModelName": input.assetModelCompositeModelName }),
    ...(input.assetModelCompositeModelProperties !== undefined && input.assetModelCompositeModelProperties !== null &&{ "assetModelCompositeModelProperties": serializeAws_restJson1AssetModelProperties(input.assetModelCompositeModelProperties, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateAssetPropertyCommand = async(
  input: UpdateAssetPropertyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assets/{assetId}/properties/{propertyId}";
  if (input.assetId !== undefined) {
    const labelValue: string = input.assetId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: assetId.');
    }
    resolvedPath = resolvedPath.replace("{assetId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: assetId.');
  }
  if (input.propertyId !== undefined) {
    const labelValue: string = input.propertyId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: propertyId.');
    }
    resolvedPath = resolvedPath.replace("{propertyId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: propertyId.');
  }
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.propertyAlias !== undefined && input.propertyAlias !== null &&{ "propertyAlias": input.propertyAlias }),
    ...(input.propertyNotificationState !== undefined && input.propertyNotificationState !== null &&{ "propertyNotificationState": input.propertyNotificationState }),
    ...(input.propertyUnit !== undefined && input.propertyUnit !== null &&{ "propertyUnit": input.propertyUnit }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "api." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1BatchAssociateProjectAssetsCommand = async(
  input: BatchAssociateProjectAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}/assets/associate";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetIds !== undefined && input.assetIds !== null &&{ "assetIds": serializeAws_restJson1IDs(input.assetIds, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1BatchDisassociateProjectAssetsCommand = async(
  input: BatchDisassociateProjectAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}/assets/disassociate";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.assetIds !== undefined && input.assetIds !== null &&{ "assetIds": serializeAws_restJson1IDs(input.assetIds, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreateAccessPolicyCommand = async(
  input: CreateAccessPolicyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/access-policies";
  let body: any;
  body = JSON.stringify({
    ...(input.accessPolicyIdentity !== undefined && input.accessPolicyIdentity !== null &&{ "accessPolicyIdentity": serializeAws_restJson1Identity(input.accessPolicyIdentity, context) }),
    ...(input.accessPolicyPermission !== undefined && input.accessPolicyPermission !== null &&{ "accessPolicyPermission": input.accessPolicyPermission }),
    ...(input.accessPolicyResource !== undefined && input.accessPolicyResource !== null &&{ "accessPolicyResource": serializeAws_restJson1Resource(input.accessPolicyResource, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreateDashboardCommand = async(
  input: CreateDashboardCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/dashboards";
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.dashboardDefinition !== undefined && input.dashboardDefinition !== null &&{ "dashboardDefinition": input.dashboardDefinition }),
    ...(input.dashboardDescription !== undefined && input.dashboardDescription !== null &&{ "dashboardDescription": input.dashboardDescription }),
    ...(input.dashboardName !== undefined && input.dashboardName !== null &&{ "dashboardName": input.dashboardName }),
    ...(input.projectId !== undefined && input.projectId !== null &&{ "projectId": input.projectId }),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreatePortalCommand = async(
  input: CreatePortalCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/portals";
  let body: any;
  body = JSON.stringify({
    ...(input.alarms !== undefined && input.alarms !== null &&{ "alarms": serializeAws_restJson1Alarms(input.alarms, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.edgeConfig !== undefined && input.edgeConfig !== null &&{ "edgeConfig": serializeAws_restJson1PortalEdgeConfig(input.edgeConfig, context) }),
    ...(input.notificationSenderEmail !== undefined && input.notificationSenderEmail !== null &&{ "notificationSenderEmail": input.notificationSenderEmail }),
    ...(input.portalAuthMode !== undefined && input.portalAuthMode !== null &&{ "portalAuthMode": input.portalAuthMode }),
    ...(input.portalContactEmail !== undefined && input.portalContactEmail !== null &&{ "portalContactEmail": input.portalContactEmail }),
    ...(input.portalDescription !== undefined && input.portalDescription !== null &&{ "portalDescription": input.portalDescription }),
    ...(input.portalLogoImageFile !== undefined && input.portalLogoImageFile !== null &&{ "portalLogoImageFile": serializeAws_restJson1ImageFile(input.portalLogoImageFile, context) }),
    ...(input.portalName !== undefined && input.portalName !== null &&{ "portalName": input.portalName }),
    ...(input.projectPublicSharing !== undefined && input.projectPublicSharing !== null &&{ "projectPublicSharing": input.projectPublicSharing }),
    ...(input.roleArn !== undefined && input.roleArn !== null &&{ "roleArn": input.roleArn }),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1CreateProjectCommand = async(
  input: CreateProjectCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects";
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.portalId !== undefined && input.portalId !== null &&{ "portalId": input.portalId }),
    ...(input.projectDescription !== undefined && input.projectDescription !== null &&{ "projectDescription": input.projectDescription }),
    ...(input.projectName !== undefined && input.projectName !== null &&{ "projectName": input.projectName }),
    ...(input.projectSharing !== undefined && input.projectSharing !== null &&{ "projectSharing": serializeAws_restJson1ProjectSharing(input.projectSharing, context) }),
    ...(input.tags !== undefined && input.tags !== null &&{ "tags": serializeAws_restJson1TagMap(input.tags, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DeleteAccessPolicyCommand = async(
  input: DeleteAccessPolicyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/access-policies/{accessPolicyId}";
  if (input.accessPolicyId !== undefined) {
    const labelValue: string = input.accessPolicyId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: accessPolicyId.');
    }
    resolvedPath = resolvedPath.replace("{accessPolicyId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: accessPolicyId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeleteDashboardCommand = async(
  input: DeleteDashboardCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/dashboards/{dashboardId}";
  if (input.dashboardId !== undefined) {
    const labelValue: string = input.dashboardId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: dashboardId.');
    }
    resolvedPath = resolvedPath.replace("{dashboardId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: dashboardId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeletePortalCommand = async(
  input: DeletePortalCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/portals/{portalId}";
  if (input.portalId !== undefined) {
    const labelValue: string = input.portalId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: portalId.');
    }
    resolvedPath = resolvedPath.replace("{portalId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: portalId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DeleteProjectCommand = async(
  input: DeleteProjectCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  const query: any = {
    ...(input.clientToken !== undefined && { "clientToken": input.clientToken }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "DELETE",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1DescribeAccessPolicyCommand = async(
  input: DescribeAccessPolicyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/access-policies/{accessPolicyId}";
  if (input.accessPolicyId !== undefined) {
    const labelValue: string = input.accessPolicyId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: accessPolicyId.');
    }
    resolvedPath = resolvedPath.replace("{accessPolicyId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: accessPolicyId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeDashboardCommand = async(
  input: DescribeDashboardCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/dashboards/{dashboardId}";
  if (input.dashboardId !== undefined) {
    const labelValue: string = input.dashboardId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: dashboardId.');
    }
    resolvedPath = resolvedPath.replace("{dashboardId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: dashboardId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribePortalCommand = async(
  input: DescribePortalCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/portals/{portalId}";
  if (input.portalId !== undefined) {
    const labelValue: string = input.portalId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: portalId.');
    }
    resolvedPath = resolvedPath.replace("{portalId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: portalId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1DescribeProjectCommand = async(
  input: DescribeProjectCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1ListAccessPoliciesCommand = async(
  input: ListAccessPoliciesCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/access-policies";
  const query: any = {
    ...(input.identityType !== undefined && { "identityType": input.identityType }),
    ...(input.identityId !== undefined && { "identityId": input.identityId }),
    ...(input.resourceType !== undefined && { "resourceType": input.resourceType }),
    ...(input.resourceId !== undefined && { "resourceId": input.resourceId }),
    ...(input.iamArn !== undefined && { "iamArn": input.iamArn }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListDashboardsCommand = async(
  input: ListDashboardsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/dashboards";
  const query: any = {
    ...(input.projectId !== undefined && { "projectId": input.projectId }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListPortalsCommand = async(
  input: ListPortalsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/portals";
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListProjectAssetsCommand = async(
  input: ListProjectAssetsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}/assets";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  const query: any = {
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1ListProjectsCommand = async(
  input: ListProjectsCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects";
  const query: any = {
    ...(input.portalId !== undefined && { "portalId": input.portalId }),
    ...(input.nextToken !== undefined && { "nextToken": input.nextToken }),
    ...(input.maxResults !== undefined && { "maxResults": input.maxResults.toString() }),
  };
  let body: any;
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "GET",
    headers,
    path: resolvedPath,
    query,
    body,
  });
}

export const serializeAws_restJson1UpdateAccessPolicyCommand = async(
  input: UpdateAccessPolicyCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/access-policies/{accessPolicyId}";
  if (input.accessPolicyId !== undefined) {
    const labelValue: string = input.accessPolicyId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: accessPolicyId.');
    }
    resolvedPath = resolvedPath.replace("{accessPolicyId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: accessPolicyId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.accessPolicyIdentity !== undefined && input.accessPolicyIdentity !== null &&{ "accessPolicyIdentity": serializeAws_restJson1Identity(input.accessPolicyIdentity, context) }),
    ...(input.accessPolicyPermission !== undefined && input.accessPolicyPermission !== null &&{ "accessPolicyPermission": input.accessPolicyPermission }),
    ...(input.accessPolicyResource !== undefined && input.accessPolicyResource !== null &&{ "accessPolicyResource": serializeAws_restJson1Resource(input.accessPolicyResource, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateDashboardCommand = async(
  input: UpdateDashboardCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/dashboards/{dashboardId}";
  if (input.dashboardId !== undefined) {
    const labelValue: string = input.dashboardId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: dashboardId.');
    }
    resolvedPath = resolvedPath.replace("{dashboardId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: dashboardId.');
  }
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.dashboardDefinition !== undefined && input.dashboardDefinition !== null &&{ "dashboardDefinition": input.dashboardDefinition }),
    ...(input.dashboardDescription !== undefined && input.dashboardDescription !== null &&{ "dashboardDescription": input.dashboardDescription }),
    ...(input.dashboardName !== undefined && input.dashboardName !== null &&{ "dashboardName": input.dashboardName }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdatePortalCommand = async(
  input: UpdatePortalCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/portals/{portalId}";
  if (input.portalId !== undefined) {
    const labelValue: string = input.portalId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: portalId.');
    }
    resolvedPath = resolvedPath.replace("{portalId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: portalId.');
  }
  let body: any;
  body = JSON.stringify({
    ...(input.alarms !== undefined && input.alarms !== null &&{ "alarms": serializeAws_restJson1Alarms(input.alarms, context) }),
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.edgeConfig !== undefined && input.edgeConfig !== null &&{ "edgeConfig": serializeAws_restJson1PortalEdgeConfig(input.edgeConfig, context) }),
    ...(input.notificationSenderEmail !== undefined && input.notificationSenderEmail !== null &&{ "notificationSenderEmail": input.notificationSenderEmail }),
    ...(input.portalContactEmail !== undefined && input.portalContactEmail !== null &&{ "portalContactEmail": input.portalContactEmail }),
    ...(input.portalDescription !== undefined && input.portalDescription !== null &&{ "portalDescription": input.portalDescription }),
    ...(input.portalLogoImage !== undefined && input.portalLogoImage !== null &&{ "portalLogoImage": serializeAws_restJson1Image(input.portalLogoImage, context) }),
    ...(input.portalName !== undefined && input.portalName !== null &&{ "portalName": input.portalName }),
    ...(input.projectPublicSharing !== undefined && input.projectPublicSharing !== null &&{ "projectPublicSharing": input.projectPublicSharing }),
    ...(input.roleArn !== undefined && input.roleArn !== null &&{ "roleArn": input.roleArn }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1UpdateProjectCommand = async(
  input: UpdateProjectCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/projects/{projectId}";
  if (input.projectId !== undefined) {
    const labelValue: string = input.projectId;
    if (labelValue.length <= 0) {
      throw new Error('Empty value provided for input HTTP label: projectId.');
    }
    resolvedPath = resolvedPath.replace("{projectId}", __extendedEncodeURIComponent(labelValue));
  } else {
    throw new Error('No value provided for input HTTP label: projectId.');
  }
  let body: any;
  body = JSON.stringify({
    'clientToken': input.clientToken ?? generateIdempotencyToken(),
    ...(input.projectDescription !== undefined && input.projectDescription !== null &&{ "projectDescription": input.projectDescription }),
    ...(input.projectName !== undefined && input.projectName !== null &&{ "projectName": input.projectName }),
    ...(input.projectSharing !== undefined && input.projectSharing !== null &&{ "projectSharing": serializeAws_restJson1ProjectSharing(input.projectSharing, context) }),
  });
  let { hostname: resolvedHostname } = await context.endpoint();
  if (context.disableHostPrefix !== true) {
    resolvedHostname = "monitor." + resolvedHostname;
    if (!__isValidHostname(resolvedHostname)) {
      throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
    }
  }
  return new __HttpRequest({
    protocol,
    hostname: resolvedHostname,
    port,
    method: "PUT",
    headers,
    path: resolvedPath,
    body,
  });
}

export const serializeAws_restJson1InvokeAssistantCommand = async(
  input: InvokeAssistantCommandInput,
  context: __SerdeContext
): Promise<__HttpRequest> => {
  const {hostname, protocol = "https", port, path: basePath} = await context.endpoint();
  const headers: any = {
    'content-type': "application/json",
  };
  let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/assistant/invocation";
  let body: any;
  body = JSON.stringify({
    ...(input.conversationId !== undefined && input.conversationId !== null &&{ "conversationId": input.conversationId }),
    ...(input.message !== undefined && input.message !== null &&{ "message": input.message }),
  });
  return new __HttpRequest({
    protocol,
    hostname,
    port,
    method: "POST",
    headers,
    path: resolvedPath,
    body,
  });
}

export const deserializeAws_restJson1CreateGatewayCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateGatewayCommandOutput> => {
  if (output.statusCode !== 201 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateGatewayCommandError(output, context);
  }
  const contents: CreateGatewayCommandOutput = {
    $metadata: deserializeMetadata(output),
    gatewayArn: undefined,
    gatewayId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.gatewayArn !== undefined && data.gatewayArn !== null) {
    contents.gatewayArn = __expectString(data.gatewayArn);
  }
  if (data.gatewayId !== undefined && data.gatewayId !== null) {
    contents.gatewayId = __expectString(data.gatewayId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateGatewayCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateGatewayCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteGatewayCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteGatewayCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteGatewayCommandError(output, context);
  }
  const contents: DeleteGatewayCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteGatewayCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteGatewayCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeGatewayCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeGatewayCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeGatewayCommandError(output, context);
  }
  const contents: DescribeGatewayCommandOutput = {
    $metadata: deserializeMetadata(output),
    creationDate: undefined,
    gatewayArn: undefined,
    gatewayCapabilitySummaries: undefined,
    gatewayId: undefined,
    gatewayName: undefined,
    gatewayPlatform: undefined,
    lastUpdateDate: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.creationDate !== undefined && data.creationDate !== null) {
    contents.creationDate = new Date(Math.round(data.creationDate * 1000));
  }
  if (data.gatewayArn !== undefined && data.gatewayArn !== null) {
    contents.gatewayArn = __expectString(data.gatewayArn);
  }
  if (data.gatewayCapabilitySummaries !== undefined && data.gatewayCapabilitySummaries !== null) {
    contents.gatewayCapabilitySummaries = deserializeAws_restJson1GatewayCapabilitySummaries(data.gatewayCapabilitySummaries, context);
  }
  if (data.gatewayId !== undefined && data.gatewayId !== null) {
    contents.gatewayId = __expectString(data.gatewayId);
  }
  if (data.gatewayName !== undefined && data.gatewayName !== null) {
    contents.gatewayName = __expectString(data.gatewayName);
  }
  if (data.gatewayPlatform !== undefined && data.gatewayPlatform !== null) {
    contents.gatewayPlatform = deserializeAws_restJson1GatewayPlatform(data.gatewayPlatform, context);
  }
  if (data.lastUpdateDate !== undefined && data.lastUpdateDate !== null) {
    contents.lastUpdateDate = new Date(Math.round(data.lastUpdateDate * 1000));
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeGatewayCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeGatewayCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeGatewayCapabilityConfigurationCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeGatewayCapabilityConfigurationCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeGatewayCapabilityConfigurationCommandError(output, context);
  }
  const contents: DescribeGatewayCapabilityConfigurationCommandOutput = {
    $metadata: deserializeMetadata(output),
    capabilityConfiguration: undefined,
    capabilityNamespace: undefined,
    capabilitySyncStatus: undefined,
    gatewayId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.capabilityConfiguration !== undefined && data.capabilityConfiguration !== null) {
    contents.capabilityConfiguration = __expectString(data.capabilityConfiguration);
  }
  if (data.capabilityNamespace !== undefined && data.capabilityNamespace !== null) {
    contents.capabilityNamespace = __expectString(data.capabilityNamespace);
  }
  if (data.capabilitySyncStatus !== undefined && data.capabilitySyncStatus !== null) {
    contents.capabilitySyncStatus = __expectString(data.capabilitySyncStatus);
  }
  if (data.gatewayId !== undefined && data.gatewayId !== null) {
    contents.gatewayId = __expectString(data.gatewayId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeGatewayCapabilityConfigurationCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeGatewayCapabilityConfigurationCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListGatewaysCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListGatewaysCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListGatewaysCommandError(output, context);
  }
  const contents: ListGatewaysCommandOutput = {
    $metadata: deserializeMetadata(output),
    gatewaySummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.gatewaySummaries !== undefined && data.gatewaySummaries !== null) {
    contents.gatewaySummaries = deserializeAws_restJson1GatewaySummaries(data.gatewaySummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListGatewaysCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListGatewaysCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateGatewayCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateGatewayCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateGatewayCommandError(output, context);
  }
  const contents: UpdateGatewayCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateGatewayCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateGatewayCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateGatewayCapabilityConfigurationCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateGatewayCapabilityConfigurationCommandOutput> => {
  if (output.statusCode !== 201 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateGatewayCapabilityConfigurationCommandError(output, context);
  }
  const contents: UpdateGatewayCapabilityConfigurationCommandOutput = {
    $metadata: deserializeMetadata(output),
    capabilityNamespace: undefined,
    capabilitySyncStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.capabilityNamespace !== undefined && data.capabilityNamespace !== null) {
    contents.capabilityNamespace = __expectString(data.capabilityNamespace);
  }
  if (data.capabilitySyncStatus !== undefined && data.capabilitySyncStatus !== null) {
    contents.capabilitySyncStatus = __expectString(data.capabilitySyncStatus);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateGatewayCapabilityConfigurationCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateGatewayCapabilityConfigurationCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1AssociateAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<AssociateAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1AssociateAssetsCommandError(output, context);
  }
  const contents: AssociateAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1AssociateAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<AssociateAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1AssociateTimeSeriesToAssetPropertyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<AssociateTimeSeriesToAssetPropertyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1AssociateTimeSeriesToAssetPropertyCommandError(output, context);
  }
  const contents: AssociateTimeSeriesToAssetPropertyCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1AssociateTimeSeriesToAssetPropertyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<AssociateTimeSeriesToAssetPropertyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateAssetCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateAssetCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateAssetCommandError(output, context);
  }
  const contents: CreateAssetCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetArn: undefined,
    assetId: undefined,
    assetStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetArn !== undefined && data.assetArn !== null) {
    contents.assetArn = __expectString(data.assetArn);
  }
  if (data.assetId !== undefined && data.assetId !== null) {
    contents.assetId = __expectString(data.assetId);
  }
  if (data.assetStatus !== undefined && data.assetStatus !== null) {
    contents.assetStatus = deserializeAws_restJson1AssetStatus(data.assetStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateAssetCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateAssetCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateAssetModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateAssetModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateAssetModelCommandError(output, context);
  }
  const contents: CreateAssetModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelArn: undefined,
    assetModelId: undefined,
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelArn !== undefined && data.assetModelArn !== null) {
    contents.assetModelArn = __expectString(data.assetModelArn);
  }
  if (data.assetModelId !== undefined && data.assetModelId !== null) {
    contents.assetModelId = __expectString(data.assetModelId);
  }
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateAssetModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateAssetModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateAssetModelCompositeModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateAssetModelCompositeModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateAssetModelCompositeModelCommandError(output, context);
  }
  const contents: CreateAssetModelCompositeModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelCompositeModelId: undefined,
    assetModelCompositeModelPath: undefined,
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelCompositeModelId !== undefined && data.assetModelCompositeModelId !== null) {
    contents.assetModelCompositeModelId = __expectString(data.assetModelCompositeModelId);
  }
  if (data.assetModelCompositeModelPath !== undefined && data.assetModelCompositeModelPath !== null) {
    contents.assetModelCompositeModelPath = deserializeAws_restJson1AssetModelCompositeModelPath(data.assetModelCompositeModelPath, context);
  }
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateAssetModelCompositeModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateAssetModelCompositeModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "PreconditionFailedException":
    case "com.amazon.iot.bifrost.exceptions#PreconditionFailedException":
      response = {
        ...await deserializeAws_restJson1PreconditionFailedExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteAssetCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteAssetCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteAssetCommandError(output, context);
  }
  const contents: DeleteAssetCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetStatus !== undefined && data.assetStatus !== null) {
    contents.assetStatus = deserializeAws_restJson1AssetStatus(data.assetStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteAssetCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteAssetCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteAssetModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteAssetModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteAssetModelCommandError(output, context);
  }
  const contents: DeleteAssetModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteAssetModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteAssetModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "PreconditionFailedException":
    case "com.amazon.iot.bifrost.exceptions#PreconditionFailedException":
      response = {
        ...await deserializeAws_restJson1PreconditionFailedExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteAssetModelCompositeModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteAssetModelCompositeModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteAssetModelCompositeModelCommandError(output, context);
  }
  const contents: DeleteAssetModelCompositeModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteAssetModelCompositeModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteAssetModelCompositeModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "PreconditionFailedException":
    case "com.amazon.iot.bifrost.exceptions#PreconditionFailedException":
      response = {
        ...await deserializeAws_restJson1PreconditionFailedExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteTimeSeriesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteTimeSeriesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteTimeSeriesCommandError(output, context);
  }
  const contents: DeleteTimeSeriesCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteTimeSeriesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteTimeSeriesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeActionCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeActionCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeActionCommandError(output, context);
  }
  const contents: DescribeActionCommandOutput = {
    $metadata: deserializeMetadata(output),
    actionDefinitionId: undefined,
    actionId: undefined,
    actionPayload: undefined,
    executionTime: undefined,
    targetResource: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.actionDefinitionId !== undefined && data.actionDefinitionId !== null) {
    contents.actionDefinitionId = __expectString(data.actionDefinitionId);
  }
  if (data.actionId !== undefined && data.actionId !== null) {
    contents.actionId = __expectString(data.actionId);
  }
  if (data.actionPayload !== undefined && data.actionPayload !== null) {
    contents.actionPayload = deserializeAws_restJson1ActionPayload(data.actionPayload, context);
  }
  if (data.executionTime !== undefined && data.executionTime !== null) {
    contents.executionTime = new Date(Math.round(data.executionTime * 1000));
  }
  if (data.targetResource !== undefined && data.targetResource !== null) {
    contents.targetResource = deserializeAws_restJson1TargetResource(data.targetResource, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeActionCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeActionCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAssetCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAssetCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAssetCommandError(output, context);
  }
  const contents: DescribeAssetCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetArn: undefined,
    assetCompositeModelSummaries: undefined,
    assetCompositeModels: undefined,
    assetCreationDate: undefined,
    assetDescription: undefined,
    assetExternalId: undefined,
    assetHierarchies: undefined,
    assetId: undefined,
    assetLastUpdateDate: undefined,
    assetModelId: undefined,
    assetName: undefined,
    assetProperties: undefined,
    assetStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetArn !== undefined && data.assetArn !== null) {
    contents.assetArn = __expectString(data.assetArn);
  }
  if (data.assetCompositeModelSummaries !== undefined && data.assetCompositeModelSummaries !== null) {
    contents.assetCompositeModelSummaries = deserializeAws_restJson1AssetCompositeModelSummaries(data.assetCompositeModelSummaries, context);
  }
  if (data.assetCompositeModels !== undefined && data.assetCompositeModels !== null) {
    contents.assetCompositeModels = deserializeAws_restJson1AssetCompositeModels(data.assetCompositeModels, context);
  }
  if (data.assetCreationDate !== undefined && data.assetCreationDate !== null) {
    contents.assetCreationDate = new Date(Math.round(data.assetCreationDate * 1000));
  }
  if (data.assetDescription !== undefined && data.assetDescription !== null) {
    contents.assetDescription = __expectString(data.assetDescription);
  }
  if (data.assetExternalId !== undefined && data.assetExternalId !== null) {
    contents.assetExternalId = __expectString(data.assetExternalId);
  }
  if (data.assetHierarchies !== undefined && data.assetHierarchies !== null) {
    contents.assetHierarchies = deserializeAws_restJson1AssetHierarchies(data.assetHierarchies, context);
  }
  if (data.assetId !== undefined && data.assetId !== null) {
    contents.assetId = __expectString(data.assetId);
  }
  if (data.assetLastUpdateDate !== undefined && data.assetLastUpdateDate !== null) {
    contents.assetLastUpdateDate = new Date(Math.round(data.assetLastUpdateDate * 1000));
  }
  if (data.assetModelId !== undefined && data.assetModelId !== null) {
    contents.assetModelId = __expectString(data.assetModelId);
  }
  if (data.assetName !== undefined && data.assetName !== null) {
    contents.assetName = __expectString(data.assetName);
  }
  if (data.assetProperties !== undefined && data.assetProperties !== null) {
    contents.assetProperties = deserializeAws_restJson1AssetProperties(data.assetProperties, context);
  }
  if (data.assetStatus !== undefined && data.assetStatus !== null) {
    contents.assetStatus = deserializeAws_restJson1AssetStatus(data.assetStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAssetCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAssetCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAssetCompositeModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAssetCompositeModelCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAssetCompositeModelCommandError(output, context);
  }
  const contents: DescribeAssetCompositeModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    actionDefinitions: undefined,
    assetCompositeModelDescription: undefined,
    assetCompositeModelExternalId: undefined,
    assetCompositeModelId: undefined,
    assetCompositeModelName: undefined,
    assetCompositeModelPath: undefined,
    assetCompositeModelProperties: undefined,
    assetCompositeModelSummaries: undefined,
    assetCompositeModelType: undefined,
    assetId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.actionDefinitions !== undefined && data.actionDefinitions !== null) {
    contents.actionDefinitions = deserializeAws_restJson1ActionDefinitions(data.actionDefinitions, context);
  }
  if (data.assetCompositeModelDescription !== undefined && data.assetCompositeModelDescription !== null) {
    contents.assetCompositeModelDescription = __expectString(data.assetCompositeModelDescription);
  }
  if (data.assetCompositeModelExternalId !== undefined && data.assetCompositeModelExternalId !== null) {
    contents.assetCompositeModelExternalId = __expectString(data.assetCompositeModelExternalId);
  }
  if (data.assetCompositeModelId !== undefined && data.assetCompositeModelId !== null) {
    contents.assetCompositeModelId = __expectString(data.assetCompositeModelId);
  }
  if (data.assetCompositeModelName !== undefined && data.assetCompositeModelName !== null) {
    contents.assetCompositeModelName = __expectString(data.assetCompositeModelName);
  }
  if (data.assetCompositeModelPath !== undefined && data.assetCompositeModelPath !== null) {
    contents.assetCompositeModelPath = deserializeAws_restJson1AssetCompositeModelPath(data.assetCompositeModelPath, context);
  }
  if (data.assetCompositeModelProperties !== undefined && data.assetCompositeModelProperties !== null) {
    contents.assetCompositeModelProperties = deserializeAws_restJson1AssetProperties(data.assetCompositeModelProperties, context);
  }
  if (data.assetCompositeModelSummaries !== undefined && data.assetCompositeModelSummaries !== null) {
    contents.assetCompositeModelSummaries = deserializeAws_restJson1AssetCompositeModelSummaries(data.assetCompositeModelSummaries, context);
  }
  if (data.assetCompositeModelType !== undefined && data.assetCompositeModelType !== null) {
    contents.assetCompositeModelType = __expectString(data.assetCompositeModelType);
  }
  if (data.assetId !== undefined && data.assetId !== null) {
    contents.assetId = __expectString(data.assetId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAssetCompositeModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAssetCompositeModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAssetModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAssetModelCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAssetModelCommandError(output, context);
  }
  const contents: DescribeAssetModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelArn: undefined,
    assetModelCompositeModelSummaries: undefined,
    assetModelCompositeModels: undefined,
    assetModelCreationDate: undefined,
    assetModelDescription: undefined,
    assetModelExternalId: undefined,
    assetModelHierarchies: undefined,
    assetModelId: undefined,
    assetModelLastUpdateDate: undefined,
    assetModelName: undefined,
    assetModelProperties: undefined,
    assetModelStatus: undefined,
    assetModelType: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelArn !== undefined && data.assetModelArn !== null) {
    contents.assetModelArn = __expectString(data.assetModelArn);
  }
  if (data.assetModelCompositeModelSummaries !== undefined && data.assetModelCompositeModelSummaries !== null) {
    contents.assetModelCompositeModelSummaries = deserializeAws_restJson1AssetModelCompositeModelSummaries(data.assetModelCompositeModelSummaries, context);
  }
  if (data.assetModelCompositeModels !== undefined && data.assetModelCompositeModels !== null) {
    contents.assetModelCompositeModels = deserializeAws_restJson1AssetModelCompositeModels(data.assetModelCompositeModels, context);
  }
  if (data.assetModelCreationDate !== undefined && data.assetModelCreationDate !== null) {
    contents.assetModelCreationDate = new Date(Math.round(data.assetModelCreationDate * 1000));
  }
  if (data.assetModelDescription !== undefined && data.assetModelDescription !== null) {
    contents.assetModelDescription = __expectString(data.assetModelDescription);
  }
  if (data.assetModelExternalId !== undefined && data.assetModelExternalId !== null) {
    contents.assetModelExternalId = __expectString(data.assetModelExternalId);
  }
  if (data.assetModelHierarchies !== undefined && data.assetModelHierarchies !== null) {
    contents.assetModelHierarchies = deserializeAws_restJson1AssetModelHierarchies(data.assetModelHierarchies, context);
  }
  if (data.assetModelId !== undefined && data.assetModelId !== null) {
    contents.assetModelId = __expectString(data.assetModelId);
  }
  if (data.assetModelLastUpdateDate !== undefined && data.assetModelLastUpdateDate !== null) {
    contents.assetModelLastUpdateDate = new Date(Math.round(data.assetModelLastUpdateDate * 1000));
  }
  if (data.assetModelName !== undefined && data.assetModelName !== null) {
    contents.assetModelName = __expectString(data.assetModelName);
  }
  if (data.assetModelProperties !== undefined && data.assetModelProperties !== null) {
    contents.assetModelProperties = deserializeAws_restJson1AssetModelProperties(data.assetModelProperties, context);
  }
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  if (data.assetModelType !== undefined && data.assetModelType !== null) {
    contents.assetModelType = __expectString(data.assetModelType);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAssetModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAssetModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAssetModelCompositeModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAssetModelCompositeModelCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAssetModelCompositeModelCommandError(output, context);
  }
  const contents: DescribeAssetModelCompositeModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    actionDefinitions: undefined,
    assetModelCompositeModelDescription: undefined,
    assetModelCompositeModelExternalId: undefined,
    assetModelCompositeModelId: undefined,
    assetModelCompositeModelName: undefined,
    assetModelCompositeModelPath: undefined,
    assetModelCompositeModelProperties: undefined,
    assetModelCompositeModelSummaries: undefined,
    assetModelCompositeModelType: undefined,
    assetModelId: undefined,
    compositionDetails: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.actionDefinitions !== undefined && data.actionDefinitions !== null) {
    contents.actionDefinitions = deserializeAws_restJson1ActionDefinitions(data.actionDefinitions, context);
  }
  if (data.assetModelCompositeModelDescription !== undefined && data.assetModelCompositeModelDescription !== null) {
    contents.assetModelCompositeModelDescription = __expectString(data.assetModelCompositeModelDescription);
  }
  if (data.assetModelCompositeModelExternalId !== undefined && data.assetModelCompositeModelExternalId !== null) {
    contents.assetModelCompositeModelExternalId = __expectString(data.assetModelCompositeModelExternalId);
  }
  if (data.assetModelCompositeModelId !== undefined && data.assetModelCompositeModelId !== null) {
    contents.assetModelCompositeModelId = __expectString(data.assetModelCompositeModelId);
  }
  if (data.assetModelCompositeModelName !== undefined && data.assetModelCompositeModelName !== null) {
    contents.assetModelCompositeModelName = __expectString(data.assetModelCompositeModelName);
  }
  if (data.assetModelCompositeModelPath !== undefined && data.assetModelCompositeModelPath !== null) {
    contents.assetModelCompositeModelPath = deserializeAws_restJson1AssetModelCompositeModelPath(data.assetModelCompositeModelPath, context);
  }
  if (data.assetModelCompositeModelProperties !== undefined && data.assetModelCompositeModelProperties !== null) {
    contents.assetModelCompositeModelProperties = deserializeAws_restJson1AssetModelProperties(data.assetModelCompositeModelProperties, context);
  }
  if (data.assetModelCompositeModelSummaries !== undefined && data.assetModelCompositeModelSummaries !== null) {
    contents.assetModelCompositeModelSummaries = deserializeAws_restJson1AssetModelCompositeModelSummaries(data.assetModelCompositeModelSummaries, context);
  }
  if (data.assetModelCompositeModelType !== undefined && data.assetModelCompositeModelType !== null) {
    contents.assetModelCompositeModelType = __expectString(data.assetModelCompositeModelType);
  }
  if (data.assetModelId !== undefined && data.assetModelId !== null) {
    contents.assetModelId = __expectString(data.assetModelId);
  }
  if (data.compositionDetails !== undefined && data.compositionDetails !== null) {
    contents.compositionDetails = deserializeAws_restJson1CompositionDetails(data.compositionDetails, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAssetModelCompositeModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAssetModelCompositeModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAssetPropertyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAssetPropertyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAssetPropertyCommandError(output, context);
  }
  const contents: DescribeAssetPropertyCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetExternalId: undefined,
    assetId: undefined,
    assetModelId: undefined,
    assetName: undefined,
    assetProperty: undefined,
    compositeModel: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetExternalId !== undefined && data.assetExternalId !== null) {
    contents.assetExternalId = __expectString(data.assetExternalId);
  }
  if (data.assetId !== undefined && data.assetId !== null) {
    contents.assetId = __expectString(data.assetId);
  }
  if (data.assetModelId !== undefined && data.assetModelId !== null) {
    contents.assetModelId = __expectString(data.assetModelId);
  }
  if (data.assetName !== undefined && data.assetName !== null) {
    contents.assetName = __expectString(data.assetName);
  }
  if (data.assetProperty !== undefined && data.assetProperty !== null) {
    contents.assetProperty = deserializeAws_restJson1Property(data.assetProperty, context);
  }
  if (data.compositeModel !== undefined && data.compositeModel !== null) {
    contents.compositeModel = deserializeAws_restJson1CompositeModelProperty(data.compositeModel, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAssetPropertyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAssetPropertyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeLoggingOptionsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeLoggingOptionsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeLoggingOptionsCommandError(output, context);
  }
  const contents: DescribeLoggingOptionsCommandOutput = {
    $metadata: deserializeMetadata(output),
    loggingOptions: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.loggingOptions !== undefined && data.loggingOptions !== null) {
    contents.loggingOptions = deserializeAws_restJson1LoggingOptions(data.loggingOptions, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeLoggingOptionsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeLoggingOptionsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeTimeSeriesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeTimeSeriesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeTimeSeriesCommandError(output, context);
  }
  const contents: DescribeTimeSeriesCommandOutput = {
    $metadata: deserializeMetadata(output),
    alias: undefined,
    assetId: undefined,
    dataType: undefined,
    dataTypeSpec: undefined,
    propertyId: undefined,
    timeSeriesArn: undefined,
    timeSeriesCreationDate: undefined,
    timeSeriesId: undefined,
    timeSeriesLastUpdateDate: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.alias !== undefined && data.alias !== null) {
    contents.alias = __expectString(data.alias);
  }
  if (data.assetId !== undefined && data.assetId !== null) {
    contents.assetId = __expectString(data.assetId);
  }
  if (data.dataType !== undefined && data.dataType !== null) {
    contents.dataType = __expectString(data.dataType);
  }
  if (data.dataTypeSpec !== undefined && data.dataTypeSpec !== null) {
    contents.dataTypeSpec = __expectString(data.dataTypeSpec);
  }
  if (data.propertyId !== undefined && data.propertyId !== null) {
    contents.propertyId = __expectString(data.propertyId);
  }
  if (data.timeSeriesArn !== undefined && data.timeSeriesArn !== null) {
    contents.timeSeriesArn = __expectString(data.timeSeriesArn);
  }
  if (data.timeSeriesCreationDate !== undefined && data.timeSeriesCreationDate !== null) {
    contents.timeSeriesCreationDate = new Date(Math.round(data.timeSeriesCreationDate * 1000));
  }
  if (data.timeSeriesId !== undefined && data.timeSeriesId !== null) {
    contents.timeSeriesId = __expectString(data.timeSeriesId);
  }
  if (data.timeSeriesLastUpdateDate !== undefined && data.timeSeriesLastUpdateDate !== null) {
    contents.timeSeriesLastUpdateDate = new Date(Math.round(data.timeSeriesLastUpdateDate * 1000));
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeTimeSeriesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeTimeSeriesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DisassociateAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DisassociateAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DisassociateAssetsCommandError(output, context);
  }
  const contents: DisassociateAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DisassociateAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DisassociateAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DisassociateTimeSeriesFromAssetPropertyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DisassociateTimeSeriesFromAssetPropertyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DisassociateTimeSeriesFromAssetPropertyCommandError(output, context);
  }
  const contents: DisassociateTimeSeriesFromAssetPropertyCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DisassociateTimeSeriesFromAssetPropertyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DisassociateTimeSeriesFromAssetPropertyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ExecuteActionCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ExecuteActionCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1ExecuteActionCommandError(output, context);
  }
  const contents: ExecuteActionCommandOutput = {
    $metadata: deserializeMetadata(output),
    actionId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.actionId !== undefined && data.actionId !== null) {
    contents.actionId = __expectString(data.actionId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ExecuteActionCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ExecuteActionCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListActionsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListActionsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListActionsCommandError(output, context);
  }
  const contents: ListActionsCommandOutput = {
    $metadata: deserializeMetadata(output),
    actionSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.actionSummaries !== undefined && data.actionSummaries !== null) {
    contents.actionSummaries = deserializeAws_restJson1ActionSummaries(data.actionSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListActionsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListActionsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetModelCompositeModelsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetModelCompositeModelsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetModelCompositeModelsCommandError(output, context);
  }
  const contents: ListAssetModelCompositeModelsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelCompositeModelSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelCompositeModelSummaries !== undefined && data.assetModelCompositeModelSummaries !== null) {
    contents.assetModelCompositeModelSummaries = deserializeAws_restJson1AssetModelCompositeModelSummaries(data.assetModelCompositeModelSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetModelCompositeModelsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetModelCompositeModelsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetModelPropertiesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetModelPropertiesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetModelPropertiesCommandError(output, context);
  }
  const contents: ListAssetModelPropertiesCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelPropertySummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelPropertySummaries !== undefined && data.assetModelPropertySummaries !== null) {
    contents.assetModelPropertySummaries = deserializeAws_restJson1AssetModelPropertySummaries(data.assetModelPropertySummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetModelPropertiesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetModelPropertiesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetModelsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetModelsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetModelsCommandError(output, context);
  }
  const contents: ListAssetModelsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelSummaries !== undefined && data.assetModelSummaries !== null) {
    contents.assetModelSummaries = deserializeAws_restJson1AssetModelSummaries(data.assetModelSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetModelsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetModelsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetPropertiesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetPropertiesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetPropertiesCommandError(output, context);
  }
  const contents: ListAssetPropertiesCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetPropertySummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetPropertySummaries !== undefined && data.assetPropertySummaries !== null) {
    contents.assetPropertySummaries = deserializeAws_restJson1AssetPropertySummaries(data.assetPropertySummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetPropertiesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetPropertiesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetRelationshipsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetRelationshipsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetRelationshipsCommandError(output, context);
  }
  const contents: ListAssetRelationshipsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetRelationshipSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetRelationshipSummaries !== undefined && data.assetRelationshipSummaries !== null) {
    contents.assetRelationshipSummaries = deserializeAws_restJson1AssetRelationshipSummaries(data.assetRelationshipSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetRelationshipsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetRelationshipsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssetsCommandError(output, context);
  }
  const contents: ListAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetSummaries !== undefined && data.assetSummaries !== null) {
    contents.assetSummaries = deserializeAws_restJson1AssetSummaries(data.assetSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAssociatedAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAssociatedAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAssociatedAssetsCommandError(output, context);
  }
  const contents: ListAssociatedAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetSummaries !== undefined && data.assetSummaries !== null) {
    contents.assetSummaries = deserializeAws_restJson1AssociatedAssetsSummaries(data.assetSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAssociatedAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAssociatedAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListCompositionRelationshipsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListCompositionRelationshipsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListCompositionRelationshipsCommandError(output, context);
  }
  const contents: ListCompositionRelationshipsCommandOutput = {
    $metadata: deserializeMetadata(output),
    compositionRelationshipSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.compositionRelationshipSummaries !== undefined && data.compositionRelationshipSummaries !== null) {
    contents.compositionRelationshipSummaries = deserializeAws_restJson1CompositionRelationshipSummaries(data.compositionRelationshipSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListCompositionRelationshipsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListCompositionRelationshipsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListTimeSeriesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListTimeSeriesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListTimeSeriesCommandError(output, context);
  }
  const contents: ListTimeSeriesCommandOutput = {
    $metadata: deserializeMetadata(output),
    TimeSeriesSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.TimeSeriesSummaries !== undefined && data.TimeSeriesSummaries !== null) {
    contents.TimeSeriesSummaries = deserializeAws_restJson1TimeSeriesSummaries(data.TimeSeriesSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListTimeSeriesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListTimeSeriesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1PutLoggingOptionsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<PutLoggingOptionsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1PutLoggingOptionsCommandError(output, context);
  }
  const contents: PutLoggingOptionsCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1PutLoggingOptionsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<PutLoggingOptionsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateAssetCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateAssetCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateAssetCommandError(output, context);
  }
  const contents: UpdateAssetCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetStatus !== undefined && data.assetStatus !== null) {
    contents.assetStatus = deserializeAws_restJson1AssetStatus(data.assetStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateAssetCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateAssetCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateAssetModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateAssetModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateAssetModelCommandError(output, context);
  }
  const contents: UpdateAssetModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateAssetModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateAssetModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "PreconditionFailedException":
    case "com.amazon.iot.bifrost.exceptions#PreconditionFailedException":
      response = {
        ...await deserializeAws_restJson1PreconditionFailedExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateAssetModelCompositeModelCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateAssetModelCompositeModelCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateAssetModelCompositeModelCommandError(output, context);
  }
  const contents: UpdateAssetModelCompositeModelCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetModelCompositeModelPath: undefined,
    assetModelStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetModelCompositeModelPath !== undefined && data.assetModelCompositeModelPath !== null) {
    contents.assetModelCompositeModelPath = deserializeAws_restJson1AssetModelCompositeModelPath(data.assetModelCompositeModelPath, context);
  }
  if (data.assetModelStatus !== undefined && data.assetModelStatus !== null) {
    contents.assetModelStatus = deserializeAws_restJson1AssetModelStatus(data.assetModelStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateAssetModelCompositeModelCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateAssetModelCompositeModelCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "PreconditionFailedException":
    case "com.amazon.iot.bifrost.exceptions#PreconditionFailedException":
      response = {
        ...await deserializeAws_restJson1PreconditionFailedExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceAlreadyExistsException":
    case "com.amazon.iot.bifrost.exceptions#ResourceAlreadyExistsException":
      response = {
        ...await deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateAssetPropertyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateAssetPropertyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateAssetPropertyCommandError(output, context);
  }
  const contents: UpdateAssetPropertyCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateAssetPropertyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateAssetPropertyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1BatchAssociateProjectAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<BatchAssociateProjectAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1BatchAssociateProjectAssetsCommandError(output, context);
  }
  const contents: BatchAssociateProjectAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
    errors: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.errors !== undefined && data.errors !== null) {
    contents.errors = deserializeAws_restJson1BatchAssociateProjectAssetsErrors(data.errors, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1BatchAssociateProjectAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<BatchAssociateProjectAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1BatchDisassociateProjectAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<BatchDisassociateProjectAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1BatchDisassociateProjectAssetsCommandError(output, context);
  }
  const contents: BatchDisassociateProjectAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
    errors: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.errors !== undefined && data.errors !== null) {
    contents.errors = deserializeAws_restJson1BatchDisassociateProjectAssetsErrors(data.errors, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1BatchDisassociateProjectAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<BatchDisassociateProjectAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateAccessPolicyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateAccessPolicyCommandOutput> => {
  if (output.statusCode !== 201 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateAccessPolicyCommandError(output, context);
  }
  const contents: CreateAccessPolicyCommandOutput = {
    $metadata: deserializeMetadata(output),
    accessPolicyArn: undefined,
    accessPolicyId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.accessPolicyArn !== undefined && data.accessPolicyArn !== null) {
    contents.accessPolicyArn = __expectString(data.accessPolicyArn);
  }
  if (data.accessPolicyId !== undefined && data.accessPolicyId !== null) {
    contents.accessPolicyId = __expectString(data.accessPolicyId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateAccessPolicyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateAccessPolicyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateDashboardCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateDashboardCommandOutput> => {
  if (output.statusCode !== 201 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateDashboardCommandError(output, context);
  }
  const contents: CreateDashboardCommandOutput = {
    $metadata: deserializeMetadata(output),
    dashboardArn: undefined,
    dashboardId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.dashboardArn !== undefined && data.dashboardArn !== null) {
    contents.dashboardArn = __expectString(data.dashboardArn);
  }
  if (data.dashboardId !== undefined && data.dashboardId !== null) {
    contents.dashboardId = __expectString(data.dashboardId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateDashboardCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateDashboardCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreatePortalCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreatePortalCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreatePortalCommandError(output, context);
  }
  const contents: CreatePortalCommandOutput = {
    $metadata: deserializeMetadata(output),
    portalArn: undefined,
    portalId: undefined,
    portalStartUrl: undefined,
    portalStatus: undefined,
    ssoApplicationId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.portalArn !== undefined && data.portalArn !== null) {
    contents.portalArn = __expectString(data.portalArn);
  }
  if (data.portalId !== undefined && data.portalId !== null) {
    contents.portalId = __expectString(data.portalId);
  }
  if (data.portalStartUrl !== undefined && data.portalStartUrl !== null) {
    contents.portalStartUrl = __expectString(data.portalStartUrl);
  }
  if (data.portalStatus !== undefined && data.portalStatus !== null) {
    contents.portalStatus = deserializeAws_restJson1PortalStatus(data.portalStatus, context);
  }
  if (data.ssoApplicationId !== undefined && data.ssoApplicationId !== null) {
    contents.ssoApplicationId = __expectString(data.ssoApplicationId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreatePortalCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreatePortalCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1CreateProjectCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<CreateProjectCommandOutput> => {
  if (output.statusCode !== 201 && output.statusCode >= 300) {
    return deserializeAws_restJson1CreateProjectCommandError(output, context);
  }
  const contents: CreateProjectCommandOutput = {
    $metadata: deserializeMetadata(output),
    projectArn: undefined,
    projectId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.projectArn !== undefined && data.projectArn !== null) {
    contents.projectArn = __expectString(data.projectArn);
  }
  if (data.projectId !== undefined && data.projectId !== null) {
    contents.projectId = __expectString(data.projectId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1CreateProjectCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<CreateProjectCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "LimitExceededException":
    case "com.amazon.iot.bifrost.exceptions#LimitExceededException":
      response = {
        ...await deserializeAws_restJson1LimitExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteAccessPolicyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteAccessPolicyCommandOutput> => {
  if (output.statusCode !== 204 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteAccessPolicyCommandError(output, context);
  }
  const contents: DeleteAccessPolicyCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteAccessPolicyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteAccessPolicyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteDashboardCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteDashboardCommandOutput> => {
  if (output.statusCode !== 204 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteDashboardCommandError(output, context);
  }
  const contents: DeleteDashboardCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteDashboardCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteDashboardCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeletePortalCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeletePortalCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeletePortalCommandError(output, context);
  }
  const contents: DeletePortalCommandOutput = {
    $metadata: deserializeMetadata(output),
    portalStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.portalStatus !== undefined && data.portalStatus !== null) {
    contents.portalStatus = deserializeAws_restJson1PortalStatus(data.portalStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeletePortalCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeletePortalCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DeleteProjectCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DeleteProjectCommandOutput> => {
  if (output.statusCode !== 204 && output.statusCode >= 300) {
    return deserializeAws_restJson1DeleteProjectCommandError(output, context);
  }
  const contents: DeleteProjectCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DeleteProjectCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DeleteProjectCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeAccessPolicyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeAccessPolicyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeAccessPolicyCommandError(output, context);
  }
  const contents: DescribeAccessPolicyCommandOutput = {
    $metadata: deserializeMetadata(output),
    accessPolicyArn: undefined,
    accessPolicyCreationDate: undefined,
    accessPolicyId: undefined,
    accessPolicyIdentity: undefined,
    accessPolicyLastUpdateDate: undefined,
    accessPolicyPermission: undefined,
    accessPolicyResource: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.accessPolicyArn !== undefined && data.accessPolicyArn !== null) {
    contents.accessPolicyArn = __expectString(data.accessPolicyArn);
  }
  if (data.accessPolicyCreationDate !== undefined && data.accessPolicyCreationDate !== null) {
    contents.accessPolicyCreationDate = new Date(Math.round(data.accessPolicyCreationDate * 1000));
  }
  if (data.accessPolicyId !== undefined && data.accessPolicyId !== null) {
    contents.accessPolicyId = __expectString(data.accessPolicyId);
  }
  if (data.accessPolicyIdentity !== undefined && data.accessPolicyIdentity !== null) {
    contents.accessPolicyIdentity = deserializeAws_restJson1Identity(data.accessPolicyIdentity, context);
  }
  if (data.accessPolicyLastUpdateDate !== undefined && data.accessPolicyLastUpdateDate !== null) {
    contents.accessPolicyLastUpdateDate = new Date(Math.round(data.accessPolicyLastUpdateDate * 1000));
  }
  if (data.accessPolicyPermission !== undefined && data.accessPolicyPermission !== null) {
    contents.accessPolicyPermission = __expectString(data.accessPolicyPermission);
  }
  if (data.accessPolicyResource !== undefined && data.accessPolicyResource !== null) {
    contents.accessPolicyResource = deserializeAws_restJson1Resource(data.accessPolicyResource, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeAccessPolicyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeAccessPolicyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeDashboardCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeDashboardCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeDashboardCommandError(output, context);
  }
  const contents: DescribeDashboardCommandOutput = {
    $metadata: deserializeMetadata(output),
    dashboardArn: undefined,
    dashboardCreationDate: undefined,
    dashboardDefinition: undefined,
    dashboardDescription: undefined,
    dashboardId: undefined,
    dashboardLastUpdateDate: undefined,
    dashboardName: undefined,
    projectId: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.dashboardArn !== undefined && data.dashboardArn !== null) {
    contents.dashboardArn = __expectString(data.dashboardArn);
  }
  if (data.dashboardCreationDate !== undefined && data.dashboardCreationDate !== null) {
    contents.dashboardCreationDate = new Date(Math.round(data.dashboardCreationDate * 1000));
  }
  if (data.dashboardDefinition !== undefined && data.dashboardDefinition !== null) {
    contents.dashboardDefinition = __expectString(data.dashboardDefinition);
  }
  if (data.dashboardDescription !== undefined && data.dashboardDescription !== null) {
    contents.dashboardDescription = __expectString(data.dashboardDescription);
  }
  if (data.dashboardId !== undefined && data.dashboardId !== null) {
    contents.dashboardId = __expectString(data.dashboardId);
  }
  if (data.dashboardLastUpdateDate !== undefined && data.dashboardLastUpdateDate !== null) {
    contents.dashboardLastUpdateDate = new Date(Math.round(data.dashboardLastUpdateDate * 1000));
  }
  if (data.dashboardName !== undefined && data.dashboardName !== null) {
    contents.dashboardName = __expectString(data.dashboardName);
  }
  if (data.projectId !== undefined && data.projectId !== null) {
    contents.projectId = __expectString(data.projectId);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeDashboardCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeDashboardCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribePortalCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribePortalCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribePortalCommandError(output, context);
  }
  const contents: DescribePortalCommandOutput = {
    $metadata: deserializeMetadata(output),
    alarms: undefined,
    edgeConfig: undefined,
    notificationSenderEmail: undefined,
    portalArn: undefined,
    portalAuthMode: undefined,
    portalClientId: undefined,
    portalContactEmail: undefined,
    portalCreationDate: undefined,
    portalDescription: undefined,
    portalId: undefined,
    portalLastUpdateDate: undefined,
    portalLogoImageLocation: undefined,
    portalName: undefined,
    portalStartUrl: undefined,
    portalStatus: undefined,
    projectPublicSharing: undefined,
    roleArn: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.alarms !== undefined && data.alarms !== null) {
    contents.alarms = deserializeAws_restJson1Alarms(data.alarms, context);
  }
  if (data.edgeConfig !== undefined && data.edgeConfig !== null) {
    contents.edgeConfig = deserializeAws_restJson1PortalEdgeConfig(data.edgeConfig, context);
  }
  if (data.notificationSenderEmail !== undefined && data.notificationSenderEmail !== null) {
    contents.notificationSenderEmail = __expectString(data.notificationSenderEmail);
  }
  if (data.portalArn !== undefined && data.portalArn !== null) {
    contents.portalArn = __expectString(data.portalArn);
  }
  if (data.portalAuthMode !== undefined && data.portalAuthMode !== null) {
    contents.portalAuthMode = __expectString(data.portalAuthMode);
  }
  if (data.portalClientId !== undefined && data.portalClientId !== null) {
    contents.portalClientId = __expectString(data.portalClientId);
  }
  if (data.portalContactEmail !== undefined && data.portalContactEmail !== null) {
    contents.portalContactEmail = __expectString(data.portalContactEmail);
  }
  if (data.portalCreationDate !== undefined && data.portalCreationDate !== null) {
    contents.portalCreationDate = new Date(Math.round(data.portalCreationDate * 1000));
  }
  if (data.portalDescription !== undefined && data.portalDescription !== null) {
    contents.portalDescription = __expectString(data.portalDescription);
  }
  if (data.portalId !== undefined && data.portalId !== null) {
    contents.portalId = __expectString(data.portalId);
  }
  if (data.portalLastUpdateDate !== undefined && data.portalLastUpdateDate !== null) {
    contents.portalLastUpdateDate = new Date(Math.round(data.portalLastUpdateDate * 1000));
  }
  if (data.portalLogoImageLocation !== undefined && data.portalLogoImageLocation !== null) {
    contents.portalLogoImageLocation = deserializeAws_restJson1ImageLocation(data.portalLogoImageLocation, context);
  }
  if (data.portalName !== undefined && data.portalName !== null) {
    contents.portalName = __expectString(data.portalName);
  }
  if (data.portalStartUrl !== undefined && data.portalStartUrl !== null) {
    contents.portalStartUrl = __expectString(data.portalStartUrl);
  }
  if (data.portalStatus !== undefined && data.portalStatus !== null) {
    contents.portalStatus = deserializeAws_restJson1PortalStatus(data.portalStatus, context);
  }
  if (data.projectPublicSharing !== undefined && data.projectPublicSharing !== null) {
    contents.projectPublicSharing = __expectString(data.projectPublicSharing);
  }
  if (data.roleArn !== undefined && data.roleArn !== null) {
    contents.roleArn = __expectString(data.roleArn);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribePortalCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribePortalCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1DescribeProjectCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<DescribeProjectCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1DescribeProjectCommandError(output, context);
  }
  const contents: DescribeProjectCommandOutput = {
    $metadata: deserializeMetadata(output),
    portalId: undefined,
    projectArn: undefined,
    projectCreationDate: undefined,
    projectDescription: undefined,
    projectId: undefined,
    projectLastUpdateDate: undefined,
    projectName: undefined,
    projectSharing: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.portalId !== undefined && data.portalId !== null) {
    contents.portalId = __expectString(data.portalId);
  }
  if (data.projectArn !== undefined && data.projectArn !== null) {
    contents.projectArn = __expectString(data.projectArn);
  }
  if (data.projectCreationDate !== undefined && data.projectCreationDate !== null) {
    contents.projectCreationDate = new Date(Math.round(data.projectCreationDate * 1000));
  }
  if (data.projectDescription !== undefined && data.projectDescription !== null) {
    contents.projectDescription = __expectString(data.projectDescription);
  }
  if (data.projectId !== undefined && data.projectId !== null) {
    contents.projectId = __expectString(data.projectId);
  }
  if (data.projectLastUpdateDate !== undefined && data.projectLastUpdateDate !== null) {
    contents.projectLastUpdateDate = new Date(Math.round(data.projectLastUpdateDate * 1000));
  }
  if (data.projectName !== undefined && data.projectName !== null) {
    contents.projectName = __expectString(data.projectName);
  }
  if (data.projectSharing !== undefined && data.projectSharing !== null) {
    contents.projectSharing = deserializeAws_restJson1ProjectSharing(data.projectSharing, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1DescribeProjectCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<DescribeProjectCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListAccessPoliciesCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListAccessPoliciesCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListAccessPoliciesCommandError(output, context);
  }
  const contents: ListAccessPoliciesCommandOutput = {
    $metadata: deserializeMetadata(output),
    accessPolicySummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.accessPolicySummaries !== undefined && data.accessPolicySummaries !== null) {
    contents.accessPolicySummaries = deserializeAws_restJson1AccessPolicySummaries(data.accessPolicySummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListAccessPoliciesCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListAccessPoliciesCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListDashboardsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListDashboardsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListDashboardsCommandError(output, context);
  }
  const contents: ListDashboardsCommandOutput = {
    $metadata: deserializeMetadata(output),
    dashboardSummaries: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.dashboardSummaries !== undefined && data.dashboardSummaries !== null) {
    contents.dashboardSummaries = deserializeAws_restJson1DashboardSummaries(data.dashboardSummaries, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListDashboardsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListDashboardsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListPortalsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListPortalsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListPortalsCommandError(output, context);
  }
  const contents: ListPortalsCommandOutput = {
    $metadata: deserializeMetadata(output),
    nextToken: undefined,
    portalSummaries: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  if (data.portalSummaries !== undefined && data.portalSummaries !== null) {
    contents.portalSummaries = deserializeAws_restJson1PortalSummaries(data.portalSummaries, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListPortalsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListPortalsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListProjectAssetsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListProjectAssetsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListProjectAssetsCommandError(output, context);
  }
  const contents: ListProjectAssetsCommandOutput = {
    $metadata: deserializeMetadata(output),
    assetIds: undefined,
    nextToken: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.assetIds !== undefined && data.assetIds !== null) {
    contents.assetIds = deserializeAws_restJson1AssetIDs(data.assetIds, context);
  }
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListProjectAssetsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListProjectAssetsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1ListProjectsCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<ListProjectsCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1ListProjectsCommandError(output, context);
  }
  const contents: ListProjectsCommandOutput = {
    $metadata: deserializeMetadata(output),
    nextToken: undefined,
    projectSummaries: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.nextToken !== undefined && data.nextToken !== null) {
    contents.nextToken = __expectString(data.nextToken);
  }
  if (data.projectSummaries !== undefined && data.projectSummaries !== null) {
    contents.projectSummaries = deserializeAws_restJson1ProjectSummaries(data.projectSummaries, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1ListProjectsCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<ListProjectsCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateAccessPolicyCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateAccessPolicyCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateAccessPolicyCommandError(output, context);
  }
  const contents: UpdateAccessPolicyCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateAccessPolicyCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateAccessPolicyCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateDashboardCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateDashboardCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateDashboardCommandError(output, context);
  }
  const contents: UpdateDashboardCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateDashboardCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateDashboardCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdatePortalCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdatePortalCommandOutput> => {
  if (output.statusCode !== 202 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdatePortalCommandError(output, context);
  }
  const contents: UpdatePortalCommandOutput = {
    $metadata: deserializeMetadata(output),
    portalStatus: undefined,
  };
  const data: { [key: string] : any } = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
  if (data.portalStatus !== undefined && data.portalStatus !== null) {
    contents.portalStatus = deserializeAws_restJson1PortalStatus(data.portalStatus, context);
  }
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdatePortalCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdatePortalCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "ConflictingOperationException":
    case "com.amazon.iot.bifrost.exceptions#ConflictingOperationException":
      response = {
        ...await deserializeAws_restJson1ConflictingOperationExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1UpdateProjectCommand = async(
  output: __HttpResponse,
  context: __SerdeContext
): Promise<UpdateProjectCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1UpdateProjectCommandError(output, context);
  }
  const contents: UpdateProjectCommandOutput = {
    $metadata: deserializeMetadata(output),
  };
  await collectBody(output.body, context);
  return Promise.resolve(contents);
}

const deserializeAws_restJson1UpdateProjectCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<UpdateProjectCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "InternalFailureException":
    case "com.amazon.iot.bifrost.exceptions#InternalFailureException":
      response = {
        ...await deserializeAws_restJson1InternalFailureExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InvalidRequestException":
    case "com.amazon.iot.bifrost.exceptions#InvalidRequestException":
      response = {
        ...await deserializeAws_restJson1InvalidRequestExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ResourceNotFoundException":
    case "com.amazon.iot.bifrost.exceptions#ResourceNotFoundException":
      response = {
        ...await deserializeAws_restJson1ResourceNotFoundExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ThrottlingException":
    case "com.amazon.iot.bifrost.exceptions#ThrottlingException":
      response = {
        ...await deserializeAws_restJson1ThrottlingExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

export const deserializeAws_restJson1InvokeAssistantCommand = async(
  output: __HttpResponse,
  context: __SerdeContext & __EventStreamSerdeContext
): Promise<InvokeAssistantCommandOutput> => {
  if (output.statusCode !== 200 && output.statusCode >= 300) {
    return deserializeAws_restJson1InvokeAssistantCommandError(output, context);
  }
  const contents: InvokeAssistantCommandOutput = {
    $metadata: deserializeMetadata(output),
    body: undefined,
    conversationId: undefined,
  };
  if (output.headers["x-amz-iotsitewise-assistant-conversation-id"] !== undefined) {
    contents.conversationId = output.headers['x-amz-iotsitewise-assistant-conversation-id'];
  }
  const data: any = context.eventStreamMarshaller.deserialize(
    output.body,
    async event => {
      const eventName = Object.keys(event)[0];
      const eventHeaders = Object.entries(event[eventName].headers).reduce(
        (accummulator, curr) => {accummulator[curr[0]] = curr[1].value; return accummulator; },
        {} as {[key: string]: any}
      );
      const eventMessage = {
        headers: eventHeaders,
        body: event[eventName].body
      };
      const parsedEvent = {
        [eventName]: eventMessage
      };
      return await deserializeAws_restJson1ResponseStream_event(parsedEvent, context);
    }
  );
  contents.body = data;
  return Promise.resolve(contents);
}

const deserializeAws_restJson1InvokeAssistantCommandError = async(
  output: __HttpResponse,
  context: __SerdeContext,
): Promise<InvokeAssistantCommandOutput> => {
  const parsedOutput: any = {
    ...output,
    body: await parseBody(output.body, context)
  };
  let response: __SmithyException & __MetadataBearer & {[key: string]: any};
  let errorCode: string = "UnknownError";
  errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
  switch (errorCode) {
    case "BadGatewayException":
    case "com.amazon.iotsophonruntimeservice#BadGatewayException":
      response = {
        ...await deserializeAws_restJson1BadGatewayExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ConflictException":
    case "com.amazon.iotsophonruntimeservice#ConflictException":
      response = {
        ...await deserializeAws_restJson1ConflictExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "InternalServerException":
    case "com.amazon.iotsophonruntimeservice#InternalServerException":
      response = {
        ...await deserializeAws_restJson1InternalServerExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    case "ServiceQuotaExceededException":
    case "com.amazon.iotsophonruntimeservice#ServiceQuotaExceededException":
      response = {
        ...await deserializeAws_restJson1ServiceQuotaExceededExceptionResponse(parsedOutput, context),
        name: errorCode,
        $metadata: deserializeMetadata(output),
      }
      break;
    default:
      const parsedBody = parsedOutput.body;
      errorCode = parsedBody.code || parsedBody.Code || errorCode;
      response = {
        ...parsedBody,
        name: `${errorCode}`,
        message: parsedBody.message || parsedBody.Message || errorCode,
        $fault: "client",
        $metadata: deserializeMetadata(output)
      } as any;
  }
  const message = response.message || response.Message || errorCode;
  response.message = message;
  delete response.Message;
  return Promise.reject(Object.assign(new Error(message), response));
}

const deserializeAws_restJson1ResponseStream_event = async (
  output: any,
  context: __SerdeContext
): Promise<ResponseStream> => {
  if (output["step"] !== undefined) {
    return {
      step: await deserializeAws_restJson1InvokeAssistantStep_event(output["step"], context)
    };
  }
  if (output["finalResponse"] !== undefined) {
    return {
      finalResponse: await deserializeAws_restJson1FinalResponse_event(output["finalResponse"], context)
    };
  }
  return {$unknown: output};
}
const deserializeAws_restJson1FinalResponse_event = async (
  output: any,
  context: __SerdeContext
): Promise<FinalResponse> => {
  let contents: FinalResponse = {} as any;
  const data: any = await parseBody(output.body, context);
  contents = {
    ...contents,
    ...deserializeAws_restJson1FinalResponse(data, context)
  } as any;
  return contents;
}
const deserializeAws_restJson1InvokeAssistantStep_event = async (
  output: any,
  context: __SerdeContext
): Promise<InvokeAssistantStep> => {
  let contents: InvokeAssistantStep = {} as any;
  const data: any = await parseBody(output.body, context);
  contents = {
    ...contents,
    ...deserializeAws_restJson1InvokeAssistantStep(data, context)
  } as any;
  return contents;
}
const deserializeAws_restJson1ConflictingOperationExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ConflictingOperationException> => {
  const contents: ConflictingOperationException = {
    name: "ConflictingOperationException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
    resourceArn: undefined,
    resourceId: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  if (data.resourceArn !== undefined && data.resourceArn !== null) {
    contents.resourceArn = __expectString(data.resourceArn);
  }
  if (data.resourceId !== undefined && data.resourceId !== null) {
    contents.resourceId = __expectString(data.resourceId);
  }
  return contents;
};

const deserializeAws_restJson1InternalFailureExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<InternalFailureException> => {
  const contents: InternalFailureException = {
    name: "InternalFailureException",
    $fault: "server",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1InvalidRequestExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<InvalidRequestException> => {
  const contents: InvalidRequestException = {
    name: "InvalidRequestException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1LimitExceededExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<LimitExceededException> => {
  const contents: LimitExceededException = {
    name: "LimitExceededException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1PreconditionFailedExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<PreconditionFailedException> => {
  const contents: PreconditionFailedException = {
    name: "PreconditionFailedException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
    resourceArn: undefined,
    resourceId: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  if (data.resourceArn !== undefined && data.resourceArn !== null) {
    contents.resourceArn = __expectString(data.resourceArn);
  }
  if (data.resourceId !== undefined && data.resourceId !== null) {
    contents.resourceId = __expectString(data.resourceId);
  }
  return contents;
};

const deserializeAws_restJson1ResourceAlreadyExistsExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ResourceAlreadyExistsException> => {
  const contents: ResourceAlreadyExistsException = {
    name: "ResourceAlreadyExistsException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
    resourceArn: undefined,
    resourceId: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  if (data.resourceArn !== undefined && data.resourceArn !== null) {
    contents.resourceArn = __expectString(data.resourceArn);
  }
  if (data.resourceId !== undefined && data.resourceId !== null) {
    contents.resourceId = __expectString(data.resourceId);
  }
  return contents;
};

const deserializeAws_restJson1ResourceNotFoundExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ResourceNotFoundException> => {
  const contents: ResourceNotFoundException = {
    name: "ResourceNotFoundException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1ThrottlingExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ThrottlingException> => {
  const contents: ThrottlingException = {
    name: "ThrottlingException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1BadGatewayExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<BadGatewayException> => {
  const contents: BadGatewayException = {
    name: "BadGatewayException",
    $fault: "server",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1ConflictExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ConflictException> => {
  const contents: ConflictException = {
    name: "ConflictException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1InternalServerExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<InternalServerException> => {
  const contents: InternalServerException = {
    name: "InternalServerException",
    $fault: "server",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const deserializeAws_restJson1ServiceQuotaExceededExceptionResponse = async (
  parsedOutput: any,
  context: __SerdeContext
): Promise<ServiceQuotaExceededException> => {
  const contents: ServiceQuotaExceededException = {
    name: "ServiceQuotaExceededException",
    $fault: "client",
    $metadata: deserializeMetadata(parsedOutput),
    message: undefined,
  };
  const data: any = parsedOutput.body;
  if (data.message !== undefined && data.message !== null) {
    contents.message = __expectString(data.message);
  }
  return contents;
};

const serializeAws_restJson1GatewayPlatform = (
  input: GatewayPlatform,
  context: __SerdeContext
): any => {
  return {
    ...(input.greengrass !== undefined && input.greengrass !== null && { "greengrass": serializeAws_restJson1Greengrass(input.greengrass, context) }),
    ...(input.greengrassV2 !== undefined && input.greengrassV2 !== null && { "greengrassV2": serializeAws_restJson1GreengrassV2(input.greengrassV2, context) }),
  };
}

const serializeAws_restJson1Greengrass = (
  input: Greengrass,
  context: __SerdeContext
): any => {
  return {
    ...(input.groupArn !== undefined && input.groupArn !== null && { "groupArn": input.groupArn }),
  };
}

const serializeAws_restJson1GreengrassV2 = (
  input: GreengrassV2,
  context: __SerdeContext
): any => {
  return {
    ...(input.coreDeviceThingName !== undefined && input.coreDeviceThingName !== null && { "coreDeviceThingName": input.coreDeviceThingName }),
  };
}

const serializeAws_restJson1ActionPayload = (
  input: ActionPayload,
  context: __SerdeContext
): any => {
  return {
    ...(input.stringValue !== undefined && input.stringValue !== null && { "stringValue": input.stringValue }),
  };
}

const serializeAws_restJson1AssetModelCompositeModel = (
  input: AssetModelCompositeModel,
  context: __SerdeContext
): any => {
  return {
    ...(input.description !== undefined && input.description !== null && { "description": input.description }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
    ...(input.properties !== undefined && input.properties !== null && { "properties": serializeAws_restJson1AssetModelProperties(input.properties, context) }),
    ...(input.type !== undefined && input.type !== null && { "type": input.type }),
  };
}

const serializeAws_restJson1AssetModelCompositeModelDefinition = (
  input: AssetModelCompositeModelDefinition,
  context: __SerdeContext
): any => {
  return {
    ...(input.description !== undefined && input.description !== null && { "description": input.description }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
    ...(input.properties !== undefined && input.properties !== null && { "properties": serializeAws_restJson1AssetModelPropertyDefinitions(input.properties, context) }),
    ...(input.type !== undefined && input.type !== null && { "type": input.type }),
  };
}

const serializeAws_restJson1AssetModelCompositeModelDefinitions = (
  input: (AssetModelCompositeModelDefinition)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelCompositeModelDefinition(entry, context);
  });
}

const serializeAws_restJson1AssetModelCompositeModels = (
  input: (AssetModelCompositeModel)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelCompositeModel(entry, context);
  });
}

const serializeAws_restJson1AssetModelHierarchies = (
  input: (AssetModelHierarchy)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelHierarchy(entry, context);
  });
}

const serializeAws_restJson1AssetModelHierarchy = (
  input: AssetModelHierarchy,
  context: __SerdeContext
): any => {
  return {
    ...(input.childAssetModelId !== undefined && input.childAssetModelId !== null && { "childAssetModelId": input.childAssetModelId }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
  };
}

const serializeAws_restJson1AssetModelHierarchyDefinition = (
  input: AssetModelHierarchyDefinition,
  context: __SerdeContext
): any => {
  return {
    ...(input.childAssetModelId !== undefined && input.childAssetModelId !== null && { "childAssetModelId": input.childAssetModelId }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
  };
}

const serializeAws_restJson1AssetModelHierarchyDefinitions = (
  input: (AssetModelHierarchyDefinition)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelHierarchyDefinition(entry, context);
  });
}

const serializeAws_restJson1AssetModelProperties = (
  input: (AssetModelProperty)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelProperty(entry, context);
  });
}

const serializeAws_restJson1AssetModelProperty = (
  input: AssetModelProperty,
  context: __SerdeContext
): any => {
  return {
    ...(input.dataType !== undefined && input.dataType !== null && { "dataType": input.dataType }),
    ...(input.dataTypeSpec !== undefined && input.dataTypeSpec !== null && { "dataTypeSpec": input.dataTypeSpec }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
    ...(input.path !== undefined && input.path !== null && { "path": serializeAws_restJson1AssetModelPropertyPath(input.path, context) }),
    ...(input.type !== undefined && input.type !== null && { "type": serializeAws_restJson1PropertyType(input.type, context) }),
    ...(input.unit !== undefined && input.unit !== null && { "unit": input.unit }),
  };
}

const serializeAws_restJson1AssetModelPropertyDefinition = (
  input: AssetModelPropertyDefinition,
  context: __SerdeContext
): any => {
  return {
    ...(input.dataType !== undefined && input.dataType !== null && { "dataType": input.dataType }),
    ...(input.dataTypeSpec !== undefined && input.dataTypeSpec !== null && { "dataTypeSpec": input.dataTypeSpec }),
    ...(input.externalId !== undefined && input.externalId !== null && { "externalId": input.externalId }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
    ...(input.type !== undefined && input.type !== null && { "type": serializeAws_restJson1PropertyType(input.type, context) }),
    ...(input.unit !== undefined && input.unit !== null && { "unit": input.unit }),
  };
}

const serializeAws_restJson1AssetModelPropertyDefinitions = (
  input: (AssetModelPropertyDefinition)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelPropertyDefinition(entry, context);
  });
}

const serializeAws_restJson1AssetModelPropertyPath = (
  input: (AssetModelPropertyPathSegment)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1AssetModelPropertyPathSegment(entry, context);
  });
}

const serializeAws_restJson1AssetModelPropertyPathSegment = (
  input: AssetModelPropertyPathSegment,
  context: __SerdeContext
): any => {
  return {
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
  };
}

const serializeAws_restJson1Attribute = (
  input: Attribute,
  context: __SerdeContext
): any => {
  return {
    ...(input.defaultValue !== undefined && input.defaultValue !== null && { "defaultValue": input.defaultValue }),
  };
}

const serializeAws_restJson1ExpressionVariable = (
  input: ExpressionVariable,
  context: __SerdeContext
): any => {
  return {
    ...(input.name !== undefined && input.name !== null && { "name": input.name }),
    ...(input.value !== undefined && input.value !== null && { "value": serializeAws_restJson1VariableValue(input.value, context) }),
  };
}

const serializeAws_restJson1ExpressionVariables = (
  input: (ExpressionVariable)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1ExpressionVariable(entry, context);
  });
}

const serializeAws_restJson1ForwardingConfig = (
  input: ForwardingConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.state !== undefined && input.state !== null && { "state": input.state }),
  };
}

const serializeAws_restJson1LoggingOptions = (
  input: LoggingOptions,
  context: __SerdeContext
): any => {
  return {
    ...(input.level !== undefined && input.level !== null && { "level": input.level }),
  };
}

const serializeAws_restJson1Measurement = (
  input: Measurement,
  context: __SerdeContext
): any => {
  return {
    ...(input.processingConfig !== undefined && input.processingConfig !== null && { "processingConfig": serializeAws_restJson1MeasurementProcessingConfig(input.processingConfig, context) }),
  };
}

const serializeAws_restJson1MeasurementProcessingConfig = (
  input: MeasurementProcessingConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.forwardingConfig !== undefined && input.forwardingConfig !== null && { "forwardingConfig": serializeAws_restJson1ForwardingConfig(input.forwardingConfig, context) }),
  };
}

const serializeAws_restJson1Metric = (
  input: Metric,
  context: __SerdeContext
): any => {
  return {
    ...(input.expression !== undefined && input.expression !== null && { "expression": input.expression }),
    ...(input.processingConfig !== undefined && input.processingConfig !== null && { "processingConfig": serializeAws_restJson1MetricProcessingConfig(input.processingConfig, context) }),
    ...(input.variables !== undefined && input.variables !== null && { "variables": serializeAws_restJson1ExpressionVariables(input.variables, context) }),
    ...(input.window !== undefined && input.window !== null && { "window": serializeAws_restJson1MetricWindow(input.window, context) }),
  };
}

const serializeAws_restJson1MetricProcessingConfig = (
  input: MetricProcessingConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.computeLocation !== undefined && input.computeLocation !== null && { "computeLocation": input.computeLocation }),
  };
}

const serializeAws_restJson1MetricWindow = (
  input: MetricWindow,
  context: __SerdeContext
): any => {
  return {
    ...(input.tumbling !== undefined && input.tumbling !== null && { "tumbling": serializeAws_restJson1TumblingWindow(input.tumbling, context) }),
  };
}

const serializeAws_restJson1PropertyType = (
  input: PropertyType,
  context: __SerdeContext
): any => {
  return {
    ...(input.attribute !== undefined && input.attribute !== null && { "attribute": serializeAws_restJson1Attribute(input.attribute, context) }),
    ...(input.measurement !== undefined && input.measurement !== null && { "measurement": serializeAws_restJson1Measurement(input.measurement, context) }),
    ...(input.metric !== undefined && input.metric !== null && { "metric": serializeAws_restJson1Metric(input.metric, context) }),
    ...(input.transform !== undefined && input.transform !== null && { "transform": serializeAws_restJson1Transform(input.transform, context) }),
  };
}

const serializeAws_restJson1TargetResource = (
  input: TargetResource,
  context: __SerdeContext
): any => {
  return {
    ...(input.assetId !== undefined && input.assetId !== null && { "assetId": input.assetId }),
  };
}

const serializeAws_restJson1Transform = (
  input: Transform,
  context: __SerdeContext
): any => {
  return {
    ...(input.expression !== undefined && input.expression !== null && { "expression": input.expression }),
    ...(input.processingConfig !== undefined && input.processingConfig !== null && { "processingConfig": serializeAws_restJson1TransformProcessingConfig(input.processingConfig, context) }),
    ...(input.variables !== undefined && input.variables !== null && { "variables": serializeAws_restJson1ExpressionVariables(input.variables, context) }),
  };
}

const serializeAws_restJson1TransformProcessingConfig = (
  input: TransformProcessingConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.computeLocation !== undefined && input.computeLocation !== null && { "computeLocation": input.computeLocation }),
    ...(input.forwardingConfig !== undefined && input.forwardingConfig !== null && { "forwardingConfig": serializeAws_restJson1ForwardingConfig(input.forwardingConfig, context) }),
  };
}

const serializeAws_restJson1TumblingWindow = (
  input: TumblingWindow,
  context: __SerdeContext
): any => {
  return {
    ...(input.interval !== undefined && input.interval !== null && { "interval": input.interval }),
    ...(input.offset !== undefined && input.offset !== null && { "offset": input.offset }),
  };
}

const serializeAws_restJson1VariableValue = (
  input: VariableValue,
  context: __SerdeContext
): any => {
  return {
    ...(input.hierarchyId !== undefined && input.hierarchyId !== null && { "hierarchyId": input.hierarchyId }),
    ...(input.propertyId !== undefined && input.propertyId !== null && { "propertyId": input.propertyId }),
    ...(input.propertyPath !== undefined && input.propertyPath !== null && { "propertyPath": serializeAws_restJson1AssetModelPropertyPath(input.propertyPath, context) }),
  };
}

const serializeAws_restJson1IDs = (
  input: (string)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return entry;
  });
}

const serializeAws_restJson1TagMap = (
  input: { [key: string]: string },
  context: __SerdeContext
): any => {
  return Object.entries(input).reduce((acc: {[key: string]: any}, [key, value]: [string, any]) => {
    if (value === null) {
      return acc;
    }
    return {
      ...acc,
      [key]: value
    };
  }, {});
}

const serializeAws_restJson1Alarms = (
  input: Alarms,
  context: __SerdeContext
): any => {
  return {
    ...(input.alarmRoleArn !== undefined && input.alarmRoleArn !== null && { "alarmRoleArn": input.alarmRoleArn }),
    ...(input.notificationLambdaArn !== undefined && input.notificationLambdaArn !== null && { "notificationLambdaArn": input.notificationLambdaArn }),
  };
}

const serializeAws_restJson1GroupIdentity = (
  input: GroupIdentity,
  context: __SerdeContext
): any => {
  return {
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
  };
}

const serializeAws_restJson1IAMRoleIdentity = (
  input: IAMRoleIdentity,
  context: __SerdeContext
): any => {
  return {
    ...(input.arn !== undefined && input.arn !== null && { "arn": input.arn }),
  };
}

const serializeAws_restJson1IAMUserIdentity = (
  input: IAMUserIdentity,
  context: __SerdeContext
): any => {
  return {
    ...(input.arn !== undefined && input.arn !== null && { "arn": input.arn }),
  };
}

const serializeAws_restJson1Identity = (
  input: Identity,
  context: __SerdeContext
): any => {
  return {
    ...(input.group !== undefined && input.group !== null && { "group": serializeAws_restJson1GroupIdentity(input.group, context) }),
    ...(input.iamRole !== undefined && input.iamRole !== null && { "iamRole": serializeAws_restJson1IAMRoleIdentity(input.iamRole, context) }),
    ...(input.iamUser !== undefined && input.iamUser !== null && { "iamUser": serializeAws_restJson1IAMUserIdentity(input.iamUser, context) }),
    ...(input.user !== undefined && input.user !== null && { "user": serializeAws_restJson1UserIdentity(input.user, context) }),
  };
}

const serializeAws_restJson1Image = (
  input: Image,
  context: __SerdeContext
): any => {
  return {
    ...(input.file !== undefined && input.file !== null && { "file": serializeAws_restJson1ImageFile(input.file, context) }),
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
  };
}

const serializeAws_restJson1ImageFile = (
  input: ImageFile,
  context: __SerdeContext
): any => {
  return {
    ...(input.data !== undefined && input.data !== null && { "data": context.base64Encoder(input.data) }),
    ...(input.type !== undefined && input.type !== null && { "type": input.type }),
  };
}

const serializeAws_restJson1PortalEdgeConfig = (
  input: PortalEdgeConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.edgeAccess !== undefined && input.edgeAccess !== null && { "edgeAccess": input.edgeAccess }),
  };
}

const serializeAws_restJson1PortalResource = (
  input: PortalResource,
  context: __SerdeContext
): any => {
  return {
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
  };
}

const serializeAws_restJson1ProjectResource = (
  input: ProjectResource,
  context: __SerdeContext
): any => {
  return {
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
  };
}

const serializeAws_restJson1ProjectSharing = (
  input: (ProjectSharingConfig)[],
  context: __SerdeContext
): any => {
  return input.filter((e: any) => e != null).map(entry => {
    if (entry === null) { return null as any; }
    return serializeAws_restJson1ProjectSharingConfig(entry, context);
  });
}

const serializeAws_restJson1ProjectSharingConfig = (
  input: ProjectSharingConfig,
  context: __SerdeContext
): any => {
  return {
    ...(input.expirationTime !== undefined && input.expirationTime !== null && { "expirationTime": input.expirationTime }),
    ...(input.sharingAlias !== undefined && input.sharingAlias !== null && { "sharingAlias": input.sharingAlias }),
    ...(input.sharingId !== undefined && input.sharingId !== null && { "sharingId": input.sharingId }),
    ...(input.sharingScope !== undefined && input.sharingScope !== null && { "sharingScope": input.sharingScope }),
    ...(input.sharingUrl !== undefined && input.sharingUrl !== null && { "sharingUrl": input.sharingUrl }),
    ...(input.status !== undefined && input.status !== null && { "status": input.status }),
  };
}

const serializeAws_restJson1Resource = (
  input: Resource,
  context: __SerdeContext
): any => {
  return {
    ...(input.portal !== undefined && input.portal !== null && { "portal": serializeAws_restJson1PortalResource(input.portal, context) }),
    ...(input.project !== undefined && input.project !== null && { "project": serializeAws_restJson1ProjectResource(input.project, context) }),
  };
}

const serializeAws_restJson1UserIdentity = (
  input: UserIdentity,
  context: __SerdeContext
): any => {
  return {
    ...(input.id !== undefined && input.id !== null && { "id": input.id }),
  };
}

const deserializeAws_restJson1GatewayCapabilitySummaries = (
  output: any,
  context: __SerdeContext
): (GatewayCapabilitySummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1GatewayCapabilitySummary(entry, context);
  });
}

const deserializeAws_restJson1GatewayCapabilitySummary = (
  output: any,
  context: __SerdeContext
): GatewayCapabilitySummary => {
  return {
    capabilityNamespace: __expectString(output.capabilityNamespace),
    capabilitySyncStatus: __expectString(output.capabilitySyncStatus),
  } as any;
}

const deserializeAws_restJson1GatewayPlatform = (
  output: any,
  context: __SerdeContext
): GatewayPlatform => {
  return {
    greengrass: (output.greengrass !== undefined && output.greengrass !== null) ? deserializeAws_restJson1Greengrass(output.greengrass, context): undefined,
    greengrassV2: (output.greengrassV2 !== undefined && output.greengrassV2 !== null) ? deserializeAws_restJson1GreengrassV2(output.greengrassV2, context): undefined,
  } as any;
}

const deserializeAws_restJson1GatewaySummaries = (
  output: any,
  context: __SerdeContext
): (GatewaySummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1GatewaySummary(entry, context);
  });
}

const deserializeAws_restJson1GatewaySummary = (
  output: any,
  context: __SerdeContext
): GatewaySummary => {
  return {
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    gatewayCapabilitySummaries: (output.gatewayCapabilitySummaries !== undefined && output.gatewayCapabilitySummaries !== null) ? deserializeAws_restJson1GatewayCapabilitySummaries(output.gatewayCapabilitySummaries, context): undefined,
    gatewayId: __expectString(output.gatewayId),
    gatewayName: __expectString(output.gatewayName),
    gatewayPlatform: (output.gatewayPlatform !== undefined && output.gatewayPlatform !== null) ? deserializeAws_restJson1GatewayPlatform(output.gatewayPlatform, context): undefined,
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
  } as any;
}

const deserializeAws_restJson1Greengrass = (
  output: any,
  context: __SerdeContext
): Greengrass => {
  return {
    groupArn: __expectString(output.groupArn),
  } as any;
}

const deserializeAws_restJson1GreengrassV2 = (
  output: any,
  context: __SerdeContext
): GreengrassV2 => {
  return {
    coreDeviceThingName: __expectString(output.coreDeviceThingName),
  } as any;
}

const deserializeAws_restJson1ActionDefinition = (
  output: any,
  context: __SerdeContext
): ActionDefinition => {
  return {
    actionDefinitionId: __expectString(output.actionDefinitionId),
    actionName: __expectString(output.actionName),
    actionType: __expectString(output.actionType),
  } as any;
}

const deserializeAws_restJson1ActionDefinitions = (
  output: any,
  context: __SerdeContext
): (ActionDefinition)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ActionDefinition(entry, context);
  });
}

const deserializeAws_restJson1ActionPayload = (
  output: any,
  context: __SerdeContext
): ActionPayload => {
  return {
    stringValue: __expectString(output.stringValue),
  } as any;
}

const deserializeAws_restJson1ActionSummaries = (
  output: any,
  context: __SerdeContext
): (ActionSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ActionSummary(entry, context);
  });
}

const deserializeAws_restJson1ActionSummary = (
  output: any,
  context: __SerdeContext
): ActionSummary => {
  return {
    actionDefinitionId: __expectString(output.actionDefinitionId),
    actionId: __expectString(output.actionId),
    targetResource: (output.targetResource !== undefined && output.targetResource !== null) ? deserializeAws_restJson1TargetResource(output.targetResource, context): undefined,
  } as any;
}

const deserializeAws_restJson1AssetCompositeModel = (
  output: any,
  context: __SerdeContext
): AssetCompositeModel => {
  return {
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    properties: (output.properties !== undefined && output.properties !== null) ? deserializeAws_restJson1AssetProperties(output.properties, context): undefined,
    type: __expectString(output.type),
  } as any;
}

const deserializeAws_restJson1AssetCompositeModelPath = (
  output: any,
  context: __SerdeContext
): (AssetCompositeModelPathSegment)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetCompositeModelPathSegment(entry, context);
  });
}

const deserializeAws_restJson1AssetCompositeModelPathSegment = (
  output: any,
  context: __SerdeContext
): AssetCompositeModelPathSegment => {
  return {
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetCompositeModels = (
  output: any,
  context: __SerdeContext
): (AssetCompositeModel)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetCompositeModel(entry, context);
  });
}

const deserializeAws_restJson1AssetCompositeModelSummaries = (
  output: any,
  context: __SerdeContext
): (AssetCompositeModelSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetCompositeModelSummary(entry, context);
  });
}

const deserializeAws_restJson1AssetCompositeModelSummary = (
  output: any,
  context: __SerdeContext
): AssetCompositeModelSummary => {
  return {
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetCompositeModelPath(output.path, context): undefined,
    type: __expectString(output.type),
  } as any;
}

const deserializeAws_restJson1AssetHierarchies = (
  output: any,
  context: __SerdeContext
): (AssetHierarchy)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetHierarchy(entry, context);
  });
}

const deserializeAws_restJson1AssetHierarchy = (
  output: any,
  context: __SerdeContext
): AssetHierarchy => {
  return {
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetHierarchyInfo = (
  output: any,
  context: __SerdeContext
): AssetHierarchyInfo => {
  return {
    childAssetId: __expectString(output.childAssetId),
    parentAssetId: __expectString(output.parentAssetId),
  } as any;
}

const deserializeAws_restJson1AssetModelCompositeModel = (
  output: any,
  context: __SerdeContext
): AssetModelCompositeModel => {
  return {
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    properties: (output.properties !== undefined && output.properties !== null) ? deserializeAws_restJson1AssetModelProperties(output.properties, context): undefined,
    type: __expectString(output.type),
  } as any;
}

const deserializeAws_restJson1AssetModelCompositeModelPath = (
  output: any,
  context: __SerdeContext
): (AssetModelCompositeModelPathSegment)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelCompositeModelPathSegment(entry, context);
  });
}

const deserializeAws_restJson1AssetModelCompositeModelPathSegment = (
  output: any,
  context: __SerdeContext
): AssetModelCompositeModelPathSegment => {
  return {
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetModelCompositeModels = (
  output: any,
  context: __SerdeContext
): (AssetModelCompositeModel)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelCompositeModel(entry, context);
  });
}

const deserializeAws_restJson1AssetModelCompositeModelSummaries = (
  output: any,
  context: __SerdeContext
): (AssetModelCompositeModelSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelCompositeModelSummary(entry, context);
  });
}

const deserializeAws_restJson1AssetModelCompositeModelSummary = (
  output: any,
  context: __SerdeContext
): AssetModelCompositeModelSummary => {
  return {
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetModelCompositeModelPath(output.path, context): undefined,
    type: __expectString(output.type),
  } as any;
}

const deserializeAws_restJson1AssetModelHierarchies = (
  output: any,
  context: __SerdeContext
): (AssetModelHierarchy)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelHierarchy(entry, context);
  });
}

const deserializeAws_restJson1AssetModelHierarchy = (
  output: any,
  context: __SerdeContext
): AssetModelHierarchy => {
  return {
    childAssetModelId: __expectString(output.childAssetModelId),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetModelProperties = (
  output: any,
  context: __SerdeContext
): (AssetModelProperty)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelProperty(entry, context);
  });
}

const deserializeAws_restJson1AssetModelProperty = (
  output: any,
  context: __SerdeContext
): AssetModelProperty => {
  return {
    dataType: __expectString(output.dataType),
    dataTypeSpec: __expectString(output.dataTypeSpec),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetModelPropertyPath(output.path, context): undefined,
    type: (output.type !== undefined && output.type !== null) ? deserializeAws_restJson1PropertyType(output.type, context): undefined,
    unit: __expectString(output.unit),
  } as any;
}

const deserializeAws_restJson1AssetModelPropertyPath = (
  output: any,
  context: __SerdeContext
): (AssetModelPropertyPathSegment)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelPropertyPathSegment(entry, context);
  });
}

const deserializeAws_restJson1AssetModelPropertyPathSegment = (
  output: any,
  context: __SerdeContext
): AssetModelPropertyPathSegment => {
  return {
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetModelPropertySummaries = (
  output: any,
  context: __SerdeContext
): (AssetModelPropertySummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelPropertySummary(entry, context);
  });
}

const deserializeAws_restJson1AssetModelPropertySummary = (
  output: any,
  context: __SerdeContext
): AssetModelPropertySummary => {
  return {
    assetModelCompositeModelId: __expectString(output.assetModelCompositeModelId),
    dataType: __expectString(output.dataType),
    dataTypeSpec: __expectString(output.dataTypeSpec),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetModelPropertyPath(output.path, context): undefined,
    type: (output.type !== undefined && output.type !== null) ? deserializeAws_restJson1PropertyType(output.type, context): undefined,
    unit: __expectString(output.unit),
  } as any;
}

const deserializeAws_restJson1AssetModelStatus = (
  output: any,
  context: __SerdeContext
): AssetModelStatus => {
  return {
    error: (output.error !== undefined && output.error !== null) ? deserializeAws_restJson1ErrorDetails(output.error, context): undefined,
    state: __expectString(output.state),
  } as any;
}

const deserializeAws_restJson1AssetModelSummaries = (
  output: any,
  context: __SerdeContext
): (AssetModelSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetModelSummary(entry, context);
  });
}

const deserializeAws_restJson1AssetModelSummary = (
  output: any,
  context: __SerdeContext
): AssetModelSummary => {
  return {
    arn: __expectString(output.arn),
    assetModelType: __expectString(output.assetModelType),
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
    status: (output.status !== undefined && output.status !== null) ? deserializeAws_restJson1AssetModelStatus(output.status, context): undefined,
  } as any;
}

const deserializeAws_restJson1AssetProperties = (
  output: any,
  context: __SerdeContext
): (AssetProperty)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetProperty(entry, context);
  });
}

const deserializeAws_restJson1AssetProperty = (
  output: any,
  context: __SerdeContext
): AssetProperty => {
  return {
    alias: __expectString(output.alias),
    dataType: __expectString(output.dataType),
    dataTypeSpec: __expectString(output.dataTypeSpec),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    notification: (output.notification !== undefined && output.notification !== null) ? deserializeAws_restJson1PropertyNotification(output.notification, context): undefined,
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetPropertyPath(output.path, context): undefined,
    unit: __expectString(output.unit),
  } as any;
}

const deserializeAws_restJson1AssetPropertyPath = (
  output: any,
  context: __SerdeContext
): (AssetPropertyPathSegment)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetPropertyPathSegment(entry, context);
  });
}

const deserializeAws_restJson1AssetPropertyPathSegment = (
  output: any,
  context: __SerdeContext
): AssetPropertyPathSegment => {
  return {
    id: __expectString(output.id),
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1AssetPropertySummaries = (
  output: any,
  context: __SerdeContext
): (AssetPropertySummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetPropertySummary(entry, context);
  });
}

const deserializeAws_restJson1AssetPropertySummary = (
  output: any,
  context: __SerdeContext
): AssetPropertySummary => {
  return {
    alias: __expectString(output.alias),
    assetCompositeModelId: __expectString(output.assetCompositeModelId),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    notification: (output.notification !== undefined && output.notification !== null) ? deserializeAws_restJson1PropertyNotification(output.notification, context): undefined,
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetPropertyPath(output.path, context): undefined,
    unit: __expectString(output.unit),
  } as any;
}

const deserializeAws_restJson1AssetRelationshipSummaries = (
  output: any,
  context: __SerdeContext
): (AssetRelationshipSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetRelationshipSummary(entry, context);
  });
}

const deserializeAws_restJson1AssetRelationshipSummary = (
  output: any,
  context: __SerdeContext
): AssetRelationshipSummary => {
  return {
    hierarchyInfo: (output.hierarchyInfo !== undefined && output.hierarchyInfo !== null) ? deserializeAws_restJson1AssetHierarchyInfo(output.hierarchyInfo, context): undefined,
    relationshipType: __expectString(output.relationshipType),
  } as any;
}

const deserializeAws_restJson1AssetStatus = (
  output: any,
  context: __SerdeContext
): AssetStatus => {
  return {
    error: (output.error !== undefined && output.error !== null) ? deserializeAws_restJson1ErrorDetails(output.error, context): undefined,
    state: __expectString(output.state),
  } as any;
}

const deserializeAws_restJson1AssetSummaries = (
  output: any,
  context: __SerdeContext
): (AssetSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetSummary(entry, context);
  });
}

const deserializeAws_restJson1AssetSummary = (
  output: any,
  context: __SerdeContext
): AssetSummary => {
  return {
    arn: __expectString(output.arn),
    assetModelId: __expectString(output.assetModelId),
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    hierarchies: (output.hierarchies !== undefined && output.hierarchies !== null) ? deserializeAws_restJson1AssetHierarchies(output.hierarchies, context): undefined,
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
    status: (output.status !== undefined && output.status !== null) ? deserializeAws_restJson1AssetStatus(output.status, context): undefined,
  } as any;
}

const deserializeAws_restJson1AssociatedAssetsSummaries = (
  output: any,
  context: __SerdeContext
): (AssociatedAssetsSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssociatedAssetsSummary(entry, context);
  });
}

const deserializeAws_restJson1AssociatedAssetsSummary = (
  output: any,
  context: __SerdeContext
): AssociatedAssetsSummary => {
  return {
    arn: __expectString(output.arn),
    assetModelId: __expectString(output.assetModelId),
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    externalId: __expectString(output.externalId),
    hierarchies: (output.hierarchies !== undefined && output.hierarchies !== null) ? deserializeAws_restJson1AssetHierarchies(output.hierarchies, context): undefined,
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
    status: (output.status !== undefined && output.status !== null) ? deserializeAws_restJson1AssetStatus(output.status, context): undefined,
  } as any;
}

const deserializeAws_restJson1Attribute = (
  output: any,
  context: __SerdeContext
): Attribute => {
  return {
    defaultValue: __expectString(output.defaultValue),
  } as any;
}

const deserializeAws_restJson1CompositeModelProperty = (
  output: any,
  context: __SerdeContext
): CompositeModelProperty => {
  return {
    assetProperty: (output.assetProperty !== undefined && output.assetProperty !== null) ? deserializeAws_restJson1Property(output.assetProperty, context): undefined,
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    type: __expectString(output.type),
  } as any;
}

const deserializeAws_restJson1CompositionDetails = (
  output: any,
  context: __SerdeContext
): CompositionDetails => {
  return {
    compositionRelationship: (output.compositionRelationship !== undefined && output.compositionRelationship !== null) ? deserializeAws_restJson1CompositionRelationship(output.compositionRelationship, context): undefined,
  } as any;
}

const deserializeAws_restJson1CompositionRelationship = (
  output: any,
  context: __SerdeContext
): (CompositionRelationshipItem)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1CompositionRelationshipItem(entry, context);
  });
}

const deserializeAws_restJson1CompositionRelationshipItem = (
  output: any,
  context: __SerdeContext
): CompositionRelationshipItem => {
  return {
    id: __expectString(output.id),
  } as any;
}

const deserializeAws_restJson1CompositionRelationshipSummaries = (
  output: any,
  context: __SerdeContext
): (CompositionRelationshipSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1CompositionRelationshipSummary(entry, context);
  });
}

const deserializeAws_restJson1CompositionRelationshipSummary = (
  output: any,
  context: __SerdeContext
): CompositionRelationshipSummary => {
  return {
    assetModelCompositeModelId: __expectString(output.assetModelCompositeModelId),
    assetModelCompositeModelType: __expectString(output.assetModelCompositeModelType),
    assetModelId: __expectString(output.assetModelId),
  } as any;
}

const deserializeAws_restJson1DetailedError = (
  output: any,
  context: __SerdeContext
): DetailedError => {
  return {
    code: __expectString(output.code),
    message: __expectString(output.message),
  } as any;
}

const deserializeAws_restJson1DetailedErrors = (
  output: any,
  context: __SerdeContext
): (DetailedError)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1DetailedError(entry, context);
  });
}

const deserializeAws_restJson1ErrorDetails = (
  output: any,
  context: __SerdeContext
): ErrorDetails => {
  return {
    code: __expectString(output.code),
    details: (output.details !== undefined && output.details !== null) ? deserializeAws_restJson1DetailedErrors(output.details, context): undefined,
    message: __expectString(output.message),
  } as any;
}

const deserializeAws_restJson1ExpressionVariable = (
  output: any,
  context: __SerdeContext
): ExpressionVariable => {
  return {
    name: __expectString(output.name),
    value: (output.value !== undefined && output.value !== null) ? deserializeAws_restJson1VariableValue(output.value, context): undefined,
  } as any;
}

const deserializeAws_restJson1ExpressionVariables = (
  output: any,
  context: __SerdeContext
): (ExpressionVariable)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ExpressionVariable(entry, context);
  });
}

const deserializeAws_restJson1ForwardingConfig = (
  output: any,
  context: __SerdeContext
): ForwardingConfig => {
  return {
    state: __expectString(output.state),
  } as any;
}

const deserializeAws_restJson1LoggingOptions = (
  output: any,
  context: __SerdeContext
): LoggingOptions => {
  return {
    level: __expectString(output.level),
  } as any;
}

const deserializeAws_restJson1Measurement = (
  output: any,
  context: __SerdeContext
): Measurement => {
  return {
    processingConfig: (output.processingConfig !== undefined && output.processingConfig !== null) ? deserializeAws_restJson1MeasurementProcessingConfig(output.processingConfig, context): undefined,
  } as any;
}

const deserializeAws_restJson1MeasurementProcessingConfig = (
  output: any,
  context: __SerdeContext
): MeasurementProcessingConfig => {
  return {
    forwardingConfig: (output.forwardingConfig !== undefined && output.forwardingConfig !== null) ? deserializeAws_restJson1ForwardingConfig(output.forwardingConfig, context): undefined,
  } as any;
}

const deserializeAws_restJson1Metric = (
  output: any,
  context: __SerdeContext
): Metric => {
  return {
    expression: __expectString(output.expression),
    processingConfig: (output.processingConfig !== undefined && output.processingConfig !== null) ? deserializeAws_restJson1MetricProcessingConfig(output.processingConfig, context): undefined,
    variables: (output.variables !== undefined && output.variables !== null) ? deserializeAws_restJson1ExpressionVariables(output.variables, context): undefined,
    window: (output.window !== undefined && output.window !== null) ? deserializeAws_restJson1MetricWindow(output.window, context): undefined,
  } as any;
}

const deserializeAws_restJson1MetricProcessingConfig = (
  output: any,
  context: __SerdeContext
): MetricProcessingConfig => {
  return {
    computeLocation: __expectString(output.computeLocation),
  } as any;
}

const deserializeAws_restJson1MetricWindow = (
  output: any,
  context: __SerdeContext
): MetricWindow => {
  return {
    tumbling: (output.tumbling !== undefined && output.tumbling !== null) ? deserializeAws_restJson1TumblingWindow(output.tumbling, context): undefined,
  } as any;
}

const deserializeAws_restJson1Property = (
  output: any,
  context: __SerdeContext
): Property => {
  return {
    alias: __expectString(output.alias),
    dataType: __expectString(output.dataType),
    externalId: __expectString(output.externalId),
    id: __expectString(output.id),
    name: __expectString(output.name),
    notification: (output.notification !== undefined && output.notification !== null) ? deserializeAws_restJson1PropertyNotification(output.notification, context): undefined,
    path: (output.path !== undefined && output.path !== null) ? deserializeAws_restJson1AssetPropertyPath(output.path, context): undefined,
    type: (output.type !== undefined && output.type !== null) ? deserializeAws_restJson1PropertyType(output.type, context): undefined,
    unit: __expectString(output.unit),
  } as any;
}

const deserializeAws_restJson1PropertyNotification = (
  output: any,
  context: __SerdeContext
): PropertyNotification => {
  return {
    state: __expectString(output.state),
    topic: __expectString(output.topic),
  } as any;
}

const deserializeAws_restJson1PropertyType = (
  output: any,
  context: __SerdeContext
): PropertyType => {
  return {
    attribute: (output.attribute !== undefined && output.attribute !== null) ? deserializeAws_restJson1Attribute(output.attribute, context): undefined,
    measurement: (output.measurement !== undefined && output.measurement !== null) ? deserializeAws_restJson1Measurement(output.measurement, context): undefined,
    metric: (output.metric !== undefined && output.metric !== null) ? deserializeAws_restJson1Metric(output.metric, context): undefined,
    transform: (output.transform !== undefined && output.transform !== null) ? deserializeAws_restJson1Transform(output.transform, context): undefined,
  } as any;
}

const deserializeAws_restJson1TargetResource = (
  output: any,
  context: __SerdeContext
): TargetResource => {
  return {
    assetId: __expectString(output.assetId),
  } as any;
}

const deserializeAws_restJson1TimeSeriesSummaries = (
  output: any,
  context: __SerdeContext
): (TimeSeriesSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1TimeSeriesSummary(entry, context);
  });
}

const deserializeAws_restJson1TimeSeriesSummary = (
  output: any,
  context: __SerdeContext
): TimeSeriesSummary => {
  return {
    alias: __expectString(output.alias),
    assetId: __expectString(output.assetId),
    dataType: __expectString(output.dataType),
    dataTypeSpec: __expectString(output.dataTypeSpec),
    propertyId: __expectString(output.propertyId),
    timeSeriesArn: __expectString(output.timeSeriesArn),
    timeSeriesCreationDate: (output.timeSeriesCreationDate !== undefined && output.timeSeriesCreationDate !== null) ? new Date(Math.round(output.timeSeriesCreationDate * 1000)): undefined,
    timeSeriesId: __expectString(output.timeSeriesId),
    timeSeriesLastUpdateDate: (output.timeSeriesLastUpdateDate !== undefined && output.timeSeriesLastUpdateDate !== null) ? new Date(Math.round(output.timeSeriesLastUpdateDate * 1000)): undefined,
  } as any;
}

const deserializeAws_restJson1Transform = (
  output: any,
  context: __SerdeContext
): Transform => {
  return {
    expression: __expectString(output.expression),
    processingConfig: (output.processingConfig !== undefined && output.processingConfig !== null) ? deserializeAws_restJson1TransformProcessingConfig(output.processingConfig, context): undefined,
    variables: (output.variables !== undefined && output.variables !== null) ? deserializeAws_restJson1ExpressionVariables(output.variables, context): undefined,
  } as any;
}

const deserializeAws_restJson1TransformProcessingConfig = (
  output: any,
  context: __SerdeContext
): TransformProcessingConfig => {
  return {
    computeLocation: __expectString(output.computeLocation),
    forwardingConfig: (output.forwardingConfig !== undefined && output.forwardingConfig !== null) ? deserializeAws_restJson1ForwardingConfig(output.forwardingConfig, context): undefined,
  } as any;
}

const deserializeAws_restJson1TumblingWindow = (
  output: any,
  context: __SerdeContext
): TumblingWindow => {
  return {
    interval: __expectString(output.interval),
    offset: __expectString(output.offset),
  } as any;
}

const deserializeAws_restJson1VariableValue = (
  output: any,
  context: __SerdeContext
): VariableValue => {
  return {
    hierarchyId: __expectString(output.hierarchyId),
    propertyId: __expectString(output.propertyId),
    propertyPath: (output.propertyPath !== undefined && output.propertyPath !== null) ? deserializeAws_restJson1AssetModelPropertyPath(output.propertyPath, context): undefined,
  } as any;
}

const deserializeAws_restJson1AccessPolicySummaries = (
  output: any,
  context: __SerdeContext
): (AccessPolicySummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AccessPolicySummary(entry, context);
  });
}

const deserializeAws_restJson1AccessPolicySummary = (
  output: any,
  context: __SerdeContext
): AccessPolicySummary => {
  return {
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    id: __expectString(output.id),
    identity: (output.identity !== undefined && output.identity !== null) ? deserializeAws_restJson1Identity(output.identity, context): undefined,
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    permission: __expectString(output.permission),
    resource: (output.resource !== undefined && output.resource !== null) ? deserializeAws_restJson1Resource(output.resource, context): undefined,
  } as any;
}

const deserializeAws_restJson1Alarms = (
  output: any,
  context: __SerdeContext
): Alarms => {
  return {
    alarmRoleArn: __expectString(output.alarmRoleArn),
    notificationLambdaArn: __expectString(output.notificationLambdaArn),
  } as any;
}

const deserializeAws_restJson1AssetErrorDetails = (
  output: any,
  context: __SerdeContext
): AssetErrorDetails => {
  return {
    assetId: __expectString(output.assetId),
    code: __expectString(output.code),
    message: __expectString(output.message),
  } as any;
}

const deserializeAws_restJson1AssetIDs = (
  output: any,
  context: __SerdeContext
): (string)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return __expectString(entry) as any;
  });
}

const deserializeAws_restJson1BatchAssociateProjectAssetsErrors = (
  output: any,
  context: __SerdeContext
): (AssetErrorDetails)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetErrorDetails(entry, context);
  });
}

const deserializeAws_restJson1BatchDisassociateProjectAssetsErrors = (
  output: any,
  context: __SerdeContext
): (AssetErrorDetails)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1AssetErrorDetails(entry, context);
  });
}

const deserializeAws_restJson1DashboardSummaries = (
  output: any,
  context: __SerdeContext
): (DashboardSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1DashboardSummary(entry, context);
  });
}

const deserializeAws_restJson1DashboardSummary = (
  output: any,
  context: __SerdeContext
): DashboardSummary => {
  return {
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
  } as any;
}

const deserializeAws_restJson1GroupIdentity = (
  output: any,
  context: __SerdeContext
): GroupIdentity => {
  return {
    id: __expectString(output.id),
  } as any;
}

const deserializeAws_restJson1IAMRoleIdentity = (
  output: any,
  context: __SerdeContext
): IAMRoleIdentity => {
  return {
    arn: __expectString(output.arn),
  } as any;
}

const deserializeAws_restJson1IAMUserIdentity = (
  output: any,
  context: __SerdeContext
): IAMUserIdentity => {
  return {
    arn: __expectString(output.arn),
  } as any;
}

const deserializeAws_restJson1Identity = (
  output: any,
  context: __SerdeContext
): Identity => {
  return {
    group: (output.group !== undefined && output.group !== null) ? deserializeAws_restJson1GroupIdentity(output.group, context): undefined,
    iamRole: (output.iamRole !== undefined && output.iamRole !== null) ? deserializeAws_restJson1IAMRoleIdentity(output.iamRole, context): undefined,
    iamUser: (output.iamUser !== undefined && output.iamUser !== null) ? deserializeAws_restJson1IAMUserIdentity(output.iamUser, context): undefined,
    user: (output.user !== undefined && output.user !== null) ? deserializeAws_restJson1UserIdentity(output.user, context): undefined,
  } as any;
}

const deserializeAws_restJson1ImageLocation = (
  output: any,
  context: __SerdeContext
): ImageLocation => {
  return {
    id: __expectString(output.id),
    url: __expectString(output.url),
  } as any;
}

const deserializeAws_restJson1MonitorErrorDetails = (
  output: any,
  context: __SerdeContext
): MonitorErrorDetails => {
  return {
    code: __expectString(output.code),
    message: __expectString(output.message),
  } as any;
}

const deserializeAws_restJson1PortalEdgeConfig = (
  output: any,
  context: __SerdeContext
): PortalEdgeConfig => {
  return {
    edgeAccess: __expectString(output.edgeAccess),
  } as any;
}

const deserializeAws_restJson1PortalResource = (
  output: any,
  context: __SerdeContext
): PortalResource => {
  return {
    id: __expectString(output.id),
  } as any;
}

const deserializeAws_restJson1PortalStatus = (
  output: any,
  context: __SerdeContext
): PortalStatus => {
  return {
    error: (output.error !== undefined && output.error !== null) ? deserializeAws_restJson1MonitorErrorDetails(output.error, context): undefined,
    state: __expectString(output.state),
  } as any;
}

const deserializeAws_restJson1PortalSummaries = (
  output: any,
  context: __SerdeContext
): (PortalSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1PortalSummary(entry, context);
  });
}

const deserializeAws_restJson1PortalSummary = (
  output: any,
  context: __SerdeContext
): PortalSummary => {
  return {
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
    roleArn: __expectString(output.roleArn),
    startUrl: __expectString(output.startUrl),
    status: (output.status !== undefined && output.status !== null) ? deserializeAws_restJson1PortalStatus(output.status, context): undefined,
  } as any;
}

const deserializeAws_restJson1ProjectResource = (
  output: any,
  context: __SerdeContext
): ProjectResource => {
  return {
    id: __expectString(output.id),
  } as any;
}

const deserializeAws_restJson1ProjectSharing = (
  output: any,
  context: __SerdeContext
): (ProjectSharingConfig)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ProjectSharingConfig(entry, context);
  });
}

const deserializeAws_restJson1ProjectSharingConfig = (
  output: any,
  context: __SerdeContext
): ProjectSharingConfig => {
  return {
    expirationTime: __expectInt32(output.expirationTime),
    sharingAlias: __expectString(output.sharingAlias),
    sharingId: __expectString(output.sharingId),
    sharingScope: __expectString(output.sharingScope),
    sharingUrl: __expectString(output.sharingUrl),
    status: __expectString(output.status),
  } as any;
}

const deserializeAws_restJson1ProjectSharingSummaries = (
  output: any,
  context: __SerdeContext
): (ProjectSharingSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ProjectSharingSummary(entry, context);
  });
}

const deserializeAws_restJson1ProjectSharingSummary = (
  output: any,
  context: __SerdeContext
): ProjectSharingSummary => {
  return {
    sharingScope: __expectString(output.sharingScope),
    status: __expectString(output.status),
  } as any;
}

const deserializeAws_restJson1ProjectSummaries = (
  output: any,
  context: __SerdeContext
): (ProjectSummary)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ProjectSummary(entry, context);
  });
}

const deserializeAws_restJson1ProjectSummary = (
  output: any,
  context: __SerdeContext
): ProjectSummary => {
  return {
    creationDate: (output.creationDate !== undefined && output.creationDate !== null) ? new Date(Math.round(output.creationDate * 1000)): undefined,
    description: __expectString(output.description),
    id: __expectString(output.id),
    lastUpdateDate: (output.lastUpdateDate !== undefined && output.lastUpdateDate !== null) ? new Date(Math.round(output.lastUpdateDate * 1000)): undefined,
    name: __expectString(output.name),
    projectSharing: (output.projectSharing !== undefined && output.projectSharing !== null) ? deserializeAws_restJson1ProjectSharingSummaries(output.projectSharing, context): undefined,
  } as any;
}

const deserializeAws_restJson1Resource = (
  output: any,
  context: __SerdeContext
): Resource => {
  return {
    portal: (output.portal !== undefined && output.portal !== null) ? deserializeAws_restJson1PortalResource(output.portal, context): undefined,
    project: (output.project !== undefined && output.project !== null) ? deserializeAws_restJson1ProjectResource(output.project, context): undefined,
  } as any;
}

const deserializeAws_restJson1UserIdentity = (
  output: any,
  context: __SerdeContext
): UserIdentity => {
  return {
    id: __expectString(output.id),
  } as any;
}

const deserializeAws_restJson1FinalResponse = (
  output: any,
  context: __SerdeContext
): FinalResponse => {
  return {
    text: __expectString(output.text),
  } as any;
}

const deserializeAws_restJson1InvokeAssistantStep = (
  output: any,
  context: __SerdeContext
): InvokeAssistantStep => {
  return {
    rationale: (output.rationale !== undefined && output.rationale !== null) ? deserializeAws_restJson1Rationale(output.rationale, context): undefined,
    stepId: __expectString(output.stepId),
    toolInvocation: (output.toolInvocation !== undefined && output.toolInvocation !== null) ? deserializeAws_restJson1ToolInvocation(output.toolInvocation, context): undefined,
  } as any;
}

const deserializeAws_restJson1Rationale = (
  output: any,
  context: __SerdeContext
): Rationale => {
  return {
    text: __expectString(output.text),
  } as any;
}

const deserializeAws_restJson1ResponseStream = (
  output: any,
  context: __SerdeContext
): ResponseStream => {
  if (output.finalResponse !== undefined && output.finalResponse !== null) {
    return {
      finalResponse: deserializeAws_restJson1FinalResponse(output.finalResponse, context)
    };
  }
  if (output.step !== undefined && output.step !== null) {
    return {
      step: deserializeAws_restJson1InvokeAssistantStep(output.step, context)
    };
  }
  return { $unknown: Object.entries(output)[0] };
}

const deserializeAws_restJson1ToolInvocation = (
  output: any,
  context: __SerdeContext
): ToolInvocation => {
  return {
    name: __expectString(output.name),
    parameters: (output.parameters !== undefined && output.parameters !== null) ? deserializeAws_restJson1ToolInvocationParameters(output.parameters, context): undefined,
  } as any;
}

const deserializeAws_restJson1ToolInvocationParameter = (
  output: any,
  context: __SerdeContext
): ToolInvocationParameter => {
  return {
    name: __expectString(output.name),
    type: __expectString(output.type),
    value: __expectString(output.value),
  } as any;
}

const deserializeAws_restJson1ToolInvocationParameters = (
  output: any,
  context: __SerdeContext
): (ToolInvocationParameter)[] => {
  return (output || []).filter((e: any) => e != null).map((entry: any) => {
    if (entry === null) { return null as any; }
    return deserializeAws_restJson1ToolInvocationParameter(entry, context);
  });
}

const deserializeMetadata = (output: __HttpResponse): __ResponseMetadata => ({
  httpStatusCode: output.statusCode,
  requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"],
  extendedRequestId: output.headers["x-amz-id-2"],
  cfId: output.headers["x-amz-cf-id"],
});

// Collect low-level response body stream to Uint8Array.
const collectBody = (streamBody: any = new Uint8Array(), context: __SerdeContext): Promise<Uint8Array> => {
  if (streamBody instanceof Uint8Array) {
    return Promise.resolve(streamBody);
  }
  return context.streamCollector(streamBody) || Promise.resolve(new Uint8Array());
};

// Encode Uint8Array data into string with utf-8.
const collectBodyString = (streamBody: any, context: __SerdeContext): Promise<string> => collectBody(streamBody, context).then(body => context.utf8Encoder(body))

const isSerializableHeaderValue = (value: any): boolean =>
  value !== undefined &&
  value !== null &&
  value !== "" &&
  (!Object.getOwnPropertyNames(value).includes("length") ||
    value.length != 0) &&
  (!Object.getOwnPropertyNames(value).includes("size") || value.size != 0);

const parseBody = (streamBody: any, context: __SerdeContext): any => collectBodyString(streamBody, context).then(encoded => {
  if (encoded.length) {
    return JSON.parse(encoded);
  }
  return {};
});

/**
 * Load an error code for the aws.rest-json-1.1 protocol.
 */
const loadRestJsonErrorCode = (output: __HttpResponse, data: any): string => {
  const findKey = (object: any, key: string) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());

  const sanitizeErrorCode = (rawValue: string): string => {
    let cleanValue = rawValue;
    if (cleanValue.indexOf(":") >= 0) {
      cleanValue = cleanValue.split(":")[0];
    }
    if (cleanValue.indexOf("#") >= 0) {
      cleanValue = cleanValue.split("#")[1];
    }
    return cleanValue;
  };

  const headerKey = findKey(output.headers, "x-amzn-errortype");
  if (headerKey !== undefined) {
    return sanitizeErrorCode(output.headers[headerKey]);
  }

  if (data.code !== undefined) {
    return sanitizeErrorCode(data.code);
  }

  if (data["__type"] !== undefined) {
    return sanitizeErrorCode(data["__type"]);
  }

  return "";
};
