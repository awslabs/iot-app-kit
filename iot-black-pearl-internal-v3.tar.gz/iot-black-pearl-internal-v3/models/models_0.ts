import {
  MetadataBearer as $MetadataBearer,
  SmithyException as __SmithyException,
} from "@aws-sdk/types";

export interface ConflictingOperationException extends __SmithyException, $MetadataBearer {
  name: "ConflictingOperationException";
  $fault: "client";
  message: string | undefined;
  resourceId: string | undefined;
  resourceArn: string | undefined;
}

export namespace ConflictingOperationException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ConflictingOperationException): any => ({
    ...obj,
  })
}

export interface InternalFailureException extends __SmithyException, $MetadataBearer {
  name: "InternalFailureException";
  $fault: "server";
  message: string | undefined;
}

export namespace InternalFailureException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InternalFailureException): any => ({
    ...obj,
  })
}

export interface InvalidRequestException extends __SmithyException, $MetadataBearer {
  name: "InvalidRequestException";
  $fault: "client";
  message: string | undefined;
}

export namespace InvalidRequestException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InvalidRequestException): any => ({
    ...obj,
  })
}

export interface LimitExceededException extends __SmithyException, $MetadataBearer {
  name: "LimitExceededException";
  $fault: "client";
  message: string | undefined;
}

export namespace LimitExceededException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: LimitExceededException): any => ({
    ...obj,
  })
}

export interface PreconditionFailedException extends __SmithyException, $MetadataBearer {
  name: "PreconditionFailedException";
  $fault: "client";
  message: string | undefined;
  resourceId: string | undefined;
  resourceArn: string | undefined;
}

export namespace PreconditionFailedException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PreconditionFailedException): any => ({
    ...obj,
  })
}

export interface ResourceAlreadyExistsException extends __SmithyException, $MetadataBearer {
  name: "ResourceAlreadyExistsException";
  $fault: "client";
  message: string | undefined;
  resourceId: string | undefined;
  resourceArn: string | undefined;
}

export namespace ResourceAlreadyExistsException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ResourceAlreadyExistsException): any => ({
    ...obj,
  })
}

export interface ResourceNotFoundException extends __SmithyException, $MetadataBearer {
  name: "ResourceNotFoundException";
  $fault: "client";
  message: string | undefined;
}

export namespace ResourceNotFoundException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ResourceNotFoundException): any => ({
    ...obj,
  })
}

export interface ThrottlingException extends __SmithyException, $MetadataBearer {
  name: "ThrottlingException";
  $fault: "client";
  message: string | undefined;
}

export namespace ThrottlingException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ThrottlingException): any => ({
    ...obj,
  })
}

export enum CapabilitySyncStatus {
  IN_SYNC = "IN_SYNC",
  OUT_OF_SYNC = "OUT_OF_SYNC",
  SYNC_FAILED = "SYNC_FAILED",
  UNKNOWN = "UNKNOWN",
}

export interface Greengrass {
  groupArn: string | undefined;
}

export namespace Greengrass {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Greengrass): any => ({
    ...obj,
  })
}

export interface GreengrassV2 {
  coreDeviceThingName: string | undefined;
}

export namespace GreengrassV2 {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: GreengrassV2): any => ({
    ...obj,
  })
}

export interface GatewayPlatform {
  greengrass?: Greengrass;
  greengrassV2?: GreengrassV2;
}

export namespace GatewayPlatform {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: GatewayPlatform): any => ({
    ...obj,
  })
}

export interface CreateGatewayRequest {
  gatewayName: string | undefined;
  gatewayPlatform: GatewayPlatform | undefined;
  tags?: { [key: string]: string };
}

export namespace CreateGatewayRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateGatewayRequest): any => ({
    ...obj,
  })
}

export interface CreateGatewayResponse {
  gatewayId: string | undefined;
  gatewayArn: string | undefined;
}

export namespace CreateGatewayResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateGatewayResponse): any => ({
    ...obj,
  })
}

export interface DeleteGatewayRequest {
  gatewayId: string | undefined;
}

export namespace DeleteGatewayRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteGatewayRequest): any => ({
    ...obj,
  })
}

export interface DescribeGatewayRequest {
  gatewayId: string | undefined;
}

export namespace DescribeGatewayRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeGatewayRequest): any => ({
    ...obj,
  })
}

export interface GatewayCapabilitySummary {
  capabilityNamespace: string | undefined;
  capabilitySyncStatus: CapabilitySyncStatus | string | undefined;
}

export namespace GatewayCapabilitySummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: GatewayCapabilitySummary): any => ({
    ...obj,
  })
}

export interface DescribeGatewayResponse {
  gatewayId: string | undefined;
  gatewayName: string | undefined;
  gatewayArn: string | undefined;
  gatewayPlatform?: GatewayPlatform;
  gatewayCapabilitySummaries: (GatewayCapabilitySummary)[] | undefined;
  creationDate: Date | undefined;
  lastUpdateDate: Date | undefined;
}

export namespace DescribeGatewayResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeGatewayResponse): any => ({
    ...obj,
  })
}

export interface DescribeGatewayCapabilityConfigurationRequest {
  gatewayId: string | undefined;
  capabilityNamespace: string | undefined;
}

export namespace DescribeGatewayCapabilityConfigurationRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeGatewayCapabilityConfigurationRequest): any => ({
    ...obj,
  })
}

export interface DescribeGatewayCapabilityConfigurationResponse {
  gatewayId: string | undefined;
  capabilityNamespace: string | undefined;
  capabilityConfiguration: string | undefined;
  capabilitySyncStatus: CapabilitySyncStatus | string | undefined;
}

export namespace DescribeGatewayCapabilityConfigurationResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeGatewayCapabilityConfigurationResponse): any => ({
    ...obj,
  })
}

export interface GatewaySummary {
  gatewayId: string | undefined;
  gatewayName: string | undefined;
  gatewayPlatform?: GatewayPlatform;
  gatewayCapabilitySummaries?: (GatewayCapabilitySummary)[];
  creationDate: Date | undefined;
  lastUpdateDate: Date | undefined;
}

export namespace GatewaySummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: GatewaySummary): any => ({
    ...obj,
  })
}

export interface ListGatewaysRequest {
  nextToken?: string;
  maxResults?: number;
}

export namespace ListGatewaysRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListGatewaysRequest): any => ({
    ...obj,
  })
}

export interface ListGatewaysResponse {
  gatewaySummaries: (GatewaySummary)[] | undefined;
  nextToken?: string;
}

export namespace ListGatewaysResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListGatewaysResponse): any => ({
    ...obj,
  })
}

export interface UpdateGatewayRequest {
  gatewayId: string | undefined;
  gatewayName: string | undefined;
}

export namespace UpdateGatewayRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateGatewayRequest): any => ({
    ...obj,
  })
}

export interface UpdateGatewayCapabilityConfigurationRequest {
  gatewayId: string | undefined;
  capabilityNamespace: string | undefined;
  capabilityConfiguration: string | undefined;
}

export namespace UpdateGatewayCapabilityConfigurationRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateGatewayCapabilityConfigurationRequest): any => ({
    ...obj,
  })
}

export interface UpdateGatewayCapabilityConfigurationResponse {
  capabilityNamespace: string | undefined;
  capabilitySyncStatus: CapabilitySyncStatus | string | undefined;
}

export namespace UpdateGatewayCapabilityConfigurationResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateGatewayCapabilityConfigurationResponse): any => ({
    ...obj,
  })
}

export interface ActionDefinition {
  actionDefinitionId: string | undefined;
  actionName: string | undefined;
  actionType: string | undefined;
}

export namespace ActionDefinition {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ActionDefinition): any => ({
    ...obj,
  })
}

export interface ActionPayload {
  stringValue: string | undefined;
}

export namespace ActionPayload {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ActionPayload): any => ({
    ...obj,
  })
}

export interface TargetResource {
  assetId: string | undefined;
}

export namespace TargetResource {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: TargetResource): any => ({
    ...obj,
  })
}

export interface ActionSummary {
  actionId?: string;
  actionDefinitionId?: string;
  targetResource?: TargetResource;
}

export namespace ActionSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ActionSummary): any => ({
    ...obj,
  })
}

export enum PropertyDataType {
  BOOLEAN = "BOOLEAN",
  DOUBLE = "DOUBLE",
  INTEGER = "INTEGER",
  STRING = "STRING",
  STRUCT = "STRUCT",
}

export enum PropertyNotificationState {
  DISABLED = "DISABLED",
  ENABLED = "ENABLED",
}

export interface PropertyNotification {
  topic: string | undefined;
  state: PropertyNotificationState | string | undefined;
}

export namespace PropertyNotification {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PropertyNotification): any => ({
    ...obj,
  })
}

export interface AssetPropertyPathSegment {
  id?: string;
  name?: string;
}

export namespace AssetPropertyPathSegment {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetPropertyPathSegment): any => ({
    ...obj,
  })
}

export interface AssetProperty {
  id: string | undefined;
  externalId?: string;
  name: string | undefined;
  alias?: string;
  notification?: PropertyNotification;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  unit?: string;
  path?: (AssetPropertyPathSegment)[];
}

export namespace AssetProperty {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetProperty): any => ({
    ...obj,
  })
}

export interface AssetCompositeModel {
  name: string | undefined;
  description?: string;
  type: string | undefined;
  properties: (AssetProperty)[] | undefined;
  id?: string;
  externalId?: string;
}

export namespace AssetCompositeModel {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetCompositeModel): any => ({
    ...obj,
  })
}

export interface AssetCompositeModelPathSegment {
  id?: string;
  name?: string;
}

export namespace AssetCompositeModelPathSegment {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetCompositeModelPathSegment): any => ({
    ...obj,
  })
}

export interface AssetCompositeModelSummary {
  id: string | undefined;
  externalId?: string;
  name: string | undefined;
  type: string | undefined;
  description: string | undefined;
  path: (AssetCompositeModelPathSegment)[] | undefined;
}

export namespace AssetCompositeModelSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetCompositeModelSummary): any => ({
    ...obj,
  })
}

export interface AssetHierarchy {
  id?: string;
  externalId?: string;
  name: string | undefined;
}

export namespace AssetHierarchy {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetHierarchy): any => ({
    ...obj,
  })
}

export interface AssetHierarchyInfo {
  parentAssetId?: string;
  childAssetId?: string;
}

export namespace AssetHierarchyInfo {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetHierarchyInfo): any => ({
    ...obj,
  })
}

export interface AssetModelPropertyPathSegment {
  id?: string;
  name?: string;
}

export namespace AssetModelPropertyPathSegment {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelPropertyPathSegment): any => ({
    ...obj,
  })
}

export interface Attribute {
  defaultValue?: string;
}

export namespace Attribute {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Attribute): any => ({
    ...obj,
  })
}

export enum ForwardingConfigState {
  DISABLED = "DISABLED",
  ENABLED = "ENABLED",
}

export interface ForwardingConfig {
  state: ForwardingConfigState | string | undefined;
}

export namespace ForwardingConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ForwardingConfig): any => ({
    ...obj,
  })
}

export interface MeasurementProcessingConfig {
  forwardingConfig: ForwardingConfig | undefined;
}

export namespace MeasurementProcessingConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: MeasurementProcessingConfig): any => ({
    ...obj,
  })
}

export interface Measurement {
  processingConfig?: MeasurementProcessingConfig;
}

export namespace Measurement {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Measurement): any => ({
    ...obj,
  })
}

export enum ComputeLocation {
  CLOUD = "CLOUD",
  EDGE = "EDGE",
}

export interface MetricProcessingConfig {
  computeLocation: ComputeLocation | string | undefined;
}

export namespace MetricProcessingConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: MetricProcessingConfig): any => ({
    ...obj,
  })
}

export interface VariableValue {
  propertyId?: string;
  hierarchyId?: string;
  propertyPath?: (AssetModelPropertyPathSegment)[];
}

export namespace VariableValue {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: VariableValue): any => ({
    ...obj,
  })
}

export interface ExpressionVariable {
  name: string | undefined;
  value: VariableValue | undefined;
}

export namespace ExpressionVariable {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ExpressionVariable): any => ({
    ...obj,
  })
}

export interface TumblingWindow {
  interval: string | undefined;
  offset?: string;
}

export namespace TumblingWindow {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: TumblingWindow): any => ({
    ...obj,
  })
}

export interface MetricWindow {
  tumbling?: TumblingWindow;
}

export namespace MetricWindow {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: MetricWindow): any => ({
    ...obj,
  })
}

export interface Metric {
  expression: string | undefined;
  variables: (ExpressionVariable)[] | undefined;
  window: MetricWindow | undefined;
  processingConfig?: MetricProcessingConfig;
}

export namespace Metric {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Metric): any => ({
    ...obj,
  })
}

export interface TransformProcessingConfig {
  computeLocation: ComputeLocation | string | undefined;
  forwardingConfig?: ForwardingConfig;
}

export namespace TransformProcessingConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: TransformProcessingConfig): any => ({
    ...obj,
  })
}

export interface Transform {
  expression: string | undefined;
  variables: (ExpressionVariable)[] | undefined;
  processingConfig?: TransformProcessingConfig;
}

export namespace Transform {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Transform): any => ({
    ...obj,
  })
}

export interface PropertyType {
  attribute?: Attribute;
  measurement?: Measurement;
  transform?: Transform;
  metric?: Metric;
}

export namespace PropertyType {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PropertyType): any => ({
    ...obj,
  })
}

export interface AssetModelProperty {
  id?: string;
  externalId?: string;
  name: string | undefined;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  unit?: string;
  type: PropertyType | undefined;
  path?: (AssetModelPropertyPathSegment)[];
}

export namespace AssetModelProperty {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelProperty): any => ({
    ...obj,
  })
}

export interface AssetModelCompositeModel {
  name: string | undefined;
  description?: string;
  type: string | undefined;
  properties?: (AssetModelProperty)[];
  id?: string;
  externalId?: string;
}

export namespace AssetModelCompositeModel {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelCompositeModel): any => ({
    ...obj,
  })
}

export interface AssetModelPropertyDefinition {
  id?: string;
  externalId?: string;
  name: string | undefined;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  unit?: string;
  type: PropertyType | undefined;
}

export namespace AssetModelPropertyDefinition {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelPropertyDefinition): any => ({
    ...obj,
  })
}

export interface AssetModelCompositeModelDefinition {
  id?: string;
  externalId?: string;
  name: string | undefined;
  description?: string;
  type: string | undefined;
  properties?: (AssetModelPropertyDefinition)[];
}

export namespace AssetModelCompositeModelDefinition {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelCompositeModelDefinition): any => ({
    ...obj,
  })
}

export interface AssetModelCompositeModelPathSegment {
  id?: string;
  name?: string;
}

export namespace AssetModelCompositeModelPathSegment {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelCompositeModelPathSegment): any => ({
    ...obj,
  })
}

export interface AssetModelCompositeModelSummary {
  id: string | undefined;
  externalId?: string;
  name: string | undefined;
  type: string | undefined;
  description?: string;
  path?: (AssetModelCompositeModelPathSegment)[];
}

export namespace AssetModelCompositeModelSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelCompositeModelSummary): any => ({
    ...obj,
  })
}

export interface AssetModelHierarchy {
  id?: string;
  externalId?: string;
  name: string | undefined;
  childAssetModelId: string | undefined;
}

export namespace AssetModelHierarchy {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelHierarchy): any => ({
    ...obj,
  })
}

export interface AssetModelHierarchyDefinition {
  id?: string;
  externalId?: string;
  name: string | undefined;
  childAssetModelId: string | undefined;
}

export namespace AssetModelHierarchyDefinition {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelHierarchyDefinition): any => ({
    ...obj,
  })
}

export interface AssetModelPropertySummary {
  id?: string;
  externalId?: string;
  name: string | undefined;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  unit?: string;
  type: PropertyType | undefined;
  assetModelCompositeModelId?: string;
  path?: (AssetModelPropertyPathSegment)[];
}

export namespace AssetModelPropertySummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelPropertySummary): any => ({
    ...obj,
  })
}

export enum AssetModelState {
  ACTIVE = "ACTIVE",
  CREATING = "CREATING",
  DELETING = "DELETING",
  FAILED = "FAILED",
  PROPAGATING = "PROPAGATING",
  UPDATING = "UPDATING",
}

export enum ErrorCode {
  INTERNAL_FAILURE = "INTERNAL_FAILURE",
  VALIDATION_ERROR = "VALIDATION_ERROR",
}

export enum DetailedErrorCode {
  INCOMPATIBLE_COMPUTE_LOCATION = "INCOMPATIBLE_COMPUTE_LOCATION",
  INCOMPATIBLE_FORWARDING_CONFIGURATION = "INCOMPATIBLE_FORWARDING_CONFIGURATION",
}

export interface DetailedError {
  code: DetailedErrorCode | string | undefined;
  message: string | undefined;
}

export namespace DetailedError {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DetailedError): any => ({
    ...obj,
  })
}

export interface ErrorDetails {
  code: ErrorCode | string | undefined;
  message: string | undefined;
  details?: (DetailedError)[];
}

export namespace ErrorDetails {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ErrorDetails): any => ({
    ...obj,
  })
}

export interface AssetModelStatus {
  state: AssetModelState | string | undefined;
  error?: ErrorDetails;
}

export namespace AssetModelStatus {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelStatus): any => ({
    ...obj,
  })
}

export enum AssetModelType {
  ASSET_MODEL = "ASSET_MODEL",
  COMPONENT_MODEL = "COMPONENT_MODEL",
}

export interface AssetModelSummary {
  id: string | undefined;
  externalId?: string;
  arn: string | undefined;
  name: string | undefined;
  assetModelType?: AssetModelType | string;
  description: string | undefined;
  creationDate: Date | undefined;
  lastUpdateDate: Date | undefined;
  status: AssetModelStatus | undefined;
}

export namespace AssetModelSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetModelSummary): any => ({
    ...obj,
  })
}

export interface AssetPropertySummary {
  id: string | undefined;
  externalId?: string;
  alias?: string;
  unit?: string;
  notification?: PropertyNotification;
  assetCompositeModelId?: string;
  path?: (AssetPropertyPathSegment)[];
}

export namespace AssetPropertySummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetPropertySummary): any => ({
    ...obj,
  })
}

export enum AssetRelationshipType {
  HIERARCHY = "HIERARCHY",
}

export interface AssetRelationshipSummary {
  hierarchyInfo?: AssetHierarchyInfo;
  relationshipType: AssetRelationshipType | string | undefined;
}

export namespace AssetRelationshipSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetRelationshipSummary): any => ({
    ...obj,
  })
}

export enum AssetState {
  ACTIVE = "ACTIVE",
  CREATING = "CREATING",
  DELETING = "DELETING",
  FAILED = "FAILED",
  UPDATING = "UPDATING",
}

export interface AssetStatus {
  state: AssetState | string | undefined;
  error?: ErrorDetails;
}

export namespace AssetStatus {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetStatus): any => ({
    ...obj,
  })
}

export interface AssetSummary {
  id: string | undefined;
  externalId?: string;
  arn: string | undefined;
  name: string | undefined;
  assetModelId: string | undefined;
  creationDate: Date | undefined;
  lastUpdateDate: Date | undefined;
  status: AssetStatus | undefined;
  hierarchies: (AssetHierarchy)[] | undefined;
  description?: string;
}

export namespace AssetSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetSummary): any => ({
    ...obj,
  })
}

export interface AssociateAssetsRequest {
  assetId: string | undefined;
  hierarchyId: string | undefined;
  childAssetId: string | undefined;
  clientToken?: string;
}

export namespace AssociateAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssociateAssetsRequest): any => ({
    ...obj,
  })
}

export interface AssociatedAssetsSummary {
  id: string | undefined;
  externalId?: string;
  arn: string | undefined;
  name: string | undefined;
  assetModelId: string | undefined;
  creationDate: Date | undefined;
  lastUpdateDate: Date | undefined;
  status: AssetStatus | undefined;
  hierarchies: (AssetHierarchy)[] | undefined;
  description?: string;
}

export namespace AssociatedAssetsSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssociatedAssetsSummary): any => ({
    ...obj,
  })
}

export interface AssociateTimeSeriesToAssetPropertyRequest {
  alias: string | undefined;
  assetId: string | undefined;
  propertyId: string | undefined;
  clientToken?: string;
}

export namespace AssociateTimeSeriesToAssetPropertyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssociateTimeSeriesToAssetPropertyRequest): any => ({
    ...obj,
  })
}

export interface Property {
  id: string | undefined;
  externalId?: string;
  name: string | undefined;
  alias?: string;
  notification?: PropertyNotification;
  dataType: PropertyDataType | string | undefined;
  unit?: string;
  type?: PropertyType;
  path?: (AssetPropertyPathSegment)[];
}

export namespace Property {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Property): any => ({
    ...obj,
  })
}

export interface CompositeModelProperty {
  name: string | undefined;
  type: string | undefined;
  assetProperty: Property | undefined;
  id?: string;
  externalId?: string;
}

export namespace CompositeModelProperty {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CompositeModelProperty): any => ({
    ...obj,
  })
}

export interface CompositionRelationshipItem {
  id?: string;
}

export namespace CompositionRelationshipItem {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CompositionRelationshipItem): any => ({
    ...obj,
  })
}

export interface CompositionDetails {
  compositionRelationship?: (CompositionRelationshipItem)[];
}

export namespace CompositionDetails {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CompositionDetails): any => ({
    ...obj,
  })
}

export interface CompositionRelationshipSummary {
  assetModelId: string | undefined;
  assetModelCompositeModelId: string | undefined;
  assetModelCompositeModelType: string | undefined;
}

export namespace CompositionRelationshipSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CompositionRelationshipSummary): any => ({
    ...obj,
  })
}

export interface CreateAssetRequest {
  assetName: string | undefined;
  assetModelId: string | undefined;
  assetId?: string;
  assetExternalId?: string;
  clientToken?: string;
  tags?: { [key: string]: string };
  assetDescription?: string;
}

export namespace CreateAssetRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetRequest): any => ({
    ...obj,
  })
}

export interface CreateAssetResponse {
  assetId: string | undefined;
  assetArn: string | undefined;
  assetStatus: AssetStatus | undefined;
}

export namespace CreateAssetResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetResponse): any => ({
    ...obj,
  })
}

export interface CreateAssetModelRequest {
  assetModelName: string | undefined;
  assetModelType?: AssetModelType | string;
  assetModelId?: string;
  assetModelExternalId?: string;
  assetModelDescription?: string;
  assetModelProperties?: (AssetModelPropertyDefinition)[];
  assetModelHierarchies?: (AssetModelHierarchyDefinition)[];
  assetModelCompositeModels?: (AssetModelCompositeModelDefinition)[];
  clientToken?: string;
  tags?: { [key: string]: string };
}

export namespace CreateAssetModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetModelRequest): any => ({
    ...obj,
  })
}

export interface CreateAssetModelResponse {
  assetModelId: string | undefined;
  assetModelArn: string | undefined;
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace CreateAssetModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetModelResponse): any => ({
    ...obj,
  })
}

export interface CreateAssetModelCompositeModelRequest {
  assetModelId: string | undefined;
  assetModelCompositeModelExternalId?: string;
  parentAssetModelCompositeModelId?: string;
  assetModelCompositeModelId?: string;
  assetModelCompositeModelDescription?: string;
  assetModelCompositeModelName: string | undefined;
  assetModelCompositeModelType: string | undefined;
  clientToken?: string;
  composedAssetModelId?: string;
  assetModelCompositeModelProperties?: (AssetModelPropertyDefinition)[];
}

export namespace CreateAssetModelCompositeModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetModelCompositeModelRequest): any => ({
    ...obj,
  })
}

export interface CreateAssetModelCompositeModelResponse {
  assetModelCompositeModelId: string | undefined;
  assetModelCompositeModelPath: (AssetModelCompositeModelPathSegment)[] | undefined;
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace CreateAssetModelCompositeModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAssetModelCompositeModelResponse): any => ({
    ...obj,
  })
}

export interface DeleteAssetRequest {
  assetId: string | undefined;
  clientToken?: string;
}

export namespace DeleteAssetRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetRequest): any => ({
    ...obj,
  })
}

export interface DeleteAssetResponse {
  assetStatus: AssetStatus | undefined;
}

export namespace DeleteAssetResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetResponse): any => ({
    ...obj,
  })
}

export interface DeleteAssetModelRequest {
  assetModelId: string | undefined;
  clientToken?: string;
}

export namespace DeleteAssetModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetModelRequest): any => ({
    ...obj,
  })
}

export interface DeleteAssetModelResponse {
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace DeleteAssetModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetModelResponse): any => ({
    ...obj,
  })
}

export interface DeleteAssetModelCompositeModelRequest {
  assetModelId: string | undefined;
  assetModelCompositeModelId: string | undefined;
  clientToken?: string;
}

export namespace DeleteAssetModelCompositeModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetModelCompositeModelRequest): any => ({
    ...obj,
  })
}

export interface DeleteAssetModelCompositeModelResponse {
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace DeleteAssetModelCompositeModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAssetModelCompositeModelResponse): any => ({
    ...obj,
  })
}

export interface DeleteTimeSeriesRequest {
  alias?: string;
  assetId?: string;
  propertyId?: string;
  clientToken?: string;
}

export namespace DeleteTimeSeriesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteTimeSeriesRequest): any => ({
    ...obj,
  })
}

export interface DescribeActionRequest {
  actionId: string | undefined;
}

export namespace DescribeActionRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeActionRequest): any => ({
    ...obj,
  })
}

export interface DescribeActionResponse {
  actionId: string | undefined;
  targetResource: TargetResource | undefined;
  actionDefinitionId: string | undefined;
  actionPayload: ActionPayload | undefined;
  executionTime: Date | undefined;
}

export namespace DescribeActionResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeActionResponse): any => ({
    ...obj,
  })
}

export interface DescribeAssetRequest {
  assetId: string | undefined;
  excludeProperties?: boolean;
}

export namespace DescribeAssetRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetRequest): any => ({
    ...obj,
  })
}

export interface DescribeAssetResponse {
  assetId: string | undefined;
  assetExternalId?: string;
  assetArn: string | undefined;
  assetName: string | undefined;
  assetModelId: string | undefined;
  assetProperties: (AssetProperty)[] | undefined;
  assetHierarchies: (AssetHierarchy)[] | undefined;
  assetCompositeModels?: (AssetCompositeModel)[];
  assetCreationDate: Date | undefined;
  assetLastUpdateDate: Date | undefined;
  assetStatus: AssetStatus | undefined;
  assetDescription?: string;
  assetCompositeModelSummaries?: (AssetCompositeModelSummary)[];
}

export namespace DescribeAssetResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetResponse): any => ({
    ...obj,
  })
}

export interface DescribeAssetCompositeModelRequest {
  assetId: string | undefined;
  assetCompositeModelId: string | undefined;
}

export namespace DescribeAssetCompositeModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetCompositeModelRequest): any => ({
    ...obj,
  })
}

export interface DescribeAssetCompositeModelResponse {
  assetId: string | undefined;
  assetCompositeModelId: string | undefined;
  assetCompositeModelExternalId?: string;
  assetCompositeModelPath: (AssetCompositeModelPathSegment)[] | undefined;
  assetCompositeModelName: string | undefined;
  assetCompositeModelDescription: string | undefined;
  assetCompositeModelType: string | undefined;
  assetCompositeModelProperties: (AssetProperty)[] | undefined;
  assetCompositeModelSummaries: (AssetCompositeModelSummary)[] | undefined;
  actionDefinitions?: (ActionDefinition)[];
}

export namespace DescribeAssetCompositeModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetCompositeModelResponse): any => ({
    ...obj,
  })
}

export interface DescribeAssetModelRequest {
  assetModelId: string | undefined;
  excludeProperties?: boolean;
}

export namespace DescribeAssetModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetModelRequest): any => ({
    ...obj,
  })
}

export interface DescribeAssetModelResponse {
  assetModelId: string | undefined;
  assetModelExternalId?: string;
  assetModelArn: string | undefined;
  assetModelName: string | undefined;
  assetModelType?: AssetModelType | string;
  assetModelDescription: string | undefined;
  assetModelProperties: (AssetModelProperty)[] | undefined;
  assetModelHierarchies: (AssetModelHierarchy)[] | undefined;
  assetModelCompositeModels?: (AssetModelCompositeModel)[];
  assetModelCompositeModelSummaries?: (AssetModelCompositeModelSummary)[];
  assetModelCreationDate: Date | undefined;
  assetModelLastUpdateDate: Date | undefined;
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace DescribeAssetModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetModelResponse): any => ({
    ...obj,
  })
}

export interface DescribeAssetModelCompositeModelRequest {
  assetModelId: string | undefined;
  assetModelCompositeModelId: string | undefined;
}

export namespace DescribeAssetModelCompositeModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetModelCompositeModelRequest): any => ({
    ...obj,
  })
}

export interface DescribeAssetModelCompositeModelResponse {
  assetModelId: string | undefined;
  assetModelCompositeModelId: string | undefined;
  assetModelCompositeModelExternalId?: string;
  assetModelCompositeModelPath: (AssetModelCompositeModelPathSegment)[] | undefined;
  assetModelCompositeModelName: string | undefined;
  assetModelCompositeModelDescription: string | undefined;
  assetModelCompositeModelType: string | undefined;
  assetModelCompositeModelProperties: (AssetModelProperty)[] | undefined;
  compositionDetails?: CompositionDetails;
  assetModelCompositeModelSummaries: (AssetModelCompositeModelSummary)[] | undefined;
  actionDefinitions?: (ActionDefinition)[];
}

export namespace DescribeAssetModelCompositeModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetModelCompositeModelResponse): any => ({
    ...obj,
  })
}

export interface DescribeAssetPropertyRequest {
  assetId: string | undefined;
  propertyId: string | undefined;
}

export namespace DescribeAssetPropertyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetPropertyRequest): any => ({
    ...obj,
  })
}

export interface DescribeAssetPropertyResponse {
  assetId: string | undefined;
  assetExternalId?: string;
  assetName: string | undefined;
  assetModelId: string | undefined;
  assetProperty?: Property;
  compositeModel?: CompositeModelProperty;
}

export namespace DescribeAssetPropertyResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAssetPropertyResponse): any => ({
    ...obj,
  })
}

export interface DescribeLoggingOptionsRequest {
}

export namespace DescribeLoggingOptionsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeLoggingOptionsRequest): any => ({
    ...obj,
  })
}

export enum LoggingLevel {
  ERROR = "ERROR",
  INFO = "INFO",
  OFF = "OFF",
}

export interface LoggingOptions {
  level: LoggingLevel | string | undefined;
}

export namespace LoggingOptions {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: LoggingOptions): any => ({
    ...obj,
  })
}

export interface DescribeLoggingOptionsResponse {
  loggingOptions: LoggingOptions | undefined;
}

export namespace DescribeLoggingOptionsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeLoggingOptionsResponse): any => ({
    ...obj,
  })
}

export interface DescribeTimeSeriesRequest {
  alias?: string;
  assetId?: string;
  propertyId?: string;
}

export namespace DescribeTimeSeriesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeTimeSeriesRequest): any => ({
    ...obj,
  })
}

export interface DescribeTimeSeriesResponse {
  assetId?: string;
  propertyId?: string;
  alias?: string;
  timeSeriesId: string | undefined;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  timeSeriesCreationDate: Date | undefined;
  timeSeriesLastUpdateDate: Date | undefined;
  timeSeriesArn: string | undefined;
}

export namespace DescribeTimeSeriesResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeTimeSeriesResponse): any => ({
    ...obj,
  })
}

export interface DisassociateAssetsRequest {
  assetId: string | undefined;
  hierarchyId: string | undefined;
  childAssetId: string | undefined;
  clientToken?: string;
}

export namespace DisassociateAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DisassociateAssetsRequest): any => ({
    ...obj,
  })
}

export interface DisassociateTimeSeriesFromAssetPropertyRequest {
  alias: string | undefined;
  assetId: string | undefined;
  propertyId: string | undefined;
  clientToken?: string;
}

export namespace DisassociateTimeSeriesFromAssetPropertyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DisassociateTimeSeriesFromAssetPropertyRequest): any => ({
    ...obj,
  })
}

export interface ExecuteActionRequest {
  targetResource: TargetResource | undefined;
  actionDefinitionId: string | undefined;
  actionPayload: ActionPayload | undefined;
  clientToken?: string;
}

export namespace ExecuteActionRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ExecuteActionRequest): any => ({
    ...obj,
  })
}

export interface ExecuteActionResponse {
  actionId: string | undefined;
}

export namespace ExecuteActionResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ExecuteActionResponse): any => ({
    ...obj,
  })
}

export enum TargetResourceType {
  ASSET = "ASSET",
}

export interface ListActionsRequest {
  targetResourceType: TargetResourceType | string | undefined;
  targetResourceId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListActionsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListActionsRequest): any => ({
    ...obj,
  })
}

export interface ListActionsResponse {
  actionSummaries: (ActionSummary)[] | undefined;
  nextToken: string | undefined;
}

export namespace ListActionsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListActionsResponse): any => ({
    ...obj,
  })
}

export interface ListAssetModelCompositeModelsRequest {
  assetModelId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListAssetModelCompositeModelsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelCompositeModelsRequest): any => ({
    ...obj,
  })
}

export interface ListAssetModelCompositeModelsResponse {
  assetModelCompositeModelSummaries: (AssetModelCompositeModelSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetModelCompositeModelsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelCompositeModelsResponse): any => ({
    ...obj,
  })
}

export enum ListAssetModelPropertiesFilter {
  ALL = "ALL",
  BASE = "BASE",
}

export interface ListAssetModelPropertiesRequest {
  assetModelId: string | undefined;
  nextToken?: string;
  maxResults?: number;
  filter?: ListAssetModelPropertiesFilter | string;
}

export namespace ListAssetModelPropertiesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelPropertiesRequest): any => ({
    ...obj,
  })
}

export interface ListAssetModelPropertiesResponse {
  assetModelPropertySummaries: (AssetModelPropertySummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetModelPropertiesResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelPropertiesResponse): any => ({
    ...obj,
  })
}

export interface ListAssetModelsRequest {
  assetModelTypes?: (AssetModelType | string)[];
  nextToken?: string;
  maxResults?: number;
}

export namespace ListAssetModelsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelsRequest): any => ({
    ...obj,
  })
}

export interface ListAssetModelsResponse {
  assetModelSummaries: (AssetModelSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetModelsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetModelsResponse): any => ({
    ...obj,
  })
}

export enum ListAssetPropertiesFilter {
  ALL = "ALL",
  BASE = "BASE",
}

export interface ListAssetPropertiesRequest {
  assetId: string | undefined;
  nextToken?: string;
  maxResults?: number;
  filter?: ListAssetPropertiesFilter | string;
}

export namespace ListAssetPropertiesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetPropertiesRequest): any => ({
    ...obj,
  })
}

export interface ListAssetPropertiesResponse {
  assetPropertySummaries: (AssetPropertySummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetPropertiesResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetPropertiesResponse): any => ({
    ...obj,
  })
}

export enum TraversalType {
  PATH_TO_ROOT = "PATH_TO_ROOT",
}

export interface ListAssetRelationshipsRequest {
  assetId: string | undefined;
  traversalType: TraversalType | string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListAssetRelationshipsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetRelationshipsRequest): any => ({
    ...obj,
  })
}

export interface ListAssetRelationshipsResponse {
  assetRelationshipSummaries: (AssetRelationshipSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetRelationshipsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetRelationshipsResponse): any => ({
    ...obj,
  })
}

export enum ListAssetsFilter {
  ALL = "ALL",
  TOP_LEVEL = "TOP_LEVEL",
}

export interface ListAssetsRequest {
  nextToken?: string;
  maxResults?: number;
  assetModelId?: string;
  filter?: ListAssetsFilter | string;
}

export namespace ListAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetsRequest): any => ({
    ...obj,
  })
}

export interface ListAssetsResponse {
  assetSummaries: (AssetSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssetsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssetsResponse): any => ({
    ...obj,
  })
}

export enum TraversalDirection {
  CHILD = "CHILD",
  PARENT = "PARENT",
}

export interface ListAssociatedAssetsRequest {
  assetId: string | undefined;
  hierarchyId?: string;
  traversalDirection?: TraversalDirection | string;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListAssociatedAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssociatedAssetsRequest): any => ({
    ...obj,
  })
}

export interface ListAssociatedAssetsResponse {
  assetSummaries: (AssociatedAssetsSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAssociatedAssetsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAssociatedAssetsResponse): any => ({
    ...obj,
  })
}

export interface ListCompositionRelationshipsRequest {
  assetModelId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListCompositionRelationshipsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListCompositionRelationshipsRequest): any => ({
    ...obj,
  })
}

export interface ListCompositionRelationshipsResponse {
  compositionRelationshipSummaries: (CompositionRelationshipSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListCompositionRelationshipsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListCompositionRelationshipsResponse): any => ({
    ...obj,
  })
}

export enum ListTimeSeriesType {
  ASSOCIATED = "ASSOCIATED",
  DISASSOCIATED = "DISASSOCIATED",
}

export interface ListTimeSeriesRequest {
  nextToken?: string;
  maxResults?: number;
  assetId?: string;
  aliasPrefix?: string;
  timeSeriesType?: ListTimeSeriesType | string;
}

export namespace ListTimeSeriesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListTimeSeriesRequest): any => ({
    ...obj,
  })
}

export interface TimeSeriesSummary {
  assetId?: string;
  propertyId?: string;
  alias?: string;
  timeSeriesId: string | undefined;
  dataType: PropertyDataType | string | undefined;
  dataTypeSpec?: string;
  timeSeriesCreationDate: Date | undefined;
  timeSeriesLastUpdateDate: Date | undefined;
  timeSeriesArn: string | undefined;
}

export namespace TimeSeriesSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: TimeSeriesSummary): any => ({
    ...obj,
  })
}

export interface ListTimeSeriesResponse {
  TimeSeriesSummaries: (TimeSeriesSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListTimeSeriesResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListTimeSeriesResponse): any => ({
    ...obj,
  })
}

export interface PutLoggingOptionsRequest {
  loggingOptions: LoggingOptions | undefined;
}

export namespace PutLoggingOptionsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PutLoggingOptionsRequest): any => ({
    ...obj,
  })
}

export interface PutLoggingOptionsResponse {
}

export namespace PutLoggingOptionsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PutLoggingOptionsResponse): any => ({
    ...obj,
  })
}

export interface UpdateAssetRequest {
  assetId: string | undefined;
  assetExternalId?: string;
  assetName: string | undefined;
  clientToken?: string;
  assetDescription?: string;
}

export namespace UpdateAssetRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetRequest): any => ({
    ...obj,
  })
}

export interface UpdateAssetResponse {
  assetStatus: AssetStatus | undefined;
}

export namespace UpdateAssetResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetResponse): any => ({
    ...obj,
  })
}

export interface UpdateAssetModelRequest {
  assetModelId: string | undefined;
  assetModelExternalId?: string;
  assetModelName: string | undefined;
  assetModelDescription?: string;
  assetModelProperties?: (AssetModelProperty)[];
  assetModelHierarchies?: (AssetModelHierarchy)[];
  assetModelCompositeModels?: (AssetModelCompositeModel)[];
  clientToken?: string;
}

export namespace UpdateAssetModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetModelRequest): any => ({
    ...obj,
  })
}

export interface UpdateAssetModelResponse {
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace UpdateAssetModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetModelResponse): any => ({
    ...obj,
  })
}

export interface UpdateAssetModelCompositeModelRequest {
  assetModelId: string | undefined;
  assetModelCompositeModelId: string | undefined;
  assetModelCompositeModelExternalId?: string;
  assetModelCompositeModelDescription?: string;
  assetModelCompositeModelName: string | undefined;
  clientToken?: string;
  assetModelCompositeModelProperties?: (AssetModelProperty)[];
}

export namespace UpdateAssetModelCompositeModelRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetModelCompositeModelRequest): any => ({
    ...obj,
  })
}

export interface UpdateAssetModelCompositeModelResponse {
  assetModelCompositeModelPath: (AssetModelCompositeModelPathSegment)[] | undefined;
  assetModelStatus: AssetModelStatus | undefined;
}

export namespace UpdateAssetModelCompositeModelResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetModelCompositeModelResponse): any => ({
    ...obj,
  })
}

export interface UpdateAssetPropertyRequest {
  assetId: string | undefined;
  propertyId: string | undefined;
  propertyAlias?: string;
  propertyNotificationState?: PropertyNotificationState | string;
  clientToken?: string;
  propertyUnit?: string;
}

export namespace UpdateAssetPropertyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAssetPropertyRequest): any => ({
    ...obj,
  })
}

export interface GroupIdentity {
  id: string | undefined;
}

export namespace GroupIdentity {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: GroupIdentity): any => ({
    ...obj,
  })
}

export interface IAMRoleIdentity {
  arn: string | undefined;
}

export namespace IAMRoleIdentity {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: IAMRoleIdentity): any => ({
    ...obj,
  })
}

export interface IAMUserIdentity {
  arn: string | undefined;
}

export namespace IAMUserIdentity {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: IAMUserIdentity): any => ({
    ...obj,
  })
}

export interface UserIdentity {
  id: string | undefined;
}

export namespace UserIdentity {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UserIdentity): any => ({
    ...obj,
  })
}

export interface Identity {
  user?: UserIdentity;
  group?: GroupIdentity;
  iamUser?: IAMUserIdentity;
  iamRole?: IAMRoleIdentity;
}

export namespace Identity {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Identity): any => ({
    ...obj,
  })
}

export enum Permission {
  ADMINISTRATOR = "ADMINISTRATOR",
  VIEWER = "VIEWER",
}

export interface PortalResource {
  id: string | undefined;
}

export namespace PortalResource {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PortalResource): any => ({
    ...obj,
  })
}

export interface ProjectResource {
  id: string | undefined;
}

export namespace ProjectResource {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ProjectResource): any => ({
    ...obj,
  })
}

export interface Resource {
  portal?: PortalResource;
  project?: ProjectResource;
}

export namespace Resource {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Resource): any => ({
    ...obj,
  })
}

export interface AccessPolicySummary {
  id: string | undefined;
  identity: Identity | undefined;
  resource: Resource | undefined;
  permission: Permission | string | undefined;
  creationDate?: Date;
  lastUpdateDate?: Date;
}

export namespace AccessPolicySummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AccessPolicySummary): any => ({
    ...obj,
  })
}

export interface Alarms {
  alarmRoleArn: string | undefined;
  notificationLambdaArn?: string;
}

export namespace Alarms {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Alarms): any => ({
    ...obj,
  })
}

export enum AssetErrorCode {
  INTERNAL_FAILURE = "INTERNAL_FAILURE",
}

export interface AssetErrorDetails {
  assetId: string | undefined;
  code: AssetErrorCode | string | undefined;
  message: string | undefined;
}

export namespace AssetErrorDetails {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: AssetErrorDetails): any => ({
    ...obj,
  })
}

export enum AuthMode {
  IAM = "IAM",
  SSO = "SSO",
}

export interface BatchAssociateProjectAssetsRequest {
  projectId: string | undefined;
  assetIds: (string)[] | undefined;
  clientToken?: string;
}

export namespace BatchAssociateProjectAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: BatchAssociateProjectAssetsRequest): any => ({
    ...obj,
  })
}

export interface BatchAssociateProjectAssetsResponse {
  errors?: (AssetErrorDetails)[];
}

export namespace BatchAssociateProjectAssetsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: BatchAssociateProjectAssetsResponse): any => ({
    ...obj,
  })
}

export interface BatchDisassociateProjectAssetsRequest {
  projectId: string | undefined;
  assetIds: (string)[] | undefined;
  clientToken?: string;
}

export namespace BatchDisassociateProjectAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: BatchDisassociateProjectAssetsRequest): any => ({
    ...obj,
  })
}

export interface BatchDisassociateProjectAssetsResponse {
  errors?: (AssetErrorDetails)[];
}

export namespace BatchDisassociateProjectAssetsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: BatchDisassociateProjectAssetsResponse): any => ({
    ...obj,
  })
}

export interface CreateAccessPolicyRequest {
  accessPolicyIdentity: Identity | undefined;
  accessPolicyResource: Resource | undefined;
  accessPolicyPermission: Permission | string | undefined;
  clientToken?: string;
  tags?: { [key: string]: string };
}

export namespace CreateAccessPolicyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAccessPolicyRequest): any => ({
    ...obj,
  })
}

export interface CreateAccessPolicyResponse {
  accessPolicyId: string | undefined;
  accessPolicyArn: string | undefined;
}

export namespace CreateAccessPolicyResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateAccessPolicyResponse): any => ({
    ...obj,
  })
}

export interface CreateDashboardRequest {
  projectId: string | undefined;
  dashboardName: string | undefined;
  dashboardDescription?: string;
  dashboardDefinition: string | undefined;
  clientToken?: string;
  tags?: { [key: string]: string };
}

export namespace CreateDashboardRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateDashboardRequest): any => ({
    ...obj,
  })
}

export interface CreateDashboardResponse {
  dashboardId: string | undefined;
  dashboardArn: string | undefined;
}

export namespace CreateDashboardResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateDashboardResponse): any => ({
    ...obj,
  })
}

export enum PortalEdgeAccessState {
  DISABLED = "DISABLED",
  ENABLED = "ENABLED",
}

export interface PortalEdgeConfig {
  edgeAccess?: PortalEdgeAccessState | string;
}

export namespace PortalEdgeConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PortalEdgeConfig): any => ({
    ...obj,
  })
}

export enum ImageFileType {
  PNG = "PNG",
}

export interface ImageFile {
  data: Uint8Array | undefined;
  type: ImageFileType | string | undefined;
}

export namespace ImageFile {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ImageFile): any => ({
    ...obj,
  })
}

export enum ProjectSharingStatus {
  DISABLED = "DISABLED",
  ENABLED = "ENABLED",
}

export interface CreatePortalRequest {
  portalName: string | undefined;
  portalDescription?: string;
  portalContactEmail: string | undefined;
  clientToken?: string;
  portalLogoImageFile?: ImageFile;
  roleArn: string | undefined;
  tags?: { [key: string]: string };
  portalAuthMode?: AuthMode | string;
  notificationSenderEmail?: string;
  alarms?: Alarms;
  edgeConfig?: PortalEdgeConfig;
  projectPublicSharing?: ProjectSharingStatus | string;
}

export namespace CreatePortalRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreatePortalRequest): any => ({
    ...obj,
  })
}

export enum MonitorErrorCode {
  INTERNAL_FAILURE = "INTERNAL_FAILURE",
  LIMIT_EXCEEDED = "LIMIT_EXCEEDED",
  VALIDATION_ERROR = "VALIDATION_ERROR",
}

export interface MonitorErrorDetails {
  code?: MonitorErrorCode | string;
  message?: string;
}

export namespace MonitorErrorDetails {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: MonitorErrorDetails): any => ({
    ...obj,
  })
}

export enum PortalState {
  ACTIVE = "ACTIVE",
  CREATING = "CREATING",
  DELETING = "DELETING",
  FAILED = "FAILED",
  PENDING = "PENDING",
  UPDATING = "UPDATING",
}

export interface PortalStatus {
  state: PortalState | string | undefined;
  error?: MonitorErrorDetails;
}

export namespace PortalStatus {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PortalStatus): any => ({
    ...obj,
  })
}

export interface CreatePortalResponse {
  portalId: string | undefined;
  portalArn: string | undefined;
  portalStartUrl: string | undefined;
  portalStatus: PortalStatus | undefined;
  ssoApplicationId: string | undefined;
}

export namespace CreatePortalResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreatePortalResponse): any => ({
    ...obj,
  })
}

export enum ProjectSharingScope {
  PUBLIC = "PUBLIC",
}

export interface ProjectSharingConfig {
  sharingScope: ProjectSharingScope | string | undefined;
  status?: ProjectSharingStatus | string;
  sharingAlias: string | undefined;
  expirationTime: number | undefined;
  sharingId?: string;
  sharingUrl?: string;
}

export namespace ProjectSharingConfig {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ProjectSharingConfig): any => ({
    ...obj,
  })
}

export interface CreateProjectRequest {
  portalId: string | undefined;
  projectName: string | undefined;
  projectDescription?: string;
  clientToken?: string;
  tags?: { [key: string]: string };
  projectSharing?: (ProjectSharingConfig)[];
}

export namespace CreateProjectRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateProjectRequest): any => ({
    ...obj,
  })
}

export interface CreateProjectResponse {
  projectId: string | undefined;
  projectArn: string | undefined;
}

export namespace CreateProjectResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: CreateProjectResponse): any => ({
    ...obj,
  })
}

export interface DashboardSummary {
  id: string | undefined;
  name: string | undefined;
  description?: string;
  creationDate?: Date;
  lastUpdateDate?: Date;
}

export namespace DashboardSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DashboardSummary): any => ({
    ...obj,
  })
}

export interface DeleteAccessPolicyRequest {
  accessPolicyId: string | undefined;
  clientToken?: string;
}

export namespace DeleteAccessPolicyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAccessPolicyRequest): any => ({
    ...obj,
  })
}

export interface DeleteAccessPolicyResponse {
}

export namespace DeleteAccessPolicyResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteAccessPolicyResponse): any => ({
    ...obj,
  })
}

export interface DeleteDashboardRequest {
  dashboardId: string | undefined;
  clientToken?: string;
}

export namespace DeleteDashboardRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteDashboardRequest): any => ({
    ...obj,
  })
}

export interface DeleteDashboardResponse {
}

export namespace DeleteDashboardResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteDashboardResponse): any => ({
    ...obj,
  })
}

export interface DeletePortalRequest {
  portalId: string | undefined;
  clientToken?: string;
}

export namespace DeletePortalRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeletePortalRequest): any => ({
    ...obj,
  })
}

export interface DeletePortalResponse {
  portalStatus: PortalStatus | undefined;
}

export namespace DeletePortalResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeletePortalResponse): any => ({
    ...obj,
  })
}

export interface DeleteProjectRequest {
  projectId: string | undefined;
  clientToken?: string;
}

export namespace DeleteProjectRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteProjectRequest): any => ({
    ...obj,
  })
}

export interface DeleteProjectResponse {
}

export namespace DeleteProjectResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DeleteProjectResponse): any => ({
    ...obj,
  })
}

export interface DescribeAccessPolicyRequest {
  accessPolicyId: string | undefined;
}

export namespace DescribeAccessPolicyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAccessPolicyRequest): any => ({
    ...obj,
  })
}

export interface DescribeAccessPolicyResponse {
  accessPolicyId: string | undefined;
  accessPolicyArn: string | undefined;
  accessPolicyIdentity: Identity | undefined;
  accessPolicyResource: Resource | undefined;
  accessPolicyPermission: Permission | string | undefined;
  accessPolicyCreationDate: Date | undefined;
  accessPolicyLastUpdateDate: Date | undefined;
}

export namespace DescribeAccessPolicyResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeAccessPolicyResponse): any => ({
    ...obj,
  })
}

export interface DescribeDashboardRequest {
  dashboardId: string | undefined;
}

export namespace DescribeDashboardRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeDashboardRequest): any => ({
    ...obj,
  })
}

export interface DescribeDashboardResponse {
  dashboardId: string | undefined;
  dashboardArn: string | undefined;
  dashboardName: string | undefined;
  projectId: string | undefined;
  dashboardDescription?: string;
  dashboardDefinition: string | undefined;
  dashboardCreationDate: Date | undefined;
  dashboardLastUpdateDate: Date | undefined;
}

export namespace DescribeDashboardResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeDashboardResponse): any => ({
    ...obj,
  })
}

export interface DescribePortalRequest {
  portalId: string | undefined;
}

export namespace DescribePortalRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribePortalRequest): any => ({
    ...obj,
  })
}

export interface ImageLocation {
  id: string | undefined;
  url: string | undefined;
}

export namespace ImageLocation {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ImageLocation): any => ({
    ...obj,
  })
}

export interface DescribePortalResponse {
  portalId: string | undefined;
  portalArn: string | undefined;
  portalName: string | undefined;
  portalDescription?: string;
  portalClientId: string | undefined;
  portalStartUrl: string | undefined;
  portalContactEmail: string | undefined;
  portalStatus: PortalStatus | undefined;
  portalCreationDate: Date | undefined;
  portalLastUpdateDate: Date | undefined;
  portalLogoImageLocation?: ImageLocation;
  roleArn?: string;
  portalAuthMode?: AuthMode | string;
  notificationSenderEmail?: string;
  alarms?: Alarms;
  edgeConfig?: PortalEdgeConfig;
  projectPublicSharing?: ProjectSharingStatus | string;
}

export namespace DescribePortalResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribePortalResponse): any => ({
    ...obj,
  })
}

export interface DescribeProjectRequest {
  projectId: string | undefined;
}

export namespace DescribeProjectRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeProjectRequest): any => ({
    ...obj,
  })
}

export interface DescribeProjectResponse {
  projectId: string | undefined;
  projectArn: string | undefined;
  projectName: string | undefined;
  portalId: string | undefined;
  projectDescription?: string;
  projectCreationDate: Date | undefined;
  projectLastUpdateDate: Date | undefined;
  projectSharing?: (ProjectSharingConfig)[];
}

export namespace DescribeProjectResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: DescribeProjectResponse): any => ({
    ...obj,
  })
}

export enum IdentityType {
  GROUP = "GROUP",
  IAM = "IAM",
  USER = "USER",
}

export interface Image {
  id?: string;
  file?: ImageFile;
}

export namespace Image {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Image): any => ({
    ...obj,
  })
}

export enum ResourceType {
  PORTAL = "PORTAL",
  PROJECT = "PROJECT",
}

export interface ListAccessPoliciesRequest {
  identityType?: IdentityType | string;
  identityId?: string;
  resourceType?: ResourceType | string;
  resourceId?: string;
  iamArn?: string;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListAccessPoliciesRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAccessPoliciesRequest): any => ({
    ...obj,
  })
}

export interface ListAccessPoliciesResponse {
  accessPolicySummaries: (AccessPolicySummary)[] | undefined;
  nextToken?: string;
}

export namespace ListAccessPoliciesResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListAccessPoliciesResponse): any => ({
    ...obj,
  })
}

export interface ListDashboardsRequest {
  projectId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListDashboardsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListDashboardsRequest): any => ({
    ...obj,
  })
}

export interface ListDashboardsResponse {
  dashboardSummaries: (DashboardSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListDashboardsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListDashboardsResponse): any => ({
    ...obj,
  })
}

export interface ListPortalsRequest {
  nextToken?: string;
  maxResults?: number;
}

export namespace ListPortalsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListPortalsRequest): any => ({
    ...obj,
  })
}

export interface PortalSummary {
  id: string | undefined;
  name: string | undefined;
  description?: string;
  startUrl: string | undefined;
  creationDate?: Date;
  lastUpdateDate?: Date;
  roleArn?: string;
  status: PortalStatus | undefined;
}

export namespace PortalSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: PortalSummary): any => ({
    ...obj,
  })
}

export interface ListPortalsResponse {
  portalSummaries?: (PortalSummary)[];
  nextToken?: string;
}

export namespace ListPortalsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListPortalsResponse): any => ({
    ...obj,
  })
}

export interface ListProjectAssetsRequest {
  projectId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListProjectAssetsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListProjectAssetsRequest): any => ({
    ...obj,
  })
}

export interface ListProjectAssetsResponse {
  assetIds: (string)[] | undefined;
  nextToken?: string;
}

export namespace ListProjectAssetsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListProjectAssetsResponse): any => ({
    ...obj,
  })
}

export interface ListProjectsRequest {
  portalId: string | undefined;
  nextToken?: string;
  maxResults?: number;
}

export namespace ListProjectsRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListProjectsRequest): any => ({
    ...obj,
  })
}

export interface ProjectSharingSummary {
  sharingScope: ProjectSharingScope | string | undefined;
  status: ProjectSharingStatus | string | undefined;
}

export namespace ProjectSharingSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ProjectSharingSummary): any => ({
    ...obj,
  })
}

export interface ProjectSummary {
  id: string | undefined;
  name: string | undefined;
  description?: string;
  creationDate?: Date;
  lastUpdateDate?: Date;
  projectSharing?: (ProjectSharingSummary)[];
}

export namespace ProjectSummary {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ProjectSummary): any => ({
    ...obj,
  })
}

export interface ListProjectsResponse {
  projectSummaries: (ProjectSummary)[] | undefined;
  nextToken?: string;
}

export namespace ListProjectsResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ListProjectsResponse): any => ({
    ...obj,
  })
}

export interface UpdateAccessPolicyRequest {
  accessPolicyId: string | undefined;
  accessPolicyIdentity: Identity | undefined;
  accessPolicyResource: Resource | undefined;
  accessPolicyPermission: Permission | string | undefined;
  clientToken?: string;
}

export namespace UpdateAccessPolicyRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAccessPolicyRequest): any => ({
    ...obj,
  })
}

export interface UpdateAccessPolicyResponse {
}

export namespace UpdateAccessPolicyResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateAccessPolicyResponse): any => ({
    ...obj,
  })
}

export interface UpdateDashboardRequest {
  dashboardId: string | undefined;
  dashboardName: string | undefined;
  dashboardDescription?: string;
  dashboardDefinition: string | undefined;
  clientToken?: string;
}

export namespace UpdateDashboardRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateDashboardRequest): any => ({
    ...obj,
  })
}

export interface UpdateDashboardResponse {
}

export namespace UpdateDashboardResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateDashboardResponse): any => ({
    ...obj,
  })
}

export interface UpdatePortalRequest {
  portalId: string | undefined;
  portalName: string | undefined;
  portalDescription?: string;
  portalContactEmail: string | undefined;
  portalLogoImage?: Image;
  roleArn: string | undefined;
  clientToken?: string;
  notificationSenderEmail?: string;
  alarms?: Alarms;
  edgeConfig?: PortalEdgeConfig;
  projectPublicSharing?: ProjectSharingStatus | string;
}

export namespace UpdatePortalRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdatePortalRequest): any => ({
    ...obj,
  })
}

export interface UpdatePortalResponse {
  portalStatus: PortalStatus | undefined;
}

export namespace UpdatePortalResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdatePortalResponse): any => ({
    ...obj,
  })
}

export interface UpdateProjectRequest {
  projectId: string | undefined;
  projectName: string | undefined;
  projectDescription?: string;
  clientToken?: string;
  projectSharing?: (ProjectSharingConfig)[];
}

export namespace UpdateProjectRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateProjectRequest): any => ({
    ...obj,
  })
}

export interface UpdateProjectResponse {
}

export namespace UpdateProjectResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: UpdateProjectResponse): any => ({
    ...obj,
  })
}

export interface BadGatewayException extends __SmithyException, $MetadataBearer {
  name: "BadGatewayException";
  $fault: "server";
  message?: string;
}

export namespace BadGatewayException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: BadGatewayException): any => ({
    ...obj,
  })
}

export interface ConflictException extends __SmithyException, $MetadataBearer {
  name: "ConflictException";
  $fault: "client";
  message?: string;
}

export namespace ConflictException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ConflictException): any => ({
    ...obj,
  })
}

export interface InternalServerException extends __SmithyException, $MetadataBearer {
  name: "InternalServerException";
  $fault: "server";
  message?: string;
}

export namespace InternalServerException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InternalServerException): any => ({
    ...obj,
  })
}

export interface InvokeAssistantRequest {
  conversationId?: string;
  message?: string;
}

export namespace InvokeAssistantRequest {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InvokeAssistantRequest): any => ({
    ...obj,
  })
}

export interface FinalResponse {
  text?: string;
}

export namespace FinalResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: FinalResponse): any => ({
    ...obj,
  })
}

export interface Rationale {
  text?: string;
}

export namespace Rationale {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: Rationale): any => ({
    ...obj,
  })
}

export interface ToolInvocationParameter {
  name?: string;
  value?: string;
  type?: string;
}

export namespace ToolInvocationParameter {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ToolInvocationParameter): any => ({
    ...obj,
  })
}

export interface ToolInvocation {
  name?: string;
  parameters?: (ToolInvocationParameter)[];
}

export namespace ToolInvocation {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ToolInvocation): any => ({
    ...obj,
  })
}

export interface InvokeAssistantStep {
  stepId?: string;
  rationale?: Rationale;
  toolInvocation?: ToolInvocation;
}

export namespace InvokeAssistantStep {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InvokeAssistantStep): any => ({
    ...obj,
  })
}

export type ResponseStream =
  | ResponseStream.FinalResponseMember
  | ResponseStream.StepMember
  | ResponseStream.$UnknownMember

export namespace ResponseStream {

  export interface StepMember {
    step: InvokeAssistantStep;
    finalResponse?: never;
    $unknown?: never;
  }

  export interface FinalResponseMember {
    step?: never;
    finalResponse: FinalResponse;
    $unknown?: never;
  }

  export interface $UnknownMember {
    step?: never;
    finalResponse?: never;
    $unknown: [string, any];
  }

  export interface Visitor<T> {
    step: (value: InvokeAssistantStep) => T;
    finalResponse: (value: FinalResponse) => T;
    _: (name: string, value: any) => T;
  }

  export const visit = <T>(
    value: ResponseStream,
    visitor: Visitor<T>
  ): T => {
    if (value.step !== undefined) return visitor.step(value.step);
    if (value.finalResponse !== undefined) return visitor.finalResponse(value.finalResponse);
    return visitor._(value.$unknown[0], value.$unknown[1]);
  }

  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ResponseStream): any => {
    if (obj.step !== undefined) return {step:
      InvokeAssistantStep.filterSensitiveLog(obj.step)
    };
    if (obj.finalResponse !== undefined) return {finalResponse:
      FinalResponse.filterSensitiveLog(obj.finalResponse)
    };
    if (obj.$unknown !== undefined) return {[obj.$unknown[0]]: 'UNKNOWN'};
  }
}

export interface InvokeAssistantResponse {
  body: AsyncIterable<ResponseStream> | undefined;
  conversationId: string | undefined;
}

export namespace InvokeAssistantResponse {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: InvokeAssistantResponse): any => ({
    ...obj,
    ...(obj.body && { body:
      'STREAMING_CONTENT'
    }),
  })
}

export interface ServiceQuotaExceededException extends __SmithyException, $MetadataBearer {
  name: "ServiceQuotaExceededException";
  $fault: "client";
  message?: string;
}

export namespace ServiceQuotaExceededException {
  /**
   * @internal
   */
  export const filterSensitiveLog = (obj: ServiceQuotaExceededException): any => ({
    ...obj,
  })
}
