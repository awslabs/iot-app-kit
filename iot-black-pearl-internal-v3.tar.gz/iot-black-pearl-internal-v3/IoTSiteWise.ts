import { IoTSiteWiseClient } from "./IoTSiteWiseClient";
import {
  AssociateAssetsCommand,
  AssociateAssetsCommandInput,
  AssociateAssetsCommandOutput,
} from "./commands/AssociateAssetsCommand";
import {
  AssociateTimeSeriesToAssetPropertyCommand,
  AssociateTimeSeriesToAssetPropertyCommandInput,
  AssociateTimeSeriesToAssetPropertyCommandOutput,
} from "./commands/AssociateTimeSeriesToAssetPropertyCommand";
import {
  BatchAssociateProjectAssetsCommand,
  BatchAssociateProjectAssetsCommandInput,
  BatchAssociateProjectAssetsCommandOutput,
} from "./commands/BatchAssociateProjectAssetsCommand";
import {
  BatchDisassociateProjectAssetsCommand,
  BatchDisassociateProjectAssetsCommandInput,
  BatchDisassociateProjectAssetsCommandOutput,
} from "./commands/BatchDisassociateProjectAssetsCommand";
import {
  CreateAccessPolicyCommand,
  CreateAccessPolicyCommandInput,
  CreateAccessPolicyCommandOutput,
} from "./commands/CreateAccessPolicyCommand";
import {
  CreateAssetCommand,
  CreateAssetCommandInput,
  CreateAssetCommandOutput,
} from "./commands/CreateAssetCommand";
import {
  CreateAssetModelCommand,
  CreateAssetModelCommandInput,
  CreateAssetModelCommandOutput,
} from "./commands/CreateAssetModelCommand";
import {
  CreateAssetModelCompositeModelCommand,
  CreateAssetModelCompositeModelCommandInput,
  CreateAssetModelCompositeModelCommandOutput,
} from "./commands/CreateAssetModelCompositeModelCommand";
import {
  CreateDashboardCommand,
  CreateDashboardCommandInput,
  CreateDashboardCommandOutput,
} from "./commands/CreateDashboardCommand";
import {
  CreateGatewayCommand,
  CreateGatewayCommandInput,
  CreateGatewayCommandOutput,
} from "./commands/CreateGatewayCommand";
import {
  CreatePortalCommand,
  CreatePortalCommandInput,
  CreatePortalCommandOutput,
} from "./commands/CreatePortalCommand";
import {
  CreateProjectCommand,
  CreateProjectCommandInput,
  CreateProjectCommandOutput,
} from "./commands/CreateProjectCommand";
import {
  DeleteAccessPolicyCommand,
  DeleteAccessPolicyCommandInput,
  DeleteAccessPolicyCommandOutput,
} from "./commands/DeleteAccessPolicyCommand";
import {
  DeleteAssetCommand,
  DeleteAssetCommandInput,
  DeleteAssetCommandOutput,
} from "./commands/DeleteAssetCommand";
import {
  DeleteAssetModelCommand,
  DeleteAssetModelCommandInput,
  DeleteAssetModelCommandOutput,
} from "./commands/DeleteAssetModelCommand";
import {
  DeleteAssetModelCompositeModelCommand,
  DeleteAssetModelCompositeModelCommandInput,
  DeleteAssetModelCompositeModelCommandOutput,
} from "./commands/DeleteAssetModelCompositeModelCommand";
import {
  DeleteDashboardCommand,
  DeleteDashboardCommandInput,
  DeleteDashboardCommandOutput,
} from "./commands/DeleteDashboardCommand";
import {
  DeleteGatewayCommand,
  DeleteGatewayCommandInput,
  DeleteGatewayCommandOutput,
} from "./commands/DeleteGatewayCommand";
import {
  DeletePortalCommand,
  DeletePortalCommandInput,
  DeletePortalCommandOutput,
} from "./commands/DeletePortalCommand";
import {
  DeleteProjectCommand,
  DeleteProjectCommandInput,
  DeleteProjectCommandOutput,
} from "./commands/DeleteProjectCommand";
import {
  DeleteTimeSeriesCommand,
  DeleteTimeSeriesCommandInput,
  DeleteTimeSeriesCommandOutput,
} from "./commands/DeleteTimeSeriesCommand";
import {
  DescribeAccessPolicyCommand,
  DescribeAccessPolicyCommandInput,
  DescribeAccessPolicyCommandOutput,
} from "./commands/DescribeAccessPolicyCommand";
import {
  DescribeActionCommand,
  DescribeActionCommandInput,
  DescribeActionCommandOutput,
} from "./commands/DescribeActionCommand";
import {
  DescribeAssetCommand,
  DescribeAssetCommandInput,
  DescribeAssetCommandOutput,
} from "./commands/DescribeAssetCommand";
import {
  DescribeAssetCompositeModelCommand,
  DescribeAssetCompositeModelCommandInput,
  DescribeAssetCompositeModelCommandOutput,
} from "./commands/DescribeAssetCompositeModelCommand";
import {
  DescribeAssetModelCommand,
  DescribeAssetModelCommandInput,
  DescribeAssetModelCommandOutput,
} from "./commands/DescribeAssetModelCommand";
import {
  DescribeAssetModelCompositeModelCommand,
  DescribeAssetModelCompositeModelCommandInput,
  DescribeAssetModelCompositeModelCommandOutput,
} from "./commands/DescribeAssetModelCompositeModelCommand";
import {
  DescribeAssetPropertyCommand,
  DescribeAssetPropertyCommandInput,
  DescribeAssetPropertyCommandOutput,
} from "./commands/DescribeAssetPropertyCommand";
import {
  DescribeDashboardCommand,
  DescribeDashboardCommandInput,
  DescribeDashboardCommandOutput,
} from "./commands/DescribeDashboardCommand";
import {
  DescribeGatewayCapabilityConfigurationCommand,
  DescribeGatewayCapabilityConfigurationCommandInput,
  DescribeGatewayCapabilityConfigurationCommandOutput,
} from "./commands/DescribeGatewayCapabilityConfigurationCommand";
import {
  DescribeGatewayCommand,
  DescribeGatewayCommandInput,
  DescribeGatewayCommandOutput,
} from "./commands/DescribeGatewayCommand";
import {
  DescribeLoggingOptionsCommand,
  DescribeLoggingOptionsCommandInput,
  DescribeLoggingOptionsCommandOutput,
} from "./commands/DescribeLoggingOptionsCommand";
import {
  DescribePortalCommand,
  DescribePortalCommandInput,
  DescribePortalCommandOutput,
} from "./commands/DescribePortalCommand";
import {
  DescribeProjectCommand,
  DescribeProjectCommandInput,
  DescribeProjectCommandOutput,
} from "./commands/DescribeProjectCommand";
import {
  DescribeTimeSeriesCommand,
  DescribeTimeSeriesCommandInput,
  DescribeTimeSeriesCommandOutput,
} from "./commands/DescribeTimeSeriesCommand";
import {
  DisassociateAssetsCommand,
  DisassociateAssetsCommandInput,
  DisassociateAssetsCommandOutput,
} from "./commands/DisassociateAssetsCommand";
import {
  DisassociateTimeSeriesFromAssetPropertyCommand,
  DisassociateTimeSeriesFromAssetPropertyCommandInput,
  DisassociateTimeSeriesFromAssetPropertyCommandOutput,
} from "./commands/DisassociateTimeSeriesFromAssetPropertyCommand";
import {
  ExecuteActionCommand,
  ExecuteActionCommandInput,
  ExecuteActionCommandOutput,
} from "./commands/ExecuteActionCommand";
import {
  InvokeAssistantCommand,
  InvokeAssistantCommandInput,
  InvokeAssistantCommandOutput,
} from "./commands/InvokeAssistantCommand";
import {
  ListAccessPoliciesCommand,
  ListAccessPoliciesCommandInput,
  ListAccessPoliciesCommandOutput,
} from "./commands/ListAccessPoliciesCommand";
import {
  ListActionsCommand,
  ListActionsCommandInput,
  ListActionsCommandOutput,
} from "./commands/ListActionsCommand";
import {
  ListAssetModelCompositeModelsCommand,
  ListAssetModelCompositeModelsCommandInput,
  ListAssetModelCompositeModelsCommandOutput,
} from "./commands/ListAssetModelCompositeModelsCommand";
import {
  ListAssetModelPropertiesCommand,
  ListAssetModelPropertiesCommandInput,
  ListAssetModelPropertiesCommandOutput,
} from "./commands/ListAssetModelPropertiesCommand";
import {
  ListAssetModelsCommand,
  ListAssetModelsCommandInput,
  ListAssetModelsCommandOutput,
} from "./commands/ListAssetModelsCommand";
import {
  ListAssetPropertiesCommand,
  ListAssetPropertiesCommandInput,
  ListAssetPropertiesCommandOutput,
} from "./commands/ListAssetPropertiesCommand";
import {
  ListAssetRelationshipsCommand,
  ListAssetRelationshipsCommandInput,
  ListAssetRelationshipsCommandOutput,
} from "./commands/ListAssetRelationshipsCommand";
import {
  ListAssetsCommand,
  ListAssetsCommandInput,
  ListAssetsCommandOutput,
} from "./commands/ListAssetsCommand";
import {
  ListAssociatedAssetsCommand,
  ListAssociatedAssetsCommandInput,
  ListAssociatedAssetsCommandOutput,
} from "./commands/ListAssociatedAssetsCommand";
import {
  ListCompositionRelationshipsCommand,
  ListCompositionRelationshipsCommandInput,
  ListCompositionRelationshipsCommandOutput,
} from "./commands/ListCompositionRelationshipsCommand";
import {
  ListDashboardsCommand,
  ListDashboardsCommandInput,
  ListDashboardsCommandOutput,
} from "./commands/ListDashboardsCommand";
import {
  ListGatewaysCommand,
  ListGatewaysCommandInput,
  ListGatewaysCommandOutput,
} from "./commands/ListGatewaysCommand";
import {
  ListPortalsCommand,
  ListPortalsCommandInput,
  ListPortalsCommandOutput,
} from "./commands/ListPortalsCommand";
import {
  ListProjectAssetsCommand,
  ListProjectAssetsCommandInput,
  ListProjectAssetsCommandOutput,
} from "./commands/ListProjectAssetsCommand";
import {
  ListProjectsCommand,
  ListProjectsCommandInput,
  ListProjectsCommandOutput,
} from "./commands/ListProjectsCommand";
import {
  ListTimeSeriesCommand,
  ListTimeSeriesCommandInput,
  ListTimeSeriesCommandOutput,
} from "./commands/ListTimeSeriesCommand";
import {
  PutLoggingOptionsCommand,
  PutLoggingOptionsCommandInput,
  PutLoggingOptionsCommandOutput,
} from "./commands/PutLoggingOptionsCommand";
import {
  UpdateAccessPolicyCommand,
  UpdateAccessPolicyCommandInput,
  UpdateAccessPolicyCommandOutput,
} from "./commands/UpdateAccessPolicyCommand";
import {
  UpdateAssetCommand,
  UpdateAssetCommandInput,
  UpdateAssetCommandOutput,
} from "./commands/UpdateAssetCommand";
import {
  UpdateAssetModelCommand,
  UpdateAssetModelCommandInput,
  UpdateAssetModelCommandOutput,
} from "./commands/UpdateAssetModelCommand";
import {
  UpdateAssetModelCompositeModelCommand,
  UpdateAssetModelCompositeModelCommandInput,
  UpdateAssetModelCompositeModelCommandOutput,
} from "./commands/UpdateAssetModelCompositeModelCommand";
import {
  UpdateAssetPropertyCommand,
  UpdateAssetPropertyCommandInput,
  UpdateAssetPropertyCommandOutput,
} from "./commands/UpdateAssetPropertyCommand";
import {
  UpdateDashboardCommand,
  UpdateDashboardCommandInput,
  UpdateDashboardCommandOutput,
} from "./commands/UpdateDashboardCommand";
import {
  UpdateGatewayCapabilityConfigurationCommand,
  UpdateGatewayCapabilityConfigurationCommandInput,
  UpdateGatewayCapabilityConfigurationCommandOutput,
} from "./commands/UpdateGatewayCapabilityConfigurationCommand";
import {
  UpdateGatewayCommand,
  UpdateGatewayCommandInput,
  UpdateGatewayCommandOutput,
} from "./commands/UpdateGatewayCommand";
import {
  UpdatePortalCommand,
  UpdatePortalCommandInput,
  UpdatePortalCommandOutput,
} from "./commands/UpdatePortalCommand";
import {
  UpdateProjectCommand,
  UpdateProjectCommandInput,
  UpdateProjectCommandOutput,
} from "./commands/UpdateProjectCommand";
import { HttpHandlerOptions as __HttpHandlerOptions } from "@aws-sdk/types";

export class IoTSiteWise extends IoTSiteWiseClient {
  public createGateway(
    args: CreateGatewayCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateGatewayCommandOutput>;
  public createGateway(
    args: CreateGatewayCommandInput,
    cb: (err: any, data?: CreateGatewayCommandOutput) => void
  ): void;
  public createGateway(
    args: CreateGatewayCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateGatewayCommandOutput) => void
  ): void;
  public createGateway(
    args: CreateGatewayCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateGatewayCommandOutput) => void),
    cb?: (err: any, data?: CreateGatewayCommandOutput) => void
  ): Promise<CreateGatewayCommandOutput> | void {
    const command = new CreateGatewayCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteGateway(
    args: DeleteGatewayCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteGatewayCommandOutput>;
  public deleteGateway(
    args: DeleteGatewayCommandInput,
    cb: (err: any, data?: DeleteGatewayCommandOutput) => void
  ): void;
  public deleteGateway(
    args: DeleteGatewayCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteGatewayCommandOutput) => void
  ): void;
  public deleteGateway(
    args: DeleteGatewayCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteGatewayCommandOutput) => void),
    cb?: (err: any, data?: DeleteGatewayCommandOutput) => void
  ): Promise<DeleteGatewayCommandOutput> | void {
    const command = new DeleteGatewayCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeGateway(
    args: DescribeGatewayCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeGatewayCommandOutput>;
  public describeGateway(
    args: DescribeGatewayCommandInput,
    cb: (err: any, data?: DescribeGatewayCommandOutput) => void
  ): void;
  public describeGateway(
    args: DescribeGatewayCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeGatewayCommandOutput) => void
  ): void;
  public describeGateway(
    args: DescribeGatewayCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeGatewayCommandOutput) => void),
    cb?: (err: any, data?: DescribeGatewayCommandOutput) => void
  ): Promise<DescribeGatewayCommandOutput> | void {
    const command = new DescribeGatewayCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeGatewayCapabilityConfiguration(
    args: DescribeGatewayCapabilityConfigurationCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeGatewayCapabilityConfigurationCommandOutput>;
  public describeGatewayCapabilityConfiguration(
    args: DescribeGatewayCapabilityConfigurationCommandInput,
    cb: (err: any, data?: DescribeGatewayCapabilityConfigurationCommandOutput) => void
  ): void;
  public describeGatewayCapabilityConfiguration(
    args: DescribeGatewayCapabilityConfigurationCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeGatewayCapabilityConfigurationCommandOutput) => void
  ): void;
  public describeGatewayCapabilityConfiguration(
    args: DescribeGatewayCapabilityConfigurationCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeGatewayCapabilityConfigurationCommandOutput) => void),
    cb?: (err: any, data?: DescribeGatewayCapabilityConfigurationCommandOutput) => void
  ): Promise<DescribeGatewayCapabilityConfigurationCommandOutput> | void {
    const command = new DescribeGatewayCapabilityConfigurationCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listGateways(
    args: ListGatewaysCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListGatewaysCommandOutput>;
  public listGateways(
    args: ListGatewaysCommandInput,
    cb: (err: any, data?: ListGatewaysCommandOutput) => void
  ): void;
  public listGateways(
    args: ListGatewaysCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListGatewaysCommandOutput) => void
  ): void;
  public listGateways(
    args: ListGatewaysCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListGatewaysCommandOutput) => void),
    cb?: (err: any, data?: ListGatewaysCommandOutput) => void
  ): Promise<ListGatewaysCommandOutput> | void {
    const command = new ListGatewaysCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateGateway(
    args: UpdateGatewayCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateGatewayCommandOutput>;
  public updateGateway(
    args: UpdateGatewayCommandInput,
    cb: (err: any, data?: UpdateGatewayCommandOutput) => void
  ): void;
  public updateGateway(
    args: UpdateGatewayCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateGatewayCommandOutput) => void
  ): void;
  public updateGateway(
    args: UpdateGatewayCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateGatewayCommandOutput) => void),
    cb?: (err: any, data?: UpdateGatewayCommandOutput) => void
  ): Promise<UpdateGatewayCommandOutput> | void {
    const command = new UpdateGatewayCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateGatewayCapabilityConfiguration(
    args: UpdateGatewayCapabilityConfigurationCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateGatewayCapabilityConfigurationCommandOutput>;
  public updateGatewayCapabilityConfiguration(
    args: UpdateGatewayCapabilityConfigurationCommandInput,
    cb: (err: any, data?: UpdateGatewayCapabilityConfigurationCommandOutput) => void
  ): void;
  public updateGatewayCapabilityConfiguration(
    args: UpdateGatewayCapabilityConfigurationCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateGatewayCapabilityConfigurationCommandOutput) => void
  ): void;
  public updateGatewayCapabilityConfiguration(
    args: UpdateGatewayCapabilityConfigurationCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateGatewayCapabilityConfigurationCommandOutput) => void),
    cb?: (err: any, data?: UpdateGatewayCapabilityConfigurationCommandOutput) => void
  ): Promise<UpdateGatewayCapabilityConfigurationCommandOutput> | void {
    const command = new UpdateGatewayCapabilityConfigurationCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public associateAssets(
    args: AssociateAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<AssociateAssetsCommandOutput>;
  public associateAssets(
    args: AssociateAssetsCommandInput,
    cb: (err: any, data?: AssociateAssetsCommandOutput) => void
  ): void;
  public associateAssets(
    args: AssociateAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: AssociateAssetsCommandOutput) => void
  ): void;
  public associateAssets(
    args: AssociateAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: AssociateAssetsCommandOutput) => void),
    cb?: (err: any, data?: AssociateAssetsCommandOutput) => void
  ): Promise<AssociateAssetsCommandOutput> | void {
    const command = new AssociateAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public associateTimeSeriesToAssetProperty(
    args: AssociateTimeSeriesToAssetPropertyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<AssociateTimeSeriesToAssetPropertyCommandOutput>;
  public associateTimeSeriesToAssetProperty(
    args: AssociateTimeSeriesToAssetPropertyCommandInput,
    cb: (err: any, data?: AssociateTimeSeriesToAssetPropertyCommandOutput) => void
  ): void;
  public associateTimeSeriesToAssetProperty(
    args: AssociateTimeSeriesToAssetPropertyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: AssociateTimeSeriesToAssetPropertyCommandOutput) => void
  ): void;
  public associateTimeSeriesToAssetProperty(
    args: AssociateTimeSeriesToAssetPropertyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: AssociateTimeSeriesToAssetPropertyCommandOutput) => void),
    cb?: (err: any, data?: AssociateTimeSeriesToAssetPropertyCommandOutput) => void
  ): Promise<AssociateTimeSeriesToAssetPropertyCommandOutput> | void {
    const command = new AssociateTimeSeriesToAssetPropertyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createAsset(
    args: CreateAssetCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateAssetCommandOutput>;
  public createAsset(
    args: CreateAssetCommandInput,
    cb: (err: any, data?: CreateAssetCommandOutput) => void
  ): void;
  public createAsset(
    args: CreateAssetCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateAssetCommandOutput) => void
  ): void;
  public createAsset(
    args: CreateAssetCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateAssetCommandOutput) => void),
    cb?: (err: any, data?: CreateAssetCommandOutput) => void
  ): Promise<CreateAssetCommandOutput> | void {
    const command = new CreateAssetCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createAssetModel(
    args: CreateAssetModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateAssetModelCommandOutput>;
  public createAssetModel(
    args: CreateAssetModelCommandInput,
    cb: (err: any, data?: CreateAssetModelCommandOutput) => void
  ): void;
  public createAssetModel(
    args: CreateAssetModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateAssetModelCommandOutput) => void
  ): void;
  public createAssetModel(
    args: CreateAssetModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateAssetModelCommandOutput) => void),
    cb?: (err: any, data?: CreateAssetModelCommandOutput) => void
  ): Promise<CreateAssetModelCommandOutput> | void {
    const command = new CreateAssetModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createAssetModelCompositeModel(
    args: CreateAssetModelCompositeModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateAssetModelCompositeModelCommandOutput>;
  public createAssetModelCompositeModel(
    args: CreateAssetModelCompositeModelCommandInput,
    cb: (err: any, data?: CreateAssetModelCompositeModelCommandOutput) => void
  ): void;
  public createAssetModelCompositeModel(
    args: CreateAssetModelCompositeModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateAssetModelCompositeModelCommandOutput) => void
  ): void;
  public createAssetModelCompositeModel(
    args: CreateAssetModelCompositeModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateAssetModelCompositeModelCommandOutput) => void),
    cb?: (err: any, data?: CreateAssetModelCompositeModelCommandOutput) => void
  ): Promise<CreateAssetModelCompositeModelCommandOutput> | void {
    const command = new CreateAssetModelCompositeModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteAsset(
    args: DeleteAssetCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteAssetCommandOutput>;
  public deleteAsset(
    args: DeleteAssetCommandInput,
    cb: (err: any, data?: DeleteAssetCommandOutput) => void
  ): void;
  public deleteAsset(
    args: DeleteAssetCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteAssetCommandOutput) => void
  ): void;
  public deleteAsset(
    args: DeleteAssetCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteAssetCommandOutput) => void),
    cb?: (err: any, data?: DeleteAssetCommandOutput) => void
  ): Promise<DeleteAssetCommandOutput> | void {
    const command = new DeleteAssetCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteAssetModel(
    args: DeleteAssetModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteAssetModelCommandOutput>;
  public deleteAssetModel(
    args: DeleteAssetModelCommandInput,
    cb: (err: any, data?: DeleteAssetModelCommandOutput) => void
  ): void;
  public deleteAssetModel(
    args: DeleteAssetModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteAssetModelCommandOutput) => void
  ): void;
  public deleteAssetModel(
    args: DeleteAssetModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteAssetModelCommandOutput) => void),
    cb?: (err: any, data?: DeleteAssetModelCommandOutput) => void
  ): Promise<DeleteAssetModelCommandOutput> | void {
    const command = new DeleteAssetModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteAssetModelCompositeModel(
    args: DeleteAssetModelCompositeModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteAssetModelCompositeModelCommandOutput>;
  public deleteAssetModelCompositeModel(
    args: DeleteAssetModelCompositeModelCommandInput,
    cb: (err: any, data?: DeleteAssetModelCompositeModelCommandOutput) => void
  ): void;
  public deleteAssetModelCompositeModel(
    args: DeleteAssetModelCompositeModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteAssetModelCompositeModelCommandOutput) => void
  ): void;
  public deleteAssetModelCompositeModel(
    args: DeleteAssetModelCompositeModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteAssetModelCompositeModelCommandOutput) => void),
    cb?: (err: any, data?: DeleteAssetModelCompositeModelCommandOutput) => void
  ): Promise<DeleteAssetModelCompositeModelCommandOutput> | void {
    const command = new DeleteAssetModelCompositeModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteTimeSeries(
    args: DeleteTimeSeriesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteTimeSeriesCommandOutput>;
  public deleteTimeSeries(
    args: DeleteTimeSeriesCommandInput,
    cb: (err: any, data?: DeleteTimeSeriesCommandOutput) => void
  ): void;
  public deleteTimeSeries(
    args: DeleteTimeSeriesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteTimeSeriesCommandOutput) => void
  ): void;
  public deleteTimeSeries(
    args: DeleteTimeSeriesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteTimeSeriesCommandOutput) => void),
    cb?: (err: any, data?: DeleteTimeSeriesCommandOutput) => void
  ): Promise<DeleteTimeSeriesCommandOutput> | void {
    const command = new DeleteTimeSeriesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAction(
    args: DescribeActionCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeActionCommandOutput>;
  public describeAction(
    args: DescribeActionCommandInput,
    cb: (err: any, data?: DescribeActionCommandOutput) => void
  ): void;
  public describeAction(
    args: DescribeActionCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeActionCommandOutput) => void
  ): void;
  public describeAction(
    args: DescribeActionCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeActionCommandOutput) => void),
    cb?: (err: any, data?: DescribeActionCommandOutput) => void
  ): Promise<DescribeActionCommandOutput> | void {
    const command = new DescribeActionCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAsset(
    args: DescribeAssetCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAssetCommandOutput>;
  public describeAsset(
    args: DescribeAssetCommandInput,
    cb: (err: any, data?: DescribeAssetCommandOutput) => void
  ): void;
  public describeAsset(
    args: DescribeAssetCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAssetCommandOutput) => void
  ): void;
  public describeAsset(
    args: DescribeAssetCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAssetCommandOutput) => void),
    cb?: (err: any, data?: DescribeAssetCommandOutput) => void
  ): Promise<DescribeAssetCommandOutput> | void {
    const command = new DescribeAssetCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAssetCompositeModel(
    args: DescribeAssetCompositeModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAssetCompositeModelCommandOutput>;
  public describeAssetCompositeModel(
    args: DescribeAssetCompositeModelCommandInput,
    cb: (err: any, data?: DescribeAssetCompositeModelCommandOutput) => void
  ): void;
  public describeAssetCompositeModel(
    args: DescribeAssetCompositeModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAssetCompositeModelCommandOutput) => void
  ): void;
  public describeAssetCompositeModel(
    args: DescribeAssetCompositeModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAssetCompositeModelCommandOutput) => void),
    cb?: (err: any, data?: DescribeAssetCompositeModelCommandOutput) => void
  ): Promise<DescribeAssetCompositeModelCommandOutput> | void {
    const command = new DescribeAssetCompositeModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAssetModel(
    args: DescribeAssetModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAssetModelCommandOutput>;
  public describeAssetModel(
    args: DescribeAssetModelCommandInput,
    cb: (err: any, data?: DescribeAssetModelCommandOutput) => void
  ): void;
  public describeAssetModel(
    args: DescribeAssetModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAssetModelCommandOutput) => void
  ): void;
  public describeAssetModel(
    args: DescribeAssetModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAssetModelCommandOutput) => void),
    cb?: (err: any, data?: DescribeAssetModelCommandOutput) => void
  ): Promise<DescribeAssetModelCommandOutput> | void {
    const command = new DescribeAssetModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAssetModelCompositeModel(
    args: DescribeAssetModelCompositeModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAssetModelCompositeModelCommandOutput>;
  public describeAssetModelCompositeModel(
    args: DescribeAssetModelCompositeModelCommandInput,
    cb: (err: any, data?: DescribeAssetModelCompositeModelCommandOutput) => void
  ): void;
  public describeAssetModelCompositeModel(
    args: DescribeAssetModelCompositeModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAssetModelCompositeModelCommandOutput) => void
  ): void;
  public describeAssetModelCompositeModel(
    args: DescribeAssetModelCompositeModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAssetModelCompositeModelCommandOutput) => void),
    cb?: (err: any, data?: DescribeAssetModelCompositeModelCommandOutput) => void
  ): Promise<DescribeAssetModelCompositeModelCommandOutput> | void {
    const command = new DescribeAssetModelCompositeModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAssetProperty(
    args: DescribeAssetPropertyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAssetPropertyCommandOutput>;
  public describeAssetProperty(
    args: DescribeAssetPropertyCommandInput,
    cb: (err: any, data?: DescribeAssetPropertyCommandOutput) => void
  ): void;
  public describeAssetProperty(
    args: DescribeAssetPropertyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAssetPropertyCommandOutput) => void
  ): void;
  public describeAssetProperty(
    args: DescribeAssetPropertyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAssetPropertyCommandOutput) => void),
    cb?: (err: any, data?: DescribeAssetPropertyCommandOutput) => void
  ): Promise<DescribeAssetPropertyCommandOutput> | void {
    const command = new DescribeAssetPropertyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeLoggingOptions(
    args: DescribeLoggingOptionsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeLoggingOptionsCommandOutput>;
  public describeLoggingOptions(
    args: DescribeLoggingOptionsCommandInput,
    cb: (err: any, data?: DescribeLoggingOptionsCommandOutput) => void
  ): void;
  public describeLoggingOptions(
    args: DescribeLoggingOptionsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeLoggingOptionsCommandOutput) => void
  ): void;
  public describeLoggingOptions(
    args: DescribeLoggingOptionsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeLoggingOptionsCommandOutput) => void),
    cb?: (err: any, data?: DescribeLoggingOptionsCommandOutput) => void
  ): Promise<DescribeLoggingOptionsCommandOutput> | void {
    const command = new DescribeLoggingOptionsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeTimeSeries(
    args: DescribeTimeSeriesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeTimeSeriesCommandOutput>;
  public describeTimeSeries(
    args: DescribeTimeSeriesCommandInput,
    cb: (err: any, data?: DescribeTimeSeriesCommandOutput) => void
  ): void;
  public describeTimeSeries(
    args: DescribeTimeSeriesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeTimeSeriesCommandOutput) => void
  ): void;
  public describeTimeSeries(
    args: DescribeTimeSeriesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeTimeSeriesCommandOutput) => void),
    cb?: (err: any, data?: DescribeTimeSeriesCommandOutput) => void
  ): Promise<DescribeTimeSeriesCommandOutput> | void {
    const command = new DescribeTimeSeriesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public disassociateAssets(
    args: DisassociateAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DisassociateAssetsCommandOutput>;
  public disassociateAssets(
    args: DisassociateAssetsCommandInput,
    cb: (err: any, data?: DisassociateAssetsCommandOutput) => void
  ): void;
  public disassociateAssets(
    args: DisassociateAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DisassociateAssetsCommandOutput) => void
  ): void;
  public disassociateAssets(
    args: DisassociateAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DisassociateAssetsCommandOutput) => void),
    cb?: (err: any, data?: DisassociateAssetsCommandOutput) => void
  ): Promise<DisassociateAssetsCommandOutput> | void {
    const command = new DisassociateAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public disassociateTimeSeriesFromAssetProperty(
    args: DisassociateTimeSeriesFromAssetPropertyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DisassociateTimeSeriesFromAssetPropertyCommandOutput>;
  public disassociateTimeSeriesFromAssetProperty(
    args: DisassociateTimeSeriesFromAssetPropertyCommandInput,
    cb: (err: any, data?: DisassociateTimeSeriesFromAssetPropertyCommandOutput) => void
  ): void;
  public disassociateTimeSeriesFromAssetProperty(
    args: DisassociateTimeSeriesFromAssetPropertyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DisassociateTimeSeriesFromAssetPropertyCommandOutput) => void
  ): void;
  public disassociateTimeSeriesFromAssetProperty(
    args: DisassociateTimeSeriesFromAssetPropertyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DisassociateTimeSeriesFromAssetPropertyCommandOutput) => void),
    cb?: (err: any, data?: DisassociateTimeSeriesFromAssetPropertyCommandOutput) => void
  ): Promise<DisassociateTimeSeriesFromAssetPropertyCommandOutput> | void {
    const command = new DisassociateTimeSeriesFromAssetPropertyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public executeAction(
    args: ExecuteActionCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ExecuteActionCommandOutput>;
  public executeAction(
    args: ExecuteActionCommandInput,
    cb: (err: any, data?: ExecuteActionCommandOutput) => void
  ): void;
  public executeAction(
    args: ExecuteActionCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ExecuteActionCommandOutput) => void
  ): void;
  public executeAction(
    args: ExecuteActionCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ExecuteActionCommandOutput) => void),
    cb?: (err: any, data?: ExecuteActionCommandOutput) => void
  ): Promise<ExecuteActionCommandOutput> | void {
    const command = new ExecuteActionCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listActions(
    args: ListActionsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListActionsCommandOutput>;
  public listActions(
    args: ListActionsCommandInput,
    cb: (err: any, data?: ListActionsCommandOutput) => void
  ): void;
  public listActions(
    args: ListActionsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListActionsCommandOutput) => void
  ): void;
  public listActions(
    args: ListActionsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListActionsCommandOutput) => void),
    cb?: (err: any, data?: ListActionsCommandOutput) => void
  ): Promise<ListActionsCommandOutput> | void {
    const command = new ListActionsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssetModelCompositeModels(
    args: ListAssetModelCompositeModelsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetModelCompositeModelsCommandOutput>;
  public listAssetModelCompositeModels(
    args: ListAssetModelCompositeModelsCommandInput,
    cb: (err: any, data?: ListAssetModelCompositeModelsCommandOutput) => void
  ): void;
  public listAssetModelCompositeModels(
    args: ListAssetModelCompositeModelsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetModelCompositeModelsCommandOutput) => void
  ): void;
  public listAssetModelCompositeModels(
    args: ListAssetModelCompositeModelsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetModelCompositeModelsCommandOutput) => void),
    cb?: (err: any, data?: ListAssetModelCompositeModelsCommandOutput) => void
  ): Promise<ListAssetModelCompositeModelsCommandOutput> | void {
    const command = new ListAssetModelCompositeModelsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssetModelProperties(
    args: ListAssetModelPropertiesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetModelPropertiesCommandOutput>;
  public listAssetModelProperties(
    args: ListAssetModelPropertiesCommandInput,
    cb: (err: any, data?: ListAssetModelPropertiesCommandOutput) => void
  ): void;
  public listAssetModelProperties(
    args: ListAssetModelPropertiesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetModelPropertiesCommandOutput) => void
  ): void;
  public listAssetModelProperties(
    args: ListAssetModelPropertiesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetModelPropertiesCommandOutput) => void),
    cb?: (err: any, data?: ListAssetModelPropertiesCommandOutput) => void
  ): Promise<ListAssetModelPropertiesCommandOutput> | void {
    const command = new ListAssetModelPropertiesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssetModels(
    args: ListAssetModelsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetModelsCommandOutput>;
  public listAssetModels(
    args: ListAssetModelsCommandInput,
    cb: (err: any, data?: ListAssetModelsCommandOutput) => void
  ): void;
  public listAssetModels(
    args: ListAssetModelsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetModelsCommandOutput) => void
  ): void;
  public listAssetModels(
    args: ListAssetModelsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetModelsCommandOutput) => void),
    cb?: (err: any, data?: ListAssetModelsCommandOutput) => void
  ): Promise<ListAssetModelsCommandOutput> | void {
    const command = new ListAssetModelsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssetProperties(
    args: ListAssetPropertiesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetPropertiesCommandOutput>;
  public listAssetProperties(
    args: ListAssetPropertiesCommandInput,
    cb: (err: any, data?: ListAssetPropertiesCommandOutput) => void
  ): void;
  public listAssetProperties(
    args: ListAssetPropertiesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetPropertiesCommandOutput) => void
  ): void;
  public listAssetProperties(
    args: ListAssetPropertiesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetPropertiesCommandOutput) => void),
    cb?: (err: any, data?: ListAssetPropertiesCommandOutput) => void
  ): Promise<ListAssetPropertiesCommandOutput> | void {
    const command = new ListAssetPropertiesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssetRelationships(
    args: ListAssetRelationshipsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetRelationshipsCommandOutput>;
  public listAssetRelationships(
    args: ListAssetRelationshipsCommandInput,
    cb: (err: any, data?: ListAssetRelationshipsCommandOutput) => void
  ): void;
  public listAssetRelationships(
    args: ListAssetRelationshipsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetRelationshipsCommandOutput) => void
  ): void;
  public listAssetRelationships(
    args: ListAssetRelationshipsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetRelationshipsCommandOutput) => void),
    cb?: (err: any, data?: ListAssetRelationshipsCommandOutput) => void
  ): Promise<ListAssetRelationshipsCommandOutput> | void {
    const command = new ListAssetRelationshipsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssets(
    args: ListAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssetsCommandOutput>;
  public listAssets(
    args: ListAssetsCommandInput,
    cb: (err: any, data?: ListAssetsCommandOutput) => void
  ): void;
  public listAssets(
    args: ListAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssetsCommandOutput) => void
  ): void;
  public listAssets(
    args: ListAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssetsCommandOutput) => void),
    cb?: (err: any, data?: ListAssetsCommandOutput) => void
  ): Promise<ListAssetsCommandOutput> | void {
    const command = new ListAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAssociatedAssets(
    args: ListAssociatedAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAssociatedAssetsCommandOutput>;
  public listAssociatedAssets(
    args: ListAssociatedAssetsCommandInput,
    cb: (err: any, data?: ListAssociatedAssetsCommandOutput) => void
  ): void;
  public listAssociatedAssets(
    args: ListAssociatedAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAssociatedAssetsCommandOutput) => void
  ): void;
  public listAssociatedAssets(
    args: ListAssociatedAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAssociatedAssetsCommandOutput) => void),
    cb?: (err: any, data?: ListAssociatedAssetsCommandOutput) => void
  ): Promise<ListAssociatedAssetsCommandOutput> | void {
    const command = new ListAssociatedAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listCompositionRelationships(
    args: ListCompositionRelationshipsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListCompositionRelationshipsCommandOutput>;
  public listCompositionRelationships(
    args: ListCompositionRelationshipsCommandInput,
    cb: (err: any, data?: ListCompositionRelationshipsCommandOutput) => void
  ): void;
  public listCompositionRelationships(
    args: ListCompositionRelationshipsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListCompositionRelationshipsCommandOutput) => void
  ): void;
  public listCompositionRelationships(
    args: ListCompositionRelationshipsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListCompositionRelationshipsCommandOutput) => void),
    cb?: (err: any, data?: ListCompositionRelationshipsCommandOutput) => void
  ): Promise<ListCompositionRelationshipsCommandOutput> | void {
    const command = new ListCompositionRelationshipsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listTimeSeries(
    args: ListTimeSeriesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListTimeSeriesCommandOutput>;
  public listTimeSeries(
    args: ListTimeSeriesCommandInput,
    cb: (err: any, data?: ListTimeSeriesCommandOutput) => void
  ): void;
  public listTimeSeries(
    args: ListTimeSeriesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListTimeSeriesCommandOutput) => void
  ): void;
  public listTimeSeries(
    args: ListTimeSeriesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListTimeSeriesCommandOutput) => void),
    cb?: (err: any, data?: ListTimeSeriesCommandOutput) => void
  ): Promise<ListTimeSeriesCommandOutput> | void {
    const command = new ListTimeSeriesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public putLoggingOptions(
    args: PutLoggingOptionsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<PutLoggingOptionsCommandOutput>;
  public putLoggingOptions(
    args: PutLoggingOptionsCommandInput,
    cb: (err: any, data?: PutLoggingOptionsCommandOutput) => void
  ): void;
  public putLoggingOptions(
    args: PutLoggingOptionsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: PutLoggingOptionsCommandOutput) => void
  ): void;
  public putLoggingOptions(
    args: PutLoggingOptionsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: PutLoggingOptionsCommandOutput) => void),
    cb?: (err: any, data?: PutLoggingOptionsCommandOutput) => void
  ): Promise<PutLoggingOptionsCommandOutput> | void {
    const command = new PutLoggingOptionsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateAsset(
    args: UpdateAssetCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateAssetCommandOutput>;
  public updateAsset(
    args: UpdateAssetCommandInput,
    cb: (err: any, data?: UpdateAssetCommandOutput) => void
  ): void;
  public updateAsset(
    args: UpdateAssetCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateAssetCommandOutput) => void
  ): void;
  public updateAsset(
    args: UpdateAssetCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateAssetCommandOutput) => void),
    cb?: (err: any, data?: UpdateAssetCommandOutput) => void
  ): Promise<UpdateAssetCommandOutput> | void {
    const command = new UpdateAssetCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateAssetModel(
    args: UpdateAssetModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateAssetModelCommandOutput>;
  public updateAssetModel(
    args: UpdateAssetModelCommandInput,
    cb: (err: any, data?: UpdateAssetModelCommandOutput) => void
  ): void;
  public updateAssetModel(
    args: UpdateAssetModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateAssetModelCommandOutput) => void
  ): void;
  public updateAssetModel(
    args: UpdateAssetModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateAssetModelCommandOutput) => void),
    cb?: (err: any, data?: UpdateAssetModelCommandOutput) => void
  ): Promise<UpdateAssetModelCommandOutput> | void {
    const command = new UpdateAssetModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateAssetModelCompositeModel(
    args: UpdateAssetModelCompositeModelCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateAssetModelCompositeModelCommandOutput>;
  public updateAssetModelCompositeModel(
    args: UpdateAssetModelCompositeModelCommandInput,
    cb: (err: any, data?: UpdateAssetModelCompositeModelCommandOutput) => void
  ): void;
  public updateAssetModelCompositeModel(
    args: UpdateAssetModelCompositeModelCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateAssetModelCompositeModelCommandOutput) => void
  ): void;
  public updateAssetModelCompositeModel(
    args: UpdateAssetModelCompositeModelCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateAssetModelCompositeModelCommandOutput) => void),
    cb?: (err: any, data?: UpdateAssetModelCompositeModelCommandOutput) => void
  ): Promise<UpdateAssetModelCompositeModelCommandOutput> | void {
    const command = new UpdateAssetModelCompositeModelCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateAssetProperty(
    args: UpdateAssetPropertyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateAssetPropertyCommandOutput>;
  public updateAssetProperty(
    args: UpdateAssetPropertyCommandInput,
    cb: (err: any, data?: UpdateAssetPropertyCommandOutput) => void
  ): void;
  public updateAssetProperty(
    args: UpdateAssetPropertyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateAssetPropertyCommandOutput) => void
  ): void;
  public updateAssetProperty(
    args: UpdateAssetPropertyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateAssetPropertyCommandOutput) => void),
    cb?: (err: any, data?: UpdateAssetPropertyCommandOutput) => void
  ): Promise<UpdateAssetPropertyCommandOutput> | void {
    const command = new UpdateAssetPropertyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public batchAssociateProjectAssets(
    args: BatchAssociateProjectAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<BatchAssociateProjectAssetsCommandOutput>;
  public batchAssociateProjectAssets(
    args: BatchAssociateProjectAssetsCommandInput,
    cb: (err: any, data?: BatchAssociateProjectAssetsCommandOutput) => void
  ): void;
  public batchAssociateProjectAssets(
    args: BatchAssociateProjectAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: BatchAssociateProjectAssetsCommandOutput) => void
  ): void;
  public batchAssociateProjectAssets(
    args: BatchAssociateProjectAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: BatchAssociateProjectAssetsCommandOutput) => void),
    cb?: (err: any, data?: BatchAssociateProjectAssetsCommandOutput) => void
  ): Promise<BatchAssociateProjectAssetsCommandOutput> | void {
    const command = new BatchAssociateProjectAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public batchDisassociateProjectAssets(
    args: BatchDisassociateProjectAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<BatchDisassociateProjectAssetsCommandOutput>;
  public batchDisassociateProjectAssets(
    args: BatchDisassociateProjectAssetsCommandInput,
    cb: (err: any, data?: BatchDisassociateProjectAssetsCommandOutput) => void
  ): void;
  public batchDisassociateProjectAssets(
    args: BatchDisassociateProjectAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: BatchDisassociateProjectAssetsCommandOutput) => void
  ): void;
  public batchDisassociateProjectAssets(
    args: BatchDisassociateProjectAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: BatchDisassociateProjectAssetsCommandOutput) => void),
    cb?: (err: any, data?: BatchDisassociateProjectAssetsCommandOutput) => void
  ): Promise<BatchDisassociateProjectAssetsCommandOutput> | void {
    const command = new BatchDisassociateProjectAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createAccessPolicy(
    args: CreateAccessPolicyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateAccessPolicyCommandOutput>;
  public createAccessPolicy(
    args: CreateAccessPolicyCommandInput,
    cb: (err: any, data?: CreateAccessPolicyCommandOutput) => void
  ): void;
  public createAccessPolicy(
    args: CreateAccessPolicyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateAccessPolicyCommandOutput) => void
  ): void;
  public createAccessPolicy(
    args: CreateAccessPolicyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateAccessPolicyCommandOutput) => void),
    cb?: (err: any, data?: CreateAccessPolicyCommandOutput) => void
  ): Promise<CreateAccessPolicyCommandOutput> | void {
    const command = new CreateAccessPolicyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createDashboard(
    args: CreateDashboardCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateDashboardCommandOutput>;
  public createDashboard(
    args: CreateDashboardCommandInput,
    cb: (err: any, data?: CreateDashboardCommandOutput) => void
  ): void;
  public createDashboard(
    args: CreateDashboardCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateDashboardCommandOutput) => void
  ): void;
  public createDashboard(
    args: CreateDashboardCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateDashboardCommandOutput) => void),
    cb?: (err: any, data?: CreateDashboardCommandOutput) => void
  ): Promise<CreateDashboardCommandOutput> | void {
    const command = new CreateDashboardCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createPortal(
    args: CreatePortalCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreatePortalCommandOutput>;
  public createPortal(
    args: CreatePortalCommandInput,
    cb: (err: any, data?: CreatePortalCommandOutput) => void
  ): void;
  public createPortal(
    args: CreatePortalCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreatePortalCommandOutput) => void
  ): void;
  public createPortal(
    args: CreatePortalCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreatePortalCommandOutput) => void),
    cb?: (err: any, data?: CreatePortalCommandOutput) => void
  ): Promise<CreatePortalCommandOutput> | void {
    const command = new CreatePortalCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public createProject(
    args: CreateProjectCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<CreateProjectCommandOutput>;
  public createProject(
    args: CreateProjectCommandInput,
    cb: (err: any, data?: CreateProjectCommandOutput) => void
  ): void;
  public createProject(
    args: CreateProjectCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: CreateProjectCommandOutput) => void
  ): void;
  public createProject(
    args: CreateProjectCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: CreateProjectCommandOutput) => void),
    cb?: (err: any, data?: CreateProjectCommandOutput) => void
  ): Promise<CreateProjectCommandOutput> | void {
    const command = new CreateProjectCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteAccessPolicy(
    args: DeleteAccessPolicyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteAccessPolicyCommandOutput>;
  public deleteAccessPolicy(
    args: DeleteAccessPolicyCommandInput,
    cb: (err: any, data?: DeleteAccessPolicyCommandOutput) => void
  ): void;
  public deleteAccessPolicy(
    args: DeleteAccessPolicyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteAccessPolicyCommandOutput) => void
  ): void;
  public deleteAccessPolicy(
    args: DeleteAccessPolicyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteAccessPolicyCommandOutput) => void),
    cb?: (err: any, data?: DeleteAccessPolicyCommandOutput) => void
  ): Promise<DeleteAccessPolicyCommandOutput> | void {
    const command = new DeleteAccessPolicyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteDashboard(
    args: DeleteDashboardCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteDashboardCommandOutput>;
  public deleteDashboard(
    args: DeleteDashboardCommandInput,
    cb: (err: any, data?: DeleteDashboardCommandOutput) => void
  ): void;
  public deleteDashboard(
    args: DeleteDashboardCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteDashboardCommandOutput) => void
  ): void;
  public deleteDashboard(
    args: DeleteDashboardCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteDashboardCommandOutput) => void),
    cb?: (err: any, data?: DeleteDashboardCommandOutput) => void
  ): Promise<DeleteDashboardCommandOutput> | void {
    const command = new DeleteDashboardCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deletePortal(
    args: DeletePortalCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeletePortalCommandOutput>;
  public deletePortal(
    args: DeletePortalCommandInput,
    cb: (err: any, data?: DeletePortalCommandOutput) => void
  ): void;
  public deletePortal(
    args: DeletePortalCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeletePortalCommandOutput) => void
  ): void;
  public deletePortal(
    args: DeletePortalCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeletePortalCommandOutput) => void),
    cb?: (err: any, data?: DeletePortalCommandOutput) => void
  ): Promise<DeletePortalCommandOutput> | void {
    const command = new DeletePortalCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public deleteProject(
    args: DeleteProjectCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DeleteProjectCommandOutput>;
  public deleteProject(
    args: DeleteProjectCommandInput,
    cb: (err: any, data?: DeleteProjectCommandOutput) => void
  ): void;
  public deleteProject(
    args: DeleteProjectCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DeleteProjectCommandOutput) => void
  ): void;
  public deleteProject(
    args: DeleteProjectCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DeleteProjectCommandOutput) => void),
    cb?: (err: any, data?: DeleteProjectCommandOutput) => void
  ): Promise<DeleteProjectCommandOutput> | void {
    const command = new DeleteProjectCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeAccessPolicy(
    args: DescribeAccessPolicyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeAccessPolicyCommandOutput>;
  public describeAccessPolicy(
    args: DescribeAccessPolicyCommandInput,
    cb: (err: any, data?: DescribeAccessPolicyCommandOutput) => void
  ): void;
  public describeAccessPolicy(
    args: DescribeAccessPolicyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeAccessPolicyCommandOutput) => void
  ): void;
  public describeAccessPolicy(
    args: DescribeAccessPolicyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeAccessPolicyCommandOutput) => void),
    cb?: (err: any, data?: DescribeAccessPolicyCommandOutput) => void
  ): Promise<DescribeAccessPolicyCommandOutput> | void {
    const command = new DescribeAccessPolicyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeDashboard(
    args: DescribeDashboardCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeDashboardCommandOutput>;
  public describeDashboard(
    args: DescribeDashboardCommandInput,
    cb: (err: any, data?: DescribeDashboardCommandOutput) => void
  ): void;
  public describeDashboard(
    args: DescribeDashboardCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeDashboardCommandOutput) => void
  ): void;
  public describeDashboard(
    args: DescribeDashboardCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeDashboardCommandOutput) => void),
    cb?: (err: any, data?: DescribeDashboardCommandOutput) => void
  ): Promise<DescribeDashboardCommandOutput> | void {
    const command = new DescribeDashboardCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describePortal(
    args: DescribePortalCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribePortalCommandOutput>;
  public describePortal(
    args: DescribePortalCommandInput,
    cb: (err: any, data?: DescribePortalCommandOutput) => void
  ): void;
  public describePortal(
    args: DescribePortalCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribePortalCommandOutput) => void
  ): void;
  public describePortal(
    args: DescribePortalCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribePortalCommandOutput) => void),
    cb?: (err: any, data?: DescribePortalCommandOutput) => void
  ): Promise<DescribePortalCommandOutput> | void {
    const command = new DescribePortalCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public describeProject(
    args: DescribeProjectCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<DescribeProjectCommandOutput>;
  public describeProject(
    args: DescribeProjectCommandInput,
    cb: (err: any, data?: DescribeProjectCommandOutput) => void
  ): void;
  public describeProject(
    args: DescribeProjectCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: DescribeProjectCommandOutput) => void
  ): void;
  public describeProject(
    args: DescribeProjectCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: DescribeProjectCommandOutput) => void),
    cb?: (err: any, data?: DescribeProjectCommandOutput) => void
  ): Promise<DescribeProjectCommandOutput> | void {
    const command = new DescribeProjectCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listAccessPolicies(
    args: ListAccessPoliciesCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListAccessPoliciesCommandOutput>;
  public listAccessPolicies(
    args: ListAccessPoliciesCommandInput,
    cb: (err: any, data?: ListAccessPoliciesCommandOutput) => void
  ): void;
  public listAccessPolicies(
    args: ListAccessPoliciesCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListAccessPoliciesCommandOutput) => void
  ): void;
  public listAccessPolicies(
    args: ListAccessPoliciesCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListAccessPoliciesCommandOutput) => void),
    cb?: (err: any, data?: ListAccessPoliciesCommandOutput) => void
  ): Promise<ListAccessPoliciesCommandOutput> | void {
    const command = new ListAccessPoliciesCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listDashboards(
    args: ListDashboardsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListDashboardsCommandOutput>;
  public listDashboards(
    args: ListDashboardsCommandInput,
    cb: (err: any, data?: ListDashboardsCommandOutput) => void
  ): void;
  public listDashboards(
    args: ListDashboardsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListDashboardsCommandOutput) => void
  ): void;
  public listDashboards(
    args: ListDashboardsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListDashboardsCommandOutput) => void),
    cb?: (err: any, data?: ListDashboardsCommandOutput) => void
  ): Promise<ListDashboardsCommandOutput> | void {
    const command = new ListDashboardsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listPortals(
    args: ListPortalsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListPortalsCommandOutput>;
  public listPortals(
    args: ListPortalsCommandInput,
    cb: (err: any, data?: ListPortalsCommandOutput) => void
  ): void;
  public listPortals(
    args: ListPortalsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListPortalsCommandOutput) => void
  ): void;
  public listPortals(
    args: ListPortalsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListPortalsCommandOutput) => void),
    cb?: (err: any, data?: ListPortalsCommandOutput) => void
  ): Promise<ListPortalsCommandOutput> | void {
    const command = new ListPortalsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listProjectAssets(
    args: ListProjectAssetsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListProjectAssetsCommandOutput>;
  public listProjectAssets(
    args: ListProjectAssetsCommandInput,
    cb: (err: any, data?: ListProjectAssetsCommandOutput) => void
  ): void;
  public listProjectAssets(
    args: ListProjectAssetsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListProjectAssetsCommandOutput) => void
  ): void;
  public listProjectAssets(
    args: ListProjectAssetsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListProjectAssetsCommandOutput) => void),
    cb?: (err: any, data?: ListProjectAssetsCommandOutput) => void
  ): Promise<ListProjectAssetsCommandOutput> | void {
    const command = new ListProjectAssetsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public listProjects(
    args: ListProjectsCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<ListProjectsCommandOutput>;
  public listProjects(
    args: ListProjectsCommandInput,
    cb: (err: any, data?: ListProjectsCommandOutput) => void
  ): void;
  public listProjects(
    args: ListProjectsCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: ListProjectsCommandOutput) => void
  ): void;
  public listProjects(
    args: ListProjectsCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: ListProjectsCommandOutput) => void),
    cb?: (err: any, data?: ListProjectsCommandOutput) => void
  ): Promise<ListProjectsCommandOutput> | void {
    const command = new ListProjectsCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateAccessPolicy(
    args: UpdateAccessPolicyCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateAccessPolicyCommandOutput>;
  public updateAccessPolicy(
    args: UpdateAccessPolicyCommandInput,
    cb: (err: any, data?: UpdateAccessPolicyCommandOutput) => void
  ): void;
  public updateAccessPolicy(
    args: UpdateAccessPolicyCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateAccessPolicyCommandOutput) => void
  ): void;
  public updateAccessPolicy(
    args: UpdateAccessPolicyCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateAccessPolicyCommandOutput) => void),
    cb?: (err: any, data?: UpdateAccessPolicyCommandOutput) => void
  ): Promise<UpdateAccessPolicyCommandOutput> | void {
    const command = new UpdateAccessPolicyCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateDashboard(
    args: UpdateDashboardCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateDashboardCommandOutput>;
  public updateDashboard(
    args: UpdateDashboardCommandInput,
    cb: (err: any, data?: UpdateDashboardCommandOutput) => void
  ): void;
  public updateDashboard(
    args: UpdateDashboardCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateDashboardCommandOutput) => void
  ): void;
  public updateDashboard(
    args: UpdateDashboardCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateDashboardCommandOutput) => void),
    cb?: (err: any, data?: UpdateDashboardCommandOutput) => void
  ): Promise<UpdateDashboardCommandOutput> | void {
    const command = new UpdateDashboardCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updatePortal(
    args: UpdatePortalCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdatePortalCommandOutput>;
  public updatePortal(
    args: UpdatePortalCommandInput,
    cb: (err: any, data?: UpdatePortalCommandOutput) => void
  ): void;
  public updatePortal(
    args: UpdatePortalCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdatePortalCommandOutput) => void
  ): void;
  public updatePortal(
    args: UpdatePortalCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdatePortalCommandOutput) => void),
    cb?: (err: any, data?: UpdatePortalCommandOutput) => void
  ): Promise<UpdatePortalCommandOutput> | void {
    const command = new UpdatePortalCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  public updateProject(
    args: UpdateProjectCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<UpdateProjectCommandOutput>;
  public updateProject(
    args: UpdateProjectCommandInput,
    cb: (err: any, data?: UpdateProjectCommandOutput) => void
  ): void;
  public updateProject(
    args: UpdateProjectCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: UpdateProjectCommandOutput) => void
  ): void;
  public updateProject(
    args: UpdateProjectCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: UpdateProjectCommandOutput) => void),
    cb?: (err: any, data?: UpdateProjectCommandOutput) => void
  ): Promise<UpdateProjectCommandOutput> | void {
    const command = new UpdateProjectCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

  /**
   * Invoke AI Assistant
   */
  public invokeAssistant(
    args: InvokeAssistantCommandInput,
    options?: __HttpHandlerOptions,
  ): Promise<InvokeAssistantCommandOutput>;
  public invokeAssistant(
    args: InvokeAssistantCommandInput,
    cb: (err: any, data?: InvokeAssistantCommandOutput) => void
  ): void;
  public invokeAssistant(
    args: InvokeAssistantCommandInput,
    options: __HttpHandlerOptions,
    cb: (err: any, data?: InvokeAssistantCommandOutput) => void
  ): void;
  public invokeAssistant(
    args: InvokeAssistantCommandInput,
    optionsOrCb?: __HttpHandlerOptions | ((err: any, data?: InvokeAssistantCommandOutput) => void),
    cb?: (err: any, data?: InvokeAssistantCommandOutput) => void
  ): Promise<InvokeAssistantCommandOutput> | void {
    const command = new InvokeAssistantCommand(args);
    if (typeof optionsOrCb === "function") {
      this.send(command, optionsOrCb)
    } else if (typeof cb === "function") {
      if (typeof optionsOrCb !== "object")
        throw new Error(`Expect http options but get ${typeof optionsOrCb}`)
      this.send(command, optionsOrCb || {}, cb)
    } else {
      return this.send(command, optionsOrCb);
    }
  }

}
